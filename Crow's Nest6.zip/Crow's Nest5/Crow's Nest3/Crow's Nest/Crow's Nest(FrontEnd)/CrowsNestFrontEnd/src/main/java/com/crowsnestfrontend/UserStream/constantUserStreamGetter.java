package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserFloatingButton.NewUserBubble;
import com.crowsnestfrontend.controllers.UserBubbleController;
import javafx.application.Platform;
import javafx.scene.layout.VBox;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.LineIterator;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

public class constantUserStreamGetter {

    public static void streamCaller()  {

        try(Socket socket = new Socket("localhost", 12345);
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter writer=new PrintWriter(socket.getOutputStream() ,true);
        )
             {
                 System.out.println("here");
                 writer.println("5");
                 writer.println(Owner.nameId);

                 VBox node1=(VBox) SceneManager.mainScene.getRoot().lookup("#allPeople");


                 int length =Integer.parseInt(reader.readLine());

                 for(int i=0;i<length; i++){
                        String name=reader.readLine();
                        System.out.println(name);
                        int imageLength=Integer.parseInt(reader.readLine());
                        System.out.println(imageLength);
                        byte[] imageBytes=socket.getInputStream().readNBytes(imageLength);
                        node1.getChildren().add(new NewUserBubble(name ,imageBytes ,node1));
                 }
        }catch (Exception e){
            System.out.println("why "+e.getMessage());
        }

    }
}
