package com.crowsnestfrontend.Utility;

import com.crowsnestfrontend.RequestClass.RequestObject;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;

public class SyncManager {
    public static CountDownLatch imageSenderLock =null;
    public static CountDownLatch messageLoading =null;
    public static CountDownLatch signUploading=null;
    static {
        processing();



    }



    public static void processing(){

        

    }
}
