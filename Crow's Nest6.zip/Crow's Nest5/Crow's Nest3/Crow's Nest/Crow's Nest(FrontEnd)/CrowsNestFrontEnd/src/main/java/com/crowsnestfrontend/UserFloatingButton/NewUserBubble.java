package com.crowsnestfrontend.UserFloatingButton;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.MainScene;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.controllers.UserBubbleController;
import com.crowsnestfrontend.controllers.mainSceneController;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class NewUserBubble extends Pane {
    public UserBubbleController ctrl;
    public NewUserBubble(String text,byte[]array, VBox box) {
        FXMLLoader loader = new FXMLLoader(
                MainApplication.class.getResource("UserBubble.fxml")
        );

        try {
            Parent bubbleUi = loader.load();

            VBox.setMargin(bubbleUi, new Insets(0, 0, 2, 8));
            this.ctrl = loader.getController();
            this.ctrl.set(box);
            this.ctrl.setText(text);
            this.ctrl.setImage(array);
            box.getChildren().add(bubbleUi);

        } catch (IOException e) {
            e.printStackTrace();
        }



    }
}
