package com.crowsnestfrontend;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SigningRelatedClasses.SignBranchingHandler;

import com.crowsnestfrontend.UserFloatingButton.NewUserBubble;
import com.crowsnestfrontend.UserFloatingButton.chatBubble.ChatBubble;
import com.crowsnestfrontend.UserStream.constantUserStreamGetter;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.PrintWriter;

import java.net.Socket;
import java.util.Objects;
class pp{
    static int number=1;
}
public class MainApplication extends Application {
    static{
        new SceneManager();
    }

    @Override
    public void start(Stage stage) throws IOException, ClassNotFoundException {
        SceneManager.globalStage=stage;
        try {
            stage.getIcons().add(new Image(
                    Objects.requireNonNull(MainApplication.class.getResourceAsStream("images/raven.png"))
            ));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        var clazz = Class.forName("com.crowsnestfrontend.Utility.SyncManager");

        stage.setTitle("Crow's Nest");
        SignBranchingHandler.signBranchLogicHandler();

        stage.show();




        stage.setResizable(false);
        stage.setOnCloseRequest(event -> {
            try(Socket socket=new Socket("localhost",12345);
                PrintWriter writer=new PrintWriter(socket.getOutputStream(),true)
            ){
                writer.println("10");
                writer.println("name");

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        var node=(VBox) SceneManager.mainScene.getRoot().lookup("#OwnerMessage");
        node.getChildren().add(new ChatBubble("hello"));




    }

    public static void main(String[] args) {
        launch();
    }
}