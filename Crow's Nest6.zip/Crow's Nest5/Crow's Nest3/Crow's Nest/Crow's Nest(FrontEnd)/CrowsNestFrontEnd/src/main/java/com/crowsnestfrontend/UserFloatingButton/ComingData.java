package com.crowsnestfrontend.UserFloatingButton;

public class ComingData {
public String name;
public byte[] image;
}
