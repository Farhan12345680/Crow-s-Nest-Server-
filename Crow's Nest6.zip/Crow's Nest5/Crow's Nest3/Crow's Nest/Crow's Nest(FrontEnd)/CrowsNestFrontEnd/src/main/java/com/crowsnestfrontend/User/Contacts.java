package com.crowsnestfrontend.User;

import com.crowsnestfrontend.User.Messages;

import java.util.ArrayList;

public class Contacts {

    public String name_id;
    public int is_friend;
    public int unseen;
    public byte[] image_bytes;
    public int image_size;
    public int is_active;

    public ArrayList<Messages>text_messages=new ArrayList<>();

    public Contacts(String name_id , int is_friend ,int image_size){
        this.name_id=name_id;
        this.is_friend=is_friend;
        this.image_size=image_size;

    }
}
