package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.SceneManagement.MainScene;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;

import com.crowsnestfrontend.Utility.SyncManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.event.ActionEvent;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ResourceBundle;




public class SignUpController implements Initializable {

    @FXML
    public VBox containerVBox;
    @FXML
    private TextField signup1;

    @FXML
    private PasswordField signup2;

    @FXML
    private Button sign_in;

    @FXML
    private Button Signup;

    @FXML
    private Text text;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        text.setText("");


        signup1.textProperty().addListener((_, _, _) -> {
            Platform.runLater(()->{
                text.setText("");
            });
        });
        signup2.textProperty().addListener((_, _, c)-> {
            {
                Platform.runLater(()->{
                    text.setText("");
                });
            }
        });
        sign_in.setOnAction(this::onSignIn);
        Signup.setOnAction(this::onSignUp);

    }


    @FXML
    private void onSignIn(ActionEvent event) {
        String name = signup1.getText().trim();
        String pass = signup2.getText().trim();

        if (name.isEmpty() || pass.isEmpty()) {
            Platform.runLater(()->{
                signup1.setText("");
                signup2.setText("");
            });
            text.setText("Please enter both name and password.");
            return;
        }

        if(name.length() >10 ||pass.length()>10){
            Platform.runLater(()->{
                signup1.setText("");
                signup2.setText("");
            });
            System.out.println("The input length has to be less than or equal to 10");
            return;
        }


        Thread.startVirtualThread(() -> {
            try (Socket clientSocket=new Socket("localhost" , 12345);
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                 BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {

                out.println("0");
                out.println(name);
                out.println(pass);

                int status = Integer.parseInt(in.readLine());
                String message = in.readLine();
                int length = Integer.parseInt(in.readLine());
                System.out.println(length);
                byte[] imageBytes = IOUtils.readFully(clientSocket.getInputStream() ,length);;

                if (status == -1) {
                    Platform.runLater(() -> text.setText(message));
                    return;
                }

                Owner.nameId = name;
                Owner.image = imageBytes;
                localDataBaseGenerator.initialize_database();

            } catch (Exception e) {
                Platform.runLater(() -> text.setText("Login failed: " + e.getMessage()));
            }
            SyncManager.signUploading.countDown();

            Platform.runLater(()->{
                SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.profileImageView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.usernameLabel.setText(Owner.nameId);
                SceneManager.globalStage.centerOnScreen();

            });

        });
    }

    @FXML
    private void onSignUp(ActionEvent event) {
        String name = signup1.getText().trim();
        String pass = signup2.getText().trim();
        if (name.isEmpty() || pass.isEmpty()) {
            Platform.runLater(()->{
                signup1.setText("");
                signup2.setText("");
            });
            text.setText("Please enter both name and password.\nDon't Use WhiteSpace");
            return;
        }
        if(name.length() >10 ||pass.length()>10){
            Platform.runLater(()->{
                signup1.setText("");
                signup2.setText("");
            });
            System.out.println("The input length has to be less than or equal to 10");
            return;
        }

        Thread.startVirtualThread(() -> {




            int status = 0;
            String message = null;
            int length=0;

            Owner.image=new byte[length];

            try(    Socket clientSocket=new Socket("localhost",12345);
                    PrintWriter out= new PrintWriter(clientSocket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))){

                out.println("1");
                out.println(name);
                out.println(pass);

                status = (Integer.parseInt(in.readLine()));
                message = in.readLine();

                Owner.nameId= name;


                if(status==-1){
                    String finalMessage = message;
                    Platform.runLater(()->{
                        signup1.setText("");
                        signup2.setText("");
                        text.setText(finalMessage);
                    });

                    return;
                }
                localDataBaseGenerator.initialize_database();
                out.println(Owner.image.length);
                Platform.runLater(()->{
                    SceneManager.globalStage.setScene(SceneManager.loadingScene);
                });
                IOUtils.write( Owner.image , clientSocket.getOutputStream());
                System.out.println("Is successful "+ in.readLine());

                new mainSceneController().Personal_image_id.setImage(new Image(new ByteArrayInputStream(Owner.image)));

            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            SyncManager.signUploading.countDown();

            Platform.runLater(()->{

                SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.profileImageView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.usernameLabel.setText(Owner.nameId);
                SceneManager.globalStage.centerOnScreen();

            });
        });

    }




}



