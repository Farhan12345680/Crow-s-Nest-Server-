package org.example.SerializedClasses;

public class ChangeImage {
}
