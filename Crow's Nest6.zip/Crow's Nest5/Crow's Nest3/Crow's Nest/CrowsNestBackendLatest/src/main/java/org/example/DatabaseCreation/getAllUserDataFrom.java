package org.example.DatabaseCreation;

import org.apache.commons.io.IOUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.*;

public class getAllUserDataFrom {

    public static void getUsers(String userName ,Socket socket){
        String getUserString="SELECT name_id, image FROM Profiles WHERE name_id NOT IN ( SELECT name_id_receiver FROM blockedUsers WHERE name_id_sender = ?);";
        String getUserCount="SELECT COUNT(*) FROM Profiles WHERE name_id NOT IN ( SELECT name_id_receiver FROM blockedUsers WHERE name_id_sender = ?);";

        try(Connection conn = DriverManager.getConnection(DatabaseCreation.URL);
            PreparedStatement ps =conn.prepareStatement(getUserString);
            PreparedStatement ps1=conn.prepareStatement(getUserCount);
            BufferedReader reader=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter writer=new PrintWriter(socket.getOutputStream() ,true);
        ){
            ps.setString(1 ,userName);
            ResultSet rs =ps.executeQuery();

            ps1.setString(1 , userName);
            ResultSet rs1=ps1.executeQuery();
            if (rs1.next()) {
                writer.println(rs1.getInt(1) + "");
            }


            while(rs.next()){
                if (rs.getString(1).equals(userName)){
                    continue;
                }
                byte[] array=rs.getBytes(2);
                writer.println(rs.getString(1));
                writer.println(array.length+"");

                IOUtils.write(array , socket.getOutputStream());

            }

        }catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
