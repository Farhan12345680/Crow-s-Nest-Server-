package org.example;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import org.apache.commons.io.IOUtils;

import org.example.DatabaseCreation.DatabaseCreation;
import org.example.DatabaseCreation.getAllUserDataFrom;
import org.example.ISOnline.is_online;
import org.example.UserAuthentication.AuthChecker;

public class ServerCrowsNest
{
    public static final int ip_port=12345;
    public static final String host_name="127.0.0.1";

    public static void main(String[] args) throws Exception {
        ServerSocket socket = new ServerSocket(ip_port);

        while(true){
            Socket client=socket.accept();

            Thread.startVirtualThread(()->{
                while(!client.isClosed()){
                    check_endpoints(client);
                }
            });
        }
    }


    public static void check_endpoints(Socket socket) {
        try (
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)
        ) {
            int request_type = Integer.parseInt(reader.readLine());

            if (request_type == 1) {
                String name = reader.readLine();
                String password = reader.readLine();
                System.out.println("New User Creation Request");
                if (AuthChecker.whetherIsUser(name)) {
                    writer.println("-1");
                    writer.println("Username already exists. Choose another.");
                    socket.close();
                }
                if(is_online.active_users.get(name)==null){
                    is_online.active_users.put(name ,new ArrayList<>());
                }
                is_online.active_users.get(name).add(" ");
                AuthChecker.insertUser(name, password);
                writer.println("1");
                writer.println("User created successfully");

                int sizeReader=Integer.parseInt(reader.readLine());
                byte[] bf= socket.getInputStream().readNBytes(sizeReader);
                DatabaseCreation.addImagetoTheTable(bf ,name);

            }
            else if (request_type == 0) {

                String name = reader.readLine();
                String password = reader.readLine();

                if (!AuthChecker.whetherIsUser(name)) {
                    writer.println("-1");
                    writer.println("User does not exist.");
                    writer.println("0");
                    socket.close();
                    return;
                }
                if (!AuthChecker.doesPasswordMatch(name, password)) {
                    writer.println("-1");
                    writer.println("Incorrect password.");
                    writer.println("0");
                    socket.close();
                    return;
                }

                if(is_online.active_users.get(name)==null){
                    is_online.active_users.put(name ,new ArrayList<>());

                }

                is_online.active_users.get(name).add(" ");
                byte[] UserImageByte=DatabaseCreation.getUserImageData(name);

                writer.println("1");
                writer.println("Login successful");

                writer.println(""+UserImageByte.length);
                System.out.println("the  length of the sending image "+UserImageByte.length);
                IOUtils.write(UserImageByte ,socket.getOutputStream());
                socket.getOutputStream().flush();
                socket.shutdownOutput();
            }
            else if (request_type == 10) {
                String name = reader.readLine();
                if(is_online.active_users.get(name)==null){

                    return ;
                }
                is_online.active_users.get(name).remove(" ");
                if(is_online.active_users.get(name).isEmpty()){
                    is_online.active_users.remove(name);
                }

                socket.close();

            }
            else if (request_type==3){
                System.out.println("ApiEndpoint number 3");
                String name=reader.readLine();
                if(is_online.active_users.get(name)==null){
                    is_online.active_users.put(name ,new ArrayList<>());

                }
                is_online.active_users.get(name).add(" ");

            }
            else if (request_type == 4) {
                System.out.println("API endpoint access is 4");

                try {
                    String name_id = reader.readLine();
                    int length = Integer.parseInt(reader.readLine());

                    byte[] buffer =  IOUtils.readFully(socket.getInputStream(), length);

                    DatabaseCreation.addImagetoTheTable(buffer, name_id);

                    System.out.println("Image length: " + length);
                    System.out.println("Image stored for: " + name_id);

                } catch (Exception e) {
                    System.out.println("Error in image receiving: " + e.getMessage());
                    e.printStackTrace();
                } finally {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                System.out.println("Hello called");
            }
            else if(request_type ==5){ //getUsers
                System.out.println("5 called");
                String name=reader.readLine();
                getAllUserDataFrom.getUsers( name, socket);

            }
        }catch(Exception e){
        }

    }
}
