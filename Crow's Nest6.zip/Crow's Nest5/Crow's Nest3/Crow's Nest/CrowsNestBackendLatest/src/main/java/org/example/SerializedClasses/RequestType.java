package org.example.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class RequestType implements Serializable {
    @Serial
    public static final long serialVersionUID=5L;



}
