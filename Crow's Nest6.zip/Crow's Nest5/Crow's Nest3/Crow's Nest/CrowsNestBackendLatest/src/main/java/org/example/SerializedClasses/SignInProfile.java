package org.example.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class SignInProfile implements Serializable {
    @Serial
    private static final long serialVersionUID = 3L;

    private final String  name;
    private final String password;

    public SignInProfile(String name, String password) {
        this.name = name;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }
}
