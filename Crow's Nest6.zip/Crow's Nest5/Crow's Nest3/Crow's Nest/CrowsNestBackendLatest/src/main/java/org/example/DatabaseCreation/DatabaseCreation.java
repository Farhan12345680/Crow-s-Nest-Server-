package org.example.DatabaseCreation;

import java.sql.*;

public class DatabaseCreation {
    public static final String URL = "jdbc:sqlite:main_database_page.db";

    public static void main(String[] args) throws SQLException {
        initializeSchema();
        System.out.println("Database setup complete.");
    }

    public static void initializeSchema() throws SQLException {
        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement()) {

            stmt.execute("PRAGMA foreign_keys = ON;");

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS Profiles (
                  name_id  TEXT PRIMARY KEY NOT NULL,
                  password TEXT NOT NULL,
                  image    BLOB
                );
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS Contacts (
                  owner_name TEXT NOT NULL,
                  target     TEXT NOT NULL,
                  is_friend  INTEGER NOT NULL DEFAULT 0,
                  FOREIGN KEY(owner_name) REFERENCES Profiles(name_id) ON DELETE CASCADE,
                  FOREIGN KEY(target)     REFERENCES Profiles(name_id) ON DELETE CASCADE,
                  PRIMARY KEY(owner_name, target)
                );
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS Messages (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  content TEXT NOT NULL,
                  isReplyTo INTEGER,
                  receiver TEXT NOT NULL,
                  sender TEXT NOT NULL,
                  time_sent DATETIME DEFAULT CURRENT_TIMESTAMP,
                  is_seen INTEGER DEFAULT 0,
                  reaction INTEGER DEFAULT 0,
                  isDeletedBySender INTEGER DEFAULT 0,
                  FOREIGN KEY(receiver) REFERENCES Profiles(name_id),
                  FOREIGN KEY(sender) REFERENCES Profiles(name_id),
                  FOREIGN KEY(isReplyTo) REFERENCES Messages(id)
                );
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS recentReaction (
                  messageID INTEGER,
                  reactionSender TEXT NOT NULL,
                  reactionChange INTEGER,
                  isDeleted INTEGER,
                  FOREIGN KEY(messageID) REFERENCES Messages(id),
                  FOREIGN KEY(reactionSender) REFERENCES Profiles(name_id)
                );
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS Call_Type (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  receiver TEXT NOT NULL,
                  sender TEXT NOT NULL,
                  time_sent DATETIME DEFAULT CURRENT_TIMESTAMP,
                  call_type INTEGER NOT NULL,
                  is_seen INTEGER DEFAULT 0,
                  FOREIGN KEY(receiver) REFERENCES Profiles(name_id),
                  FOREIGN KEY(sender) REFERENCES Profiles(name_id) ON DELETE CASCADE
                );
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS blockedUsers (
                  name_id_sender TEXT NOT NULL,
                  name_id_receiver TEXT NOT NULL,
                  FOREIGN KEY(name_id_sender) REFERENCES Profiles(name_id),
                  FOREIGN KEY(name_id_receiver) REFERENCES Profiles(name_id)
                );
            """);

            stmt.execute("CREATE INDEX IF NOT EXISTS blockedUserIndex ON blockedUsers(name_id_sender);");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_contacts_owner ON Contacts(owner_name);");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_messages_recv_sndr ON Messages(receiver, sender);");
            stmt.execute("CREATE INDEX IF NOT EXISTS get_unseen_messages ON Messages(receiver, sender, is_seen);");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_reactionType ON recentReaction(messageID);");
        }
    }

    public static void addImagetoTheTable(byte[] bytes, String name) {
        String sql = "UPDATE Profiles SET image = ? WHERE name_id = ?;";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBytes(1, bytes);
            ps.setString(2, name);
            ps.execute();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static byte[] getUserImageData(String nameid) {
        String sql = "SELECT image FROM Profiles WHERE name_id = ?;";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nameid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getBytes("image");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return new byte[0];
    }
}
