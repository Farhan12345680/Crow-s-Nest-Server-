package com.crowsnestfrontend.ClientSideDataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class changeOwnerClientDatabase {
    public static  void addImagetoTheTable(byte[] bytes,String name){
        System.out.println("called");
        String insertIntoDatabaseStateMent= """
                UPDATE owner_personal_data SET image_bytes = ? WHERE name_id = ?;
                """;

        try(Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString )){
            try(PreparedStatement ps =conn.prepareStatement(insertIntoDatabaseStateMent)){
                ps.setBytes(1 , bytes);
                ps.setString(2 , name);
                ps.execute();
                System.out.println("image insertion successful");
            }catch (SQLException e){
                System.out.println(e.getMessage());
            }
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
}
