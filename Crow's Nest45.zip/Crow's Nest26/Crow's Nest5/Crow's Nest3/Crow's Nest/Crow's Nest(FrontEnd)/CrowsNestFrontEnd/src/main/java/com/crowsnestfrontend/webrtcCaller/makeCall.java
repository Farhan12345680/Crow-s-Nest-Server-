package com.crowsnestfrontend.webrtcCaller;

import com.crowsnestfrontend.SerializedClasses.webrtcpayload;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.UserStream.constantStream;
import dev.onvoid.webrtc.*;
import dev.onvoid.webrtc.media.MediaStreamTrack;
import dev.onvoid.webrtc.media.audio.*;
import dev.onvoid.webrtc.media.video.*;
import javafx.application.Platform;
import org.controlsfx.control.tableview2.filter.filtereditor.SouthFilter;

import javax.xml.transform.Source;
import java.util.ArrayList;
import java.util.List;

public class makeCall {

    private PeerConnectionFactory factory;
    private RTCPeerConnection peerConnection;
    private AudioTrack localAudio;
    private VideoTrack localVideo;

    public makeCall() {
        factory = new PeerConnectionFactory();

        RTCConfiguration config = new RTCConfiguration();
        RTCPeerConnection pc = factory.createPeerConnection(config,
                new PeerConnectionObserver() {
                    @Override
                    public void onIceCandidate(RTCIceCandidate rtcIceCandidate) {
                        System.out.println("New ice candidate " + rtcIceCandidate.sdp);
                    }
                }
                );
        RTCOfferOptions options = new RTCOfferOptions();

        pc.createOffer(
                options,
                new CreateSessionDescriptionObserver() {
                    @Override
                    public void onSuccess(RTCSessionDescription offer) {
                        System.out.println("=== SDP Offer Generated ===");
                        System.out.println("Type: " + offer.sdpType);
                        System.out.println("SDP:\n" + offer.sdp);
                        constantStream.payloadBlockingQueue.add(new webrtcpayload(Owner.nameId
                                , SelectedUserData.name.get(),offer.sdpType+"" , offer.sdp));
                        // Set local description
                        pc.setLocalDescription(offer, new SetSessionDescriptionObserver() {
                            @Override
                            public void onSuccess() {
                                System.out.println("Local description set");
                            }

                            @Override
                            public void onFailure(String error) {
                                System.err.println("Failed to set local description: " + error);
                            }
                        });
                    }

                    @Override
                    public void onFailure(String error) {
                        System.err.println("Failed to create offer: " + error);
                    }
                }
        );

    }
}
