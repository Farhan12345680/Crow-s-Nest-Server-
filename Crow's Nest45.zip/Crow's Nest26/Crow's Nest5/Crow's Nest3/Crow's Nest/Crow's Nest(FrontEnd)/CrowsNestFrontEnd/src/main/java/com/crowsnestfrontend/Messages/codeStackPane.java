package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.Utility.codeArea;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;
import org.fxmisc.richtext.CodeArea;

import java.io.IOException;

public class codeStackPane extends StackPane {

    private final CodeArea codeBox;
    @FXML
    private VBox FolderCreationPage;


    public codeStackPane() {
        codeBox = new codeArea();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("StackPaneCodingObject.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.getChildren().add(codeBox);

        double height = Screen.getScreens().getFirst().getVisualBounds().getHeight() * 0.9;
        double width = Screen.getScreens().getFirst().getVisualBounds().getWidth() * 0.55;

        for (Node node : this.getChildren()) {
            if (node instanceof Region region) {
                region.setMinHeight(height);
                region.setMinWidth(width);
            }
        }

        codeBox.setMinHeight(height);
        codeBox.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 0.7);
        FolderCreationPage.toFront();
        codeBox.setVisible(false);
        codeBox.setManaged(false);
    }

    public CodeArea getCodeBox() {
        return codeBox;
    }
}
