package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.ClientSideDataBase.UserPayloadHandling;
import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.Messages.MessagePayloadProcessing;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.*;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.User.User;
import com.crowsnestfrontend.UserFloatingButton.UserCell;
import com.crowsnestfrontend.UserStream.constantStream;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.StringBinding;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.WeakChangeListener;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.ByteArrayInputStream;
import java.util.Objects;

public class UserBubbleController {
    public static String[] imageURL = new String[4];
    public VBox parentBox = null;

    @FXML public ImageView userProfileImage;
    @FXML public Text userName;
    @FXML public ImageView addFriend;
    @FXML public ImageView blockuser;
    @FXML public Pane userBubblePane;
    @FXML public HBox NormalView;
    @FXML public HBox AcceptView;
    @FXML public ImageView AcceptFriendRequest;
    @FXML public ImageView RejectFriendRequest;
    @FXML public Text UnseenTextCount;

    private static final Image[] IMAGE_ICONS = new Image[4];
    static {
        imageURL[0] = "images/add-friend.png";
        imageURL[1] = "images/pending.png";
        imageURL[2] = "images/add-group.png";
        imageURL[3] = "images/pending.png";

        IMAGE_ICONS[0] = new Image(Objects.requireNonNull(MainApplication.class.getResourceAsStream(imageURL[0])));
        IMAGE_ICONS[1] = new Image(Objects.requireNonNull(MainApplication.class.getResourceAsStream(imageURL[1])));
        IMAGE_ICONS[2] = new Image(Objects.requireNonNull(MainApplication.class.getResourceAsStream(imageURL[2])));
        IMAGE_ICONS[3] = new Image(Objects.requireNonNull(MainApplication.class.getResourceAsStream(imageURL[3])));
    }

    private UserCell ownerCell;
    private User currentUser;

    private ChangeListener<Number> friendListener;

    public void setOwnerCell(UserCell cell) {
        this.ownerCell = cell;
    }

    @FXML
    public void initialize() {
        if (addFriend != null) addFriend.setOnMouseClicked(this::addFriendClicker);
        if (blockuser != null) blockuser.setOnMouseClicked(this::blockUserCall);
        if (AcceptFriendRequest != null) AcceptFriendRequest.setOnMouseClicked(this::friendRequestAccepted);
        if (RejectFriendRequest != null) RejectFriendRequest.setOnMouseClicked(this::friendRequestRejected);
    }

    @FXML
    private void friendRequestRejected(MouseEvent event) {
        Platform.runLater(() -> {
            System.out.println("rejected called");
            SceneManager.mainSceneContrller.friendRequestUsers.remove(currentUser);
            constantStream.payloadBlockingQueue.add(new removeIncomingFriendRequest(Owner.nameId, currentUser.name));
            currentUser.setIsFriend(0);
        });
    }

    @FXML
    private void friendRequestAccepted(MouseEvent event) {
        Platform.runLater(() -> {
            System.out.println("Accepted called");
            constantStream.payloadBlockingQueue.add(new MakeFriendRequestAccept(Owner.nameId, currentUser.name));
            currentUser.setIsFriend(3);
        });
    }

    public void setUser(User user) {
        Runnable work = () -> {
            if (this.currentUser != null) {
                try { if (friendListener != null) this.currentUser.isFriendProperty().removeListener(friendListener); } catch (Exception ignored) {}
                try { UnseenTextCount.textProperty().unbind(); } catch (Exception ignored) {}
            }

            this.currentUser = user;

            userName.setText(user.name);
            byte[] imgBytes = user.imageURL;
            if (imgBytes != null) setImage(imgBytes);

            friendListener = (a ,b , newVal) -> applyFriendState(newVal.intValue());
            user.isFriendProperty().addListener(friendListener);

            StringBinding unseenBinding = Bindings.createStringBinding(() -> {
                int v = user.MessageProperty().get();
                return v == 0 ? "" : String.valueOf(v);
            }, user.MessageProperty());

            UnseenTextCount.textProperty().bind(unseenBinding);

            applyFriendState(user.getStatus());
        };

        if (Platform.isFxApplicationThread()) work.run();
        else Platform.runLater(work);
    }

    private void applyFriendState(int state) {
        Platform.runLater(() -> {
            NormalView.setVisible(false);
            NormalView.setManaged(false);
            AcceptView.setVisible(false);
            AcceptView.setManaged(false);

            switch (state) {
                case 0 -> {
                    User user = ownerCell.getItem();
                    if (ownerCell != null) {
                        Owner.friendRequest.remove(currentUser.name);
                        Owner.friends.remove(currentUser.name);

                        if (SceneManager.mainSceneContrller.friendUsers.contains(user)) {
                            SceneManager.mainSceneContrller.friendUsers.remove(user);
                            Owner.friends.remove(user.name);
                        }

                        if (SceneManager.mainSceneContrller.friendRequestUsers.contains(user)) {
                            SceneManager.mainSceneContrller.friendRequestUsers.remove(user);
                            Owner.friendRequest.remove(user.name);
                        }
                    }
                    UserPayloadHandling.friendUserPayloadHandling(currentUser.name, 0);
                    addFriend.setImage(IMAGE_ICONS[2]);
                    NormalView.setVisible(true);
                    NormalView.setManaged(true);
                }

                case 1 -> {
                    UserPayloadHandling.friendUserPayloadHandling(currentUser.name, 1);
                    addFriend.setImage(IMAGE_ICONS[3]);
                    NormalView.setVisible(true);
                    NormalView.setManaged(true);
                }

                case 2 -> {
                    if (!Owner.friendRequest.containsKey(currentUser.name)) {
                        Owner.friendRequest.put(currentUser.name, " ");
                        SceneManager.mainSceneContrller.addRequestUser(currentUser);
                    }
                    UserPayloadHandling.friendUserPayloadHandling(currentUser.name, 2);
                    AcceptView.setVisible(true);
                    AcceptView.setManaged(true);
                }

                case 3 -> {
                    System.out.println("---------------->received<------------------ made friends");
                    addFriend.setImage(IMAGE_ICONS[0]);
                    UserPayloadHandling.friendUserPayloadHandling(currentUser.name, 3);

                    Owner.friendRequest.remove(currentUser.name);
                    SceneManager.mainSceneContrller.friendRequestUsers.remove(currentUser);

                    if (!Owner.friends.containsKey(currentUser.name)) Owner.friends.put(currentUser.name, " ");
                    if (!SceneManager.mainSceneContrller.friendUsers.contains(currentUser)) SceneManager.mainSceneContrller.friendUsers.add(currentUser);

                    NormalView.setVisible(true);
                    NormalView.setManaged(true);
                }
                default -> {}
            }
        });
    }

    @FXML
    public void setText(String msg) {
        Platform.runLater(() -> userName.setText(msg));
    }

    @FXML
    public void setUser(byte[] userImage) {
        Platform.runLater(() -> userProfileImage.setImage(new Image(new ByteArrayInputStream(userImage))));
    }

    @FXML
    public void addFriendClicker(MouseEvent event) {
        if (currentUser == null) return;

        int data = currentUser.getStatus();
        Platform.runLater(() -> {
            switch (data) {
                case 0 -> {
                    currentUser.setIsFriend(1);
                    constantStream.payloadBlockingQueue.add(new MakeFriendRequest(Owner.nameId, currentUser.name));
                }
                case 1 -> {
                    currentUser.setIsFriend(0);
                    constantStream.payloadBlockingQueue.add(new deleteFriendRequest(Owner.nameId, currentUser.name));
                }
                case 2 -> currentUser.setIsFriend(0);
                case 3 -> {
                    constantStream.payloadBlockingQueue.add(new Unfriend(Owner.nameId, currentUser.name));
                    currentUser.setIsFriend(0);
                }
            }
        });
    }

    @FXML
    private void blockUserCall(MouseEvent event) {
        event.consume();
        if (ownerCell != null) {
            User user = ownerCell.getItem();

            Platform.runLater(() -> {
                SceneManager.mainSceneContrller.blockUserMessage.setText(
                        "You have blocked \"" + currentUser.name + "\".\nUnblock through the profile button, if you want to further communicate."
                );
                SceneManager.mainSceneContrller.obsUsers.remove(user);

                if (SceneManager.mainSceneContrller.friendUsers.contains(user)) {
                    SceneManager.mainSceneContrller.friendUsers.remove(user);
                    Owner.friends.remove(user.name);
                }

                if (SceneManager.mainSceneContrller.friendRequestUsers.contains(user)) {
                    SceneManager.mainSceneContrller.friendRequestUsers.remove(user);
                    Owner.friendRequest.remove(user.name);
                }

                SceneManager.mainSceneContrller.BlockScreen.toFront();
            });
            localDataBaseGenerator.makeBlock(user.name);
            constantStream.payloadBlockingQueue.add(new MakeBlock(Owner.nameId, user.name));
        }
    }


    public void set(VBox node1) {
        this.parentBox = node1;
    }

    @FXML
    public void setImage(byte[] imageBytes) {
        Platform.runLater(() -> userProfileImage.setImage(new Image(new ByteArrayInputStream(imageBytes))));
    }

    @FXML
    public void onBubbleClicked(MouseEvent event) {
        Thread.startVirtualThread(() ->
                MessagePayloadProcessing.messagePayloadProcessingUserBased(currentUser.name));
        mainSceneController.name=currentUser.name;
        mainSceneController.image=currentUser.imageURL;
        Platform.runLater(() -> {
            currentUser.setIngerCountToZero();
            SceneManager.mainSceneContrller.messageBox.toFront();
            SelectedUserData.name.set(currentUser.name);
            SelectedUserData.image = currentUser.imageURL;
        });
    }
}
