package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.deleteMessage;
import com.crowsnestfrontend.SerializedClasses.payloadMessageReaction;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.Utility.ImageObjectHolder;
import com.crowsnestfrontend.controllers.MessageReply;
import com.crowsnestfrontend.controllers.mainSceneController;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Popup;

import static com.crowsnestfrontend.UserStream.constantStream.payloadBlockingQueue;

public class MessageCell extends ListCell<Message> {

    @FXML
    private Label messageLabel;
    @FXML
    private HBox OwnerMessage;
    @FXML
    private Label BubbleTime;
    @FXML
    private ImageView reactionImage;
    @FXML
    private Label replyText;
    @FXML
    private ImageView deleteButton;
    @FXML
    private Label replyingTo;

    private FXMLLoader loader;
    private Message currentMessage;

    private final ChangeListener<Number> reactionListener = (obs, oldVal, newVal) -> {
        int rt = newVal == null ? 0 : newVal.intValue();
        switch (rt) {
            case 1 -> reactionImage.setImage(ImageObjectHolder.IMG_HAHA);
            case 2 -> reactionImage.setImage(ImageObjectHolder.IMG_LOVE);
            case 3 -> reactionImage.setImage(ImageObjectHolder.IMG_ANGRY);
            case 4 -> reactionImage.setImage(ImageObjectHolder.IMG_SAD);
            default -> reactionImage.setImage(ImageObjectHolder.IMG_NEUTRAL);
        }
    };

    @Override
    protected void updateItem(Message message, boolean empty) {
        super.updateItem(message, empty);

        if (empty || message == null) {
            detachListener();
            currentMessage = null;
            loader = null;
            setText(null);
            setGraphic(null);
            return;
        }

        if (currentMessage != null && currentMessage != message) {
            detachListener();
        }

        this.currentMessage = message;

        if (loader == null) {
            loader = new FXMLLoader(MainApplication.class.getResource("chatBubble.fxml"));
            loader.setController(this);
            try {
                loader.load();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        setupReplying(message);
        setupMessageBubble(message);
        setupDelete(message);
        setupReactionPopup();

        attachListener();
        updateReactionUI();

        setText(null);
        setGraphic(OwnerMessage);
    }

    private void detachListener() {
        if (currentMessage != null) {
            currentMessage.reaction_type.removeListener(reactionListener);
        }
    }

    private void attachListener() {
        if (currentMessage != null) {
            currentMessage.reaction_type.addListener(reactionListener);
        }
    }

    private void updateReactionUI() {
        if (currentMessage != null) {
            reactionListener.changed(currentMessage.reaction_type, null, currentMessage.reaction_type.get());
        }
    }

    private void setupReplying(Message message) {
        if (message.replyMessageID == -1) {
            replyingTo.setVisible(false);
            replyingTo.setManaged(false);
        } else {
            var replyMsg = Owner.messageConcurrentHashMap.get(message.replyMessageID);
            if (replyMsg != null) {
                replyingTo.setText("Replying to: " + replyMsg.getText());
                replyingTo.setVisible(true);
                replyingTo.setManaged(true);
            }
        }

        replyText.setOnMouseClicked(event -> {
            Dialog<Void> dialog = new Dialog<>();
            dialog.setDialogPane(new DialogPane());
            dialog.getDialogPane().getButtonTypes().add(new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE));
            MessageReply messageReply = new MessageReply(message.messageID, dialog::close);
            dialog.getDialogPane().setContent(messageReply);
            dialog.show();
        });
    }

    private void setupMessageBubble(Message message) {
        messageLabel.setText(message.getText());
        BubbleTime.setText(message.formattedTime);

        if (message.isOwnMessage()) {
            reactionImage.setMouseTransparent(true);
            OwnerMessage.setStyle("-fx-alignment: center-right;");
            messageLabel.setStyle("-fx-background-color: #DCF8C6; -fx-padding: 8px; -fx-background-radius: 12px;");
        } else {
            OwnerMessage.setStyle("-fx-alignment: center-left;");
            messageLabel.setStyle("-fx-background-color: #FFFFFF; -fx-padding: 8px; -fx-background-radius: 12px;");
        }

        if (message.isOwnMessage() && (message.isDeletedBySender.get() == 1 || message.isDeletedByReceiver.get() == 1)) {
            hideExtras(message);
        } else if ((message.isDeletedBySender.get() == 1 || message.isDeletedByReceiver.get() == 1)) {
            hideExtras(message);
        }

        message.isDeletedBySender.addListener((obs, oldVal, newVal) -> hideExtras(message));
        message.isDeletedByReceiver.addListener((obs, oldVal, newVal) -> hideExtras(message));
    }

//    private void hideExtrasSender(Message message) {
//        if(message.isDeletedBySender.get()==1 && message.ownMessage){
//            messageLabel.setText("You deleted this message");
//        }else if(message.isDeletedBySender.get()==1 && !message.ownMessage ){
//            messageLabel.setText("Message was deleted");
//        }else if(!message.ownMessage &&  message.isDeletedByReceiver.get()==1){
//            messageLabel.setText("You deleted this message ");
//        }else if(message.isDeletedBySender.get()==1 && message.ownMessage){
//
//        }
//
//        reactionImage.setVisible(false);
//        reactionImage.setManaged(false);
//        replyText.setVisible(false);
//        replyText.setManaged(false);
//        BubbleTime.setVisible(false);
//        BubbleTime.setManaged(false);
//    }

    private void hideExtras(Message message) {
        if(message.isDeletedBySender.get()==1 && message.ownMessage){
            messageLabel.setText("You deleted this message");


            reactionImage.setVisible(false);
            reactionImage.setManaged(false);
            replyText.setVisible(false);
            replyText.setManaged(false);
            BubbleTime.setVisible(false);
            BubbleTime.setManaged(false);
        }else if(message.isDeletedBySender.get()==1 && !message.ownMessage ){
            messageLabel.setText("Message was deleted");


            reactionImage.setVisible(false);
            reactionImage.setManaged(false);
            replyText.setVisible(false);
            replyText.setManaged(false);
            BubbleTime.setVisible(false);
            BubbleTime.setManaged(false);
        }else if(!message.ownMessage &&  message.isDeletedByReceiver.get()==1){
            messageLabel.setText("You deleted this message ");


            reactionImage.setVisible(false);
            reactionImage.setManaged(false);
            replyText.setVisible(false);
            replyText.setManaged(false);
            BubbleTime.setVisible(false);
            BubbleTime.setManaged(false);
        }else if(message.isDeletedByReceiver.get()==1 && message.ownMessage){


            reactionImage.setVisible(false);
            reactionImage.setManaged(false);
            replyText.setVisible(false);
            replyText.setManaged(false);
            BubbleTime.setVisible(false);
            BubbleTime.setManaged(false);
        }else{

        }

    }

    private void setupDelete(Message message) {
        deleteButton.setOnMouseClicked(event -> {
            String sender, receiver;
            if (message.ownMessage) {
                sender = Owner.nameId;
                message.isDeletedBySender.set(1);
                receiver = SelectedUserData.name.get();
            } else {
                sender = SelectedUserData.name.get();
                message.isDeletedByReceiver.set(1);
                receiver = SelectedUserData.name.get();
            }

            deleteMessage obj = new deleteMessage(message.messageID, Owner.nameId, sender, receiver);
            MessagePayloadProcessing.deleteMessage(obj);
            payloadBlockingQueue.add(obj);
        });
    }

    private void setupReactionPopup() {
        reactionImage.setOnMouseClicked(e -> {
            if (currentMessage == null) return;

            Popup popup = new Popup();
            popup.setAutoHide(true);

            ReactionPopUP reactionBox = new ReactionPopUP(currentMessage.messageID, popup ,reactionImage);
            popup.getContent().add(reactionBox);

            double x = e.getScreenX() - reactionBox.getWidth() / 2 + reactionImage.getBoundsInLocal().getWidth() / 2;
            double y = e.getScreenY() - reactionBox.getHeight() - 10;

            popup.show(SceneManager.globalStage, x, y);
        });
    }
}
