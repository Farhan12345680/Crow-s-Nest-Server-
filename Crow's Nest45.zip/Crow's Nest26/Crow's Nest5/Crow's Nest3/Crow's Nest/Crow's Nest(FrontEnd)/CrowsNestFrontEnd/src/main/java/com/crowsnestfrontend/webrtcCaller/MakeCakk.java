//package com.crowsnestfrontend.webrtcCaller;
//
//import com.crowsnestfrontend.SceneManagement.SceneManager;
//import dev.onvoid.webrtc.*;
//import dev.onvoid.webrtc.media.MediaStreamTrack;
//import dev.onvoid.webrtc.media.audio.*;
//import dev.onvoid.webrtc.media.video.*;
//import javafx.application.Platform;
//import javafx.scene.control.ButtonBar;
//import javafx.scene.control.ButtonType;
//import javafx.scene.control.Dialog;
//import javafx.scene.control.DialogPane;
//import javafx.stage.Modality;
//import javafx.stage.StageStyle;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class MakeCall {
//
//    private PeerConnectionFactory factory;
//    private RTCPeerConnection peerConnection;
//    private AudioTrack localAudio;
//    private VideoTrack localVideo;
//    private Dialog<Void> dialog;
//
//    public MakeCall() {
//        factory = new PeerConnectionFactory();
//
//        try {
//            dialog = new Dialog<>();
//            dialog.initStyle(StageStyle.TRANSPARENT);
//            dialog.initModality(Modality.APPLICATION_MODAL);
//            dialog.setDialogPane(new DialogPane());
//
//            ButtonType dummyButton = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
//            dialog.getDialogPane().getButtonTypes().add(dummyButton);
//            dialog.getDialogPane().lookupButton(dummyButton).setVisible(false);
//            dialog.getDialogPane().lookupButton(dummyButton).setManaged(false);
//
//            callerWaitingScene callWaiting = new callerWaitingScene(dialog::close);
//            dialog.getDialogPane().setContent(callWaiting);
//
//            dialog.setOnCloseRequest(event -> cleanup());
//
//            Platform.runLater(() -> {
//                dialog.show();
//
//                RTCConfiguration config = new RTCConfiguration();
//                RTCIceServer iceServer = new RTCIceServer();
//                iceServer.urls.add("stun:stun.l.google.com:19302");
//                config.iceServers.add(iceServer);
//
//                peerConnection = factory.createPeerConnection(config, new PeerConnectionObserver() {
//                    @Override
//                    public void onIceCandidate(RTCIceCandidate candidate) {
//                        System.out.println("New ICE candidate: " + candidate.sdp);
//                        // Send candidate to remote peer via signaling server
//                        sendIceCandidateToRemote(candidate);
//                    }
//
//                    @Override
//                    public void onConnectionChange(RTCPeerConnectionState state) {
//                        System.out.println("PeerConnection state: " + state);
//                        if (state == RTCPeerConnectionState.DISCONNECTED || state == RTCPeerConnectionState.FAILED) {
//                            Platform.runLater(() -> dialog.close());
//                        }
//                    }
//
//                    @Override
//                    public void onIceConnectionChange(RTCIceConnectionState state) {
//                        System.out.println("ICE connection state: " + state);
//                    }
//
//                    @Override
//                    public void onTrack(RTCRtpTransceiver transceiver) {
//                        MediaStreamTrack track = transceiver.getReceiver().getTrack();
//                        System.out.println("Received remote track: " + track.getKind());
//                        // You can add UI code here to render the remote video/audio
//                    }
//
//                    @Override
//                    public void onDataChannel(RTCDataChannel dataChannel) {
//                        System.out.println("DataChannel created: " + dataChannel.getLabel());
//                    }
//                });
//
//                AudioOptions audioOptions = new AudioOptions();
//                audioOptions.echoCancellation = true;
//                localAudio = factory.createAudioTrack("audio0", factory.createAudioSource(audioOptions));
//
//                VideoDeviceSource videoSource = new VideoDeviceSource();
//                localVideo = factory.createVideoTrack("video0", videoSource);
//
//                List<String> streamIds = new ArrayList<>();
//                streamIds.add("stream1");
//                peerConnection.addTrack(localAudio, streamIds);
//                peerConnection.addTrack(localVideo, streamIds);
//
//                RTCOfferOptions offerOptions = new RTCOfferOptions();
//                peerConnection.createOffer(offerOptions, new CreateSessionDescriptionObserver() {
//                    @Override
//                    public void onSuccess(RTCSessionDescription desc) {
//                        peerConnection.setLocalDescription(desc, new SetSessionDescriptionObserver() {
//                            @Override
//                            public void onSuccess() {
//                                System.out.println("Local description set successfully!");
//                            }
//
//                            @Override
//                            public void onFailure(String error) {
//                                System.err.println("Failed to set local description: " + error);
//                            }
//                        });
//
//                        System.out.println("Offer created! SDP: " + desc.sdp);
//                        // Send the offer SDP to remote peer through signaling server
//                        sendOfferToRemote(desc);
//                    }
//
//                    @Override
//                    public void onFailure(String error) {
//                        System.err.println("Failed to create offer: " + error);
//                    }
//                });
//            });
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    // Public method to receive the remote answer SDP from signaling server
//    public void onRemoteAnswerReceived(String sdp) {
//        RTCSessionDescription remoteDesc = new RTCSessionDescription(RTCSdpType.ANSWER, sdp);
//        peerConnection.setRemoteDescription(remoteDesc, new SetSessionDescriptionObserver() {
//            @Override
//            public void onSuccess() {
//                System.out.println("Remote description set successfully!");
//            }
//
//            @Override
//            public void onFailure(String error) {
//                System.err.println("Failed to set remote description: " + error);
//            }
//        });
//    }
//
//    // Public method to receive remote ICE candidates from signaling server
//    public void onRemoteIceCandidateReceived(String candidate, String sdpMid, int sdpMLineIndex) {
//        RTCIceCandidate iceCandidate = new RTCIceCandidate(candidate, sdpMid, sdpMLineIndex);
//        peerConnection.addIceCandidate(iceCandidate);
//    }
//
//    // Method to send offer SDP to remote peer - implement signaling here
//    private void sendOfferToRemote(RTCSessionDescription offer) {
//        // TODO: Implement signaling to send offer SDP to remote peer
//        System.out.println("[Signaling] Send offer to remote peer:\n" + offer.sdp);
//    }
//
//    // Method to send ICE candidates to remote peer - implement signaling here
//    private void sendIceCandidateToRemote(RTCIceCandidate candidate) {
//        // TODO: Implement signaling to send ICE candidates to remote peer
//        System.out.println("[Signaling] Send ICE candidate to remote peer:\n" + candidate.sdp);
//    }
//
//    // Cleanup resources when dialog is closed or call ends
//    private void cleanup() {
//        System.out.println("Cleaning up resources...");
//        if (peerConnection != null) {
//            peerConnection.close();
//            peerConnection = null;
//        }
//        if (localVideo != null) {
//            localVideo.dispose();
//            localVideo = null;
//        }
//        if (localAudio != null) {
//            localAudio.dispose();
//            localAudio = null;
//        }
//        if (factory != null) {
//            factory.dispose();
//            factory = null;
//        }
//    }
//}
