package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.updateStatus;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.User;
import javafx.application.Platform;

public class UpdateStream {

    public static void updater(updateStatus us) {
        System.out.println("Processing request update");

        String name = us.getName();
        User user = Owner.current.get(name);

        if (user == null) {
            System.out.println("this is the problem");
            return;
        }

        int status = us.getStatus();

        switch (status) {
            case 1:
                    user.setIsFriend(2);
                break;

            case -1, 0, 13:
                    user.setIsFriend(0);
                break;

            case 3, 11:
                user.setIsFriend(3);
                break;

            case 10:
                user.setIsFriend(1);
                break;
            case -144:
                localDataBaseGenerator.makeBlock(name);

                Platform.runLater(() -> {
                    SceneManager.mainSceneContrller.obsUsers.remove(user);

                    if (SceneManager.mainSceneContrller.friendUsers.remove(user)) {
                        Owner.friends.remove(user.name);
                    }

                    if (SceneManager.mainSceneContrller.friendRequestUsers.remove(user)) {
                        Owner.friendRequest.remove(user.name);
                    }
                });
                break;


            default:
                System.out.println("Unknown status: " + status);
        }
    }
}
