package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class webrtcpayload extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID = 702L;

    public String userId;
    public String candidate;

    public Object sdp;
    public String type;

    public webrtcpayload(String userId,String candidate ,String  type,String sdp ) {
        super("");
        this.userId = userId;
        this.candidate = candidate;
        this.type=type;
        this.sdp=sdp;

    }
}
