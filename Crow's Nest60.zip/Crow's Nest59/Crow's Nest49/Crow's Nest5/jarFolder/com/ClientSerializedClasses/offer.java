package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class offer implements Serializable {

    @Serial
    private static final long serialVersionUID=1709L;
    public String name;
    public String image;

    public offer(String name , String image){
        this.name=name;
        this.image=image;
    }
}
