package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class startCodeBox implements Serializable{
    @Serial
    private static final long serialVersionUID = 1712L;
    public String messageString;

    public startCodeBox(){

    }
    
}
