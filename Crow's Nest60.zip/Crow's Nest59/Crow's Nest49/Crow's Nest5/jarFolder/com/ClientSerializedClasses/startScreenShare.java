package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class startScreenShare implements Serializable{
    @Serial
    private static final long serialVersionUID = 1713L;
    public String messageString;

    public startScreenShare(){
            
    }
    
}
