package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class endCodeBlocks implements Serializable{
    @Serial
    private static final long serialVersionUID = 1706L;
    public String messageString;

    public endCodeBlocks(){
            
    }
    
}
