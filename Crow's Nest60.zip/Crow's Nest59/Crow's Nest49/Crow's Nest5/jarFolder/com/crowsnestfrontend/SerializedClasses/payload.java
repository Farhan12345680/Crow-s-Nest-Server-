package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class payload implements Serializable {
    @Serial
    private static final long serialVersionUID =15L;

    public final String clientName;


    public payload(String clientName) {
        this.clientName = clientName;
    }
}
