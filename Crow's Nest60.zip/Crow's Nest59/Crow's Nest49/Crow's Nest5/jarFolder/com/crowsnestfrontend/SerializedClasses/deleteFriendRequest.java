package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class deleteFriendRequest extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID=38L;
    private final String name ;

    public deleteFriendRequest(String clientName , String name   ){
        super(clientName);
        this.name= name;
    }

    public String getName(){
        return this.name;
    }
}
