package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class ImageChanger  implements Serializable {
    @Serial
    private static  final long serialVersionUID=908L;
    private final String name;
    private final String imageURL;

    public ImageChanger(String name,String imageURL){
        this.imageURL=imageURL;
        this.name=name;
    }

    public String getName(){
        return this.name;
    }
    public String getImageURL(){
        return this.imageURL;
    }
}
