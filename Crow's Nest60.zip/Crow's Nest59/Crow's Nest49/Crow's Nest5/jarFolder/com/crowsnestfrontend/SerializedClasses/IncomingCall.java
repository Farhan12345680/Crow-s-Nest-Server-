package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class IncomingCall extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 8991237L;

    public int incoming;
    public String callerName;
    public byte[] callerPhoto;

    public String receiver;

    public IncomingCall(int incoming, String callerName, byte[] callerPhoto, String receiver) {
        super("");
        this.callerName = callerName;
        this.callerPhoto = callerPhoto;
        this.receiver = receiver;
    }
}