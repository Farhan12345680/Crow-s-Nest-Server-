package com.comment;

import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;
import java.io.Serializable;

public class commentDataReturn extends payload implements Serializable {

    @Serial
    private static final long serialVersionUID = 13495L;

    public String senderName;
    public int PostID;
    public int commentID;
    public String commentDescription;
    public String time;

    public commentDataReturn(String senderName,
            int PostID, int commentID, String commentDescription, String time) {
        super(senderName);
        this.commentDescription = commentDescription;
        this.senderName = senderName;
        this.PostID = PostID;
        this.commentID = commentID;
        this.time = time;
    }
}
