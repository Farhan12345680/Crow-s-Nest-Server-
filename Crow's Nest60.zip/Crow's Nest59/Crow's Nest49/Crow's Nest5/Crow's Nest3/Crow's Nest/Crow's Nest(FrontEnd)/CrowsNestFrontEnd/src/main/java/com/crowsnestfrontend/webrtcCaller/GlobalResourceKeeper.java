package com.crowsnestfrontend.webrtcCaller;

import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.Utility.SyncManager;
import com.crowsnestfrontend.controllers.VideoSceneController;
import dev.onvoid.webrtc.PeerConnectionFactory;
import dev.onvoid.webrtc.RTCPeerConnection;
import dev.onvoid.webrtc.media.audio.AudioTrack;
import dev.onvoid.webrtc.media.video.VideoDesktopSource;
import dev.onvoid.webrtc.media.video.VideoTrack;
import dev.onvoid.webrtc.media.video.desktop.ScreenCapturer;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import nu.pattern.OpenCV;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;

import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.atomic.AtomicBoolean;

public class GlobalResourceKeeper {
    private static GlobalResourceKeeper instance;


//    @FXML
//    public VBox voiceHolder;

    private WritableImage writableImage;
    private PixelWriter pixelWriter;

    private WritableImage remoteWritableImage;
    private PixelWriter remotePixelWriter;

    public static VideoSceneController controller;

    public static synchronized GlobalResourceKeeper getInstance(){
        if(instance==null){
            instance = new GlobalResourceKeeper();
        }

        return instance;
    }

    public synchronized  void selfCameraOnOff(){

    }


    public synchronized  void otherCameraOnOff(){


    }

    public static VideoDesktopSource videoSource;




    public static void startDesktopVideoCapture(){
        videoSource=new VideoDesktopSource();
        videoSource.setFrameRate(30);
        videoSource.setMaxFrameSize(1280 , 720);

        videoSource.setSourceId(0, false);

        videoSource.start();


    }

    public static void endDesktopVideoCapture(){

        videoSource.stop();

        videoSource.dispose();

        videoSource=null;
    }

    public static AtomicBoolean isSelfCameraActive = new AtomicBoolean(true);
    public static AtomicBoolean isOtherCameraActive = new AtomicBoolean(true);


    public static AtomicBoolean isCodeBlockActive =new AtomicBoolean(false);
    public static AtomicBoolean isScreeenShareActive= new AtomicBoolean(false);


    public static  void codeCaller(VBox codeArea , StackPane pane  , VBox voiceHolder ) throws  Exception{
        if(isScreeenShareActive.get()){
            return;
        }

        if(!isCodeBlockActive.get()){
            codeArea.setVisible(true);
            codeArea.setManaged(true);
            codeArea.toFront();

            voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *30f/100);
        }
        else{
            codeArea.setVisible(false);
            codeArea.setManaged(false);
            codeArea.toBack();

            voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        }

        isCodeBlockActive.set(!isCodeBlockActive.get());

    }

    public static void videoShare( ){
        if(GlobalResourceKeeper.isScreeenShareActive!=null){

        }



    }




}
