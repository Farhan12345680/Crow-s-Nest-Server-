package com.crowsnestfrontend.forum;

import javafx.scene.layout.HBox;

public class writePostHbox extends HBox {
}
