package com.crowsnestfrontend.Utility;

import com.ClientSerializedClasses.caretPosition;
import com.ClientSerializedClasses.textChange;
import com.crowsnestfrontend.webrtcCaller.Callee;
import com.crowsnestfrontend.webrtcCaller.Caller;
import javafx.application.Platform;
import javafx.stage.Screen;
import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.LineNumberFactory;
import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;

import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class codeArea extends CodeArea {

    private static final String[] KEYWORDS = new String[]{
            "abstract", "assert", "boolean", "break", "byte", "case",
            "catch", "char", "class", "const", "continue", "default",
            "do", "double", "else", "enum", "extends", "final", "finally",
            "float", "for", "if", "goto", "implements", "import", "instanceof",
            "int", "interface", "long", "native", "new", "package", "private",
            "protected", "public", "return", "short", "static", "strictfp",
            "super", "switch", "synchronized", "this", "throw", "throws",
            "transient", "try", "void", "volatile", "while"
    };

    private static final String[] TYPES = {
            "int", "float", "String", "Boolean",
            "Integer", "double", "Float", "Double"
    };

    private static final String[] OPERATORS = {
            "+", "/", "-", "*", "(", ")", "{", "}", "[", "]", "="
    };

    private static final Pattern PATTERN = Pattern.compile(
            "(?<KEYWORD>\\b(" + String.join("|", KEYWORDS) + ")\\b)"
                    + "|(?<TYPE>\\b(" + String.join("|", TYPES) + ")\\b)"
                    + "|(?<OPERATORS>(" + String.join("|",
                    java.util.Arrays.stream(OPERATORS).map(Pattern::quote).toList()
            ) + "))"
                    + "|(?<NUMBER>\\b\\d+\\b)"
                    + "|(?<STRING>\"([^\"\\\\]|\\\\.)*\")"
    );

    public codeArea() {
        this.setParagraphGraphicFactory(LineNumberFactory.get(this));
        this.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 85f / 100);

        this.textProperty().addListener((obs, oldText, newText) -> {
            Platform.runLater(()->{
                this.setStyleSpans(0, applyHighlighting(newText));

            });
        });
        this.replaceText("public class HelloWorld {\n    public static void main(String[] args) {\n    }\n}");
        this.caretPositionProperty().addListener((obs, oldPos, newPos) -> {
            int x = this.getCaretColumn();
            int y =this.getCurrentParagraph();
            if(Caller.callerObject!=null){
            Caller.callerObject.sendObject(new caretPosition(x ,y));}
        });

        this.plainTextChanges()
                .subscribe(change -> {
                    int position = change.getPosition();
                    String inserted = change.getInserted();
                    String removed = change.getRemoved();

                    if(Caller.callerObject!=null){
                        Caller.callerObject.sendObject(new textChange(position , inserted, removed));

                    }
                });
    }

    private StyleSpans<Collection<String>> applyHighlighting(String text) {


        Matcher matcher = PATTERN.matcher(text);
        StyleSpansBuilder<Collection<String>> spansBuilder = new StyleSpansBuilder<>();

        int lastKwEnd = 0;
        while (matcher.find()) {
            String styleClass =
                    matcher.group("KEYWORD")   != null ? "keyword" :
                            matcher.group("TYPE")      != null ? "type" :
                                    matcher.group("OPERATORS") != null ? "operator" :
                                            matcher.group("NUMBER")    != null ? "number" :
                                                    matcher.group("STRING")    != null ? "string" : null;

            assert styleClass != null;

            spansBuilder.add(java.util.Collections.emptyList(), matcher.start() - lastKwEnd);
            spansBuilder.add(java.util.Collections.singleton(styleClass), matcher.end() - matcher.start());
            lastKwEnd = matcher.end();
        }
        spansBuilder.add(java.util.Collections.emptyList(), text.length() - lastKwEnd);

        return spansBuilder.create();
    }
}
