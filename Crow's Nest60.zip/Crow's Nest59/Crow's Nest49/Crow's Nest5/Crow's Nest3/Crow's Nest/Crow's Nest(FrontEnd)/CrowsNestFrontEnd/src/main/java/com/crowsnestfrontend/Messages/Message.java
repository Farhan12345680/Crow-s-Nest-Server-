package com.crowsnestfrontend.Messages;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;



public class Message {
    public int messageID;
    public int replyMessageID=-1;
    public IntegerProperty reaction_type=new SimpleIntegerProperty(0);
    public String text;
    public boolean ownMessage;
    public String formattedTime ;
    public int messageType;
    public String imageURL;
    public IntegerProperty isDeletedBySender=new SimpleIntegerProperty(0);

    public IntegerProperty isDeletedByReceiver=new SimpleIntegerProperty(0);


    public int index=0;
    public Message(String text ,boolean ownMessage ,String formattedTime
            , int messageID){
        this.text=text;
        this.ownMessage = ownMessage;
        this.formattedTime=formattedTime;
        this.messageID=messageID;
    }

    public Message(String text , boolean ownMessage ,String formattedTime
                    ,int messageID ,int replyMessageID ,int reaction , int isDeleteBySender , int isDeletedByReceiver
            ,int messageType , String imageURL){

            this(text , ownMessage ,formattedTime ,messageID);
            this.replyMessageID=replyMessageID;
            this.reaction_type.set(reaction);
            this.isDeletedBySender.set(isDeleteBySender);
            this.isDeletedByReceiver.set(isDeletedByReceiver);
            this.messageType=messageType;
            this.imageURL=imageURL;
    }

    public String getText() {
        return text;
    }

    public boolean isOwnMessage() {
        return ownMessage;
    }



}