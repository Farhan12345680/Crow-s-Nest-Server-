package com.crowsnestfrontend;


import com.cloudinary.utils.ObjectUtils;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import javafx.scene.image.Image;

import java.io.*;
import java.net.URL;
import java.util.Map;

import static com.crowsnestfrontend.SceneManagement.SceneManager.cloudinary;

public class FileManager {

    public static void main(String[] args) throws IOException {
        storeImageOnFile("https://res.cloudinary.com/demo/image/upload/kitten_fighting.gif" ,
                "profileImage");

    }

    public static String storeImageOnFile(String globalURL , String type) {
        File file = new File("images");
        String returnString = "";

        try {
            if (!file.exists()) {
                file.mkdir();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        File file1 = new File("images/" + type + "s");
        try {
            if (!file1.exists()) {
                file1.mkdir();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        typeExtractor type2 = extractType(globalURL);
        File file2 = new File("images/" + type + "s/" + type2.name + "." + type2.type);

        try {
            if (file2.createNewFile()) {
                //System.out.println("this was called none times \n hello world my name is farhan adib\n this called one only");
                try (FileOutputStream fileOutputStream = new FileOutputStream(file2);
                     InputStream openStream = new URL(globalURL).openStream()) {

                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = openStream.read(buffer)) != -1) {
                        fileOutputStream.write(buffer, 0, bytesRead);
                    }
                }
            }

            returnString = file2.toURI().toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return returnString;
    }

    static class typeExtractor {
        String name="";
        String type="";

    }

    public static typeExtractor extractType(String url){
       if(url==null){
           url=" ";
       }
        int length= url.length();
        int i=0;

        typeExtractor type=new typeExtractor();
        for(i=length-1 ;i>=0; i--){
            if(url.charAt(i)=='.'){
                break;
            }
        }

        type.type=url.substring(i+1);
        int j=i;
        for(;j>=0; j--){
            if(url.charAt(j)=='/'){
                type.name=url.substring(j+1, i);
                break;
            }
        }
        return type;
    }

    public static String getImageFromGithub(String url ){
        String returnString ="";

        url=cloudinaryDefaults.githubToCloudinary(url);
        //System.out.println(url);
        File file = new File("images");


        try {
            if (!file.exists()) {
                file.mkdir();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        File file1 = new File("images/profileImages");
        try {
            if (!file1.exists()) {
                file1.mkdir();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        typeExtractor type2 = extractType(url);
        File file2 = new File("images/profileImages/" + type2.name + "." + type2.type);

        try {
            if (file2.createNewFile()) {
                try (FileOutputStream fileOutputStream = new FileOutputStream(file2);
                     InputStream openStream = new URL(url).openStream()) {

                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = openStream.read(buffer)) != -1) {
                        fileOutputStream.write(buffer, 0, bytesRead);
                    }
                }
            }
            returnString = file2.toURI().toString();

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return returnString;
    }

    public static String getImageUniqueId(){


        var type = extractType(Owner.image);

        return "https://res.cloudinary.com/dvpwqtobj/image/upload/v1757076286/"+type.name+"."+type.type;
    }
}
