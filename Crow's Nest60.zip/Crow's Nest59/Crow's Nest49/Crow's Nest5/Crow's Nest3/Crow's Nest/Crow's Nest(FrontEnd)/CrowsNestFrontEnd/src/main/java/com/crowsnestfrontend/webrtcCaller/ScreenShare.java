package com.crowsnestfrontend.webrtcCaller;

import com.crowsnestfrontend.MainApplication;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class ScreenShare extends VBox {
    @FXML
    public Button askToShareScreen;

    @FXML
    public Label StatusLabel;

    @FXML
    public Button GiveUpControl;

    @FXML
    public ImageView ScreenImage;

    public ScreenShare(){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("ScreenShareFXML.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);


        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        GlobalResourceKeeper.controller.ScreenShareController=this;
        if(askToShareScreen!=null){
            askToShareScreen.setOnMouseClicked((e)->{

            });
        }

        if(GiveUpControl!=null){
            GiveUpControl.setOnMouseClicked((e)->{
            });
        }




    }


}
