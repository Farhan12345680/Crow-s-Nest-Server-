package com.crowsnestfrontend.controllers;

import com.ClientSerializedClasses.endCall;
import com.ClientSerializedClasses.startCodeBox;
import com.ClientSerializedClasses.startScreenShare;
import com.crowsnestfrontend.Utility.codeStackPane;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.webrtcCaller.*;
import dev.onvoid.webrtc.media.video.VideoTrack;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import kotlin.random.PlatformRandomKt;
import okhttp3.Call;
import org.fxmisc.richtext.CodeArea;
import org.opencv.videoio.VideoCapture;

import java.io.IOException;
import java.util.Collections;

import static com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper.videoSource;


public class VideoSceneController {

    @FXML
    public ImageView otherView;
    @FXML
    public ImageView endCall;
    @FXML
    public ImageView code;
    @FXML
    public ImageView camera;
    @FXML
    public ImageView mic;

    @FXML
    public ImageView selfView;

    @FXML
    public VBox voiceHolder;
    @FXML
    public HBox buttonHolder;
    @FXML
    public VBox codeArea;
    @FXML
    public VBox videoChatHolder;
    @FXML
    public Text ClientName;
    @FXML
    public Text UserName;

    public CodeArea codeBox;
    public VideoCapture capture;

    public byte[] buffer;
    public WritableImage writableImage;
    public PixelWriter pixelWriter;

    public volatile boolean cameraActive = false;
    @FXML
    public ImageView videoShare;

    public ScreenShare screenShare;

    public static int videoShower=0;

    public VBox ScreenShareController;



    @FXML
    public codeStackPane pane;

    {
        pane=new codeStackPane();

    }

    @FXML
    public void initialize() throws IOException, InterruptedException {
        GlobalResourceKeeper.controller=this;

        ClientName.setText(SelectedUserData.name.get());
        UserName.setText(Owner.nameId);

        otherView.setImage(new Image( SelectedUserData.image));

        voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        videoChatHolder.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight()-200);
        selfView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        selfView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        otherView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        otherView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        codeArea.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);
        codeArea.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() *90f/100);


        pane=new codeStackPane();
        codeArea.getChildren().add(pane);

        codeArea.setVisible(false);
        codeArea.setManaged(false);
        pane.toFront();


        code.setOnMouseClicked((e)->{
           // resource.selfCameraOnOff();
            if(Callee.callee!=null){
                return;
            }
            Caller.callerObject.sendObject(new startCodeBox());

            try {
                GlobalResourceKeeper.codeCaller(codeArea ,pane , voiceHolder);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        screenShare=new ScreenShare();
        pane.getChildren().add(screenShare);


        endCall.setOnMouseClicked((e)->{
            //resource.stopCameraPermanent();
            if(Caller.callerObject!=null){
                Caller.callerObject.sendObject(new endCall());

            }
            if(Callee.callee!=null){
                Callee.callee.sendObject(new endCall());

            }

            SceneManager.globalStage.setScene(SceneManager.mainScene);
            SceneManager.globalStage.centerOnScreen();
            SceneManager.globalStage.show();
        });

        camera.setOnMouseClicked((e)->{
            //resource.cycleCamera();
        });

        videoShare.setOnMouseClicked((e)->{
            if(Caller.callerObject==null){

                return;
            }

            System.out.println("this was called");
            if(videoShower==0 ){
                pane.setVisible(true);
                pane.setManaged(true);
                System.out.println("this is inside 0");
                Caller.callerObject.sendObject(new startScreenShare());
                GlobalResourceKeeper.isScreeenShareActive.set(true);
                GlobalResourceKeeper.startDesktopVideoCapture();
                VideoTrack desktopTrack = Caller.callerObject.factory.createVideoTrack("desktopTrack", videoSource);
                Caller.callerObject.pc.addTrack(desktopTrack, Collections.singletonList("desktopStream"));

                codeArea.setManaged(true);
                codeArea.setVisible(true);
            }else{
                pane.setVisible(false);
                pane.setManaged(false);
                GlobalResourceKeeper.isScreeenShareActive.set(false);
                GlobalResourceKeeper.endDesktopVideoCapture();

            }


            videoShower++;
            videoShower%=2;

        });



        var current=new VideoSceneChat();
        buttonHolder.getChildren().add(current);

        //resource.startCamera();
    }

}
