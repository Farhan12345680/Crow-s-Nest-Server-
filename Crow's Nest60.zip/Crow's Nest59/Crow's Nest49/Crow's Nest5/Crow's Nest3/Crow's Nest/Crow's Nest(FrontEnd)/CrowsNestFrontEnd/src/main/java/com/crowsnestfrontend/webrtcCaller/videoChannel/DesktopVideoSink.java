package com.crowsnestfrontend.webrtcCaller.videoChannel;

import com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper;
import dev.onvoid.webrtc.media.FourCC;
import dev.onvoid.webrtc.media.video.VideoBufferConverter;
import dev.onvoid.webrtc.media.video.VideoFrame;
import dev.onvoid.webrtc.media.video.VideoFrameBuffer;
import dev.onvoid.webrtc.media.video.VideoTrackSink;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;

public class DesktopVideoSink  implements VideoTrackSink {


    private static final long LOG_INTERVAL_MS = 1000;
    private int frameCount = 0;
    private long lastLogTime = System.currentTimeMillis();

    // Color correction parameters

    // White balance control

    public DesktopVideoSink() { }


    @Override
    public void onVideoFrame(VideoFrame frame) {
        frameCount++;
        long now = System.currentTimeMillis();

        if (now - lastLogTime >= LOG_INTERVAL_MS) {
            System.out.printf("Frames: %d in %.2f s; last frame: %dx%d rot=%d ts=%dms%n",
                    frameCount, (now - lastLogTime) / 1000.0,
                    frame.buffer.getWidth(), frame.buffer.getHeight(),
                    frame.rotation, frame.timestampNs / 1_000_000);
            frameCount = 0;
            lastLogTime = now;
        }

        try {
            VideoFrameBuffer frameBuffer = frame.buffer;
            int frameWidth = frameBuffer.getWidth();
            int frameHeight = frameBuffer.getHeight();

            // Create a BufferedImage with ABGR format (compatible with RGBA conversion)
            BufferedImage image = new BufferedImage(frameWidth, frameHeight, BufferedImage.TYPE_4BYTE_ABGR);

            // Get the underlying byte array from the BufferedImage
            byte[] imageBuffer = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();

            // Convert the frame buffer from I420 format to RGBA format
            VideoBufferConverter.convertFromI420(frameBuffer, imageBuffer, FourCC.RGBA);
            // Convert to JavaFX Image
            Image fxImage = SwingFXUtils.toFXImage(image, null);

            if(GlobalResourceKeeper.controller!=null){
                Platform.runLater(() ->{
                    GlobalResourceKeeper.controller.screenShare.ScreenImage.setImage(fxImage);


                });

            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            frame.release(); // free frame buffer
        }
    }

}
