package com.crowsnestfrontend.forum;


import com.comment.commentData;
import com.comment.commentDataRequest;
import com.comment.commentEdit;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.UserStream.constantStream;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.stage.Popup;

import java.io.IOException;

public class commentPopUp extends StackPane {

    public int postID;
    @FXML
    public Button sendButton;
    @FXML
    public Button closeButton;

    @FXML
    public TextField replyMessageField;


    public commentPopUp(int postID , Popup popup){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("customeAlertBox.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.postID=postID;

        replyMessageField.setOnKeyPressed((event)->{

            if(event.getCode()== KeyCode.ENTER){
                Platform.runLater(popup::hide);

                if(replyMessageField.getText().isBlank()){
                    return;
                }
                constantStream.payloadBlockingQueue.add(new commentData(Owner.nameId , this.postID ,
                        replyMessageField.getText() ,"" ,-1));

                //ZonedDateTime now1=ZonedDateTime.now(ZoneOffset.UTC);
                //String formattedTime = now1.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))+" UTC";

                //messageListView.getItems().add(new Message(writeTextField.getText(), true, formattedTime ,90 ));

                Platform.runLater(()->{
                    replyMessageField.clear();
                });

            }
        });

        sendButton.setOnMouseClicked(event -> {

            if(replyMessageField.getText().trim().isEmpty()){
                return;
            }
            constantStream.payloadBlockingQueue.add(new commentData(Owner.nameId , this.postID ,
                    replyMessageField.getText() ,"" ,-1));

            Platform.runLater(()->{
                popup.hide();

                replyMessageField.clear();


            });
        });

        closeButton.setOnMouseClicked(event -> {
            Platform.runLater(popup::hide);
        });

    }



    public commentPopUp(int postID, Popup popup, int flag , String str){
        System.out.println("second constructor called");
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("customeAlertBox.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.postID=postID;

        if(replyMessageField!=null){
            replyMessageField.setText(str);
        }
        replyMessageField.setOnKeyPressed((event)->{

            if(event.getCode()== KeyCode.ENTER){
                Platform.runLater(popup::hide);

                if(replyMessageField.getText().isBlank()){
                    return;
                }
                constantStream.payloadBlockingQueue.add(new commentEdit(Owner.nameId , this.postID ,flag,
                        replyMessageField.getText() ));


                //ZonedDateTime now1=ZonedDateTime.now(ZoneOffset.UTC);
                //String formattedTime = now1.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))+" UTC";

                //messageListView.getItems().add(new Message(writeTextField.getText(), true, formattedTime ,90 ));

                Platform.runLater(()->{
                    replyMessageField.clear();
                });

            }
        });

        if(sendButton!=null){

            sendButton.setOnMouseClicked((e)->{

                if(replyMessageField.getText().trim().isEmpty()){
                    return;
                }
                constantStream.payloadBlockingQueue.add(new commentEdit(Owner.nameId , this.postID ,flag,
                        replyMessageField.getText() ));

                Platform.runLater(()->{
                    popup.hide();

                    replyMessageField.clear();


                });
            });
        }
        closeButton.setOnMouseClicked(event -> {
            Platform.runLater(popup::hide);
        });
    }
}
