package com.crowsnestfrontend.forum;

import com.PostFile.EditFile;
import com.PostFile.PostData;
import com.PostFile.getPostData;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.forum.MarkDownCodeEditor.MarkDownCodeEditor;
import com.crowsnestfrontend.forum.writePost.WritePost;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Files;

public class EditPostClass extends VBox {

    public static EditPostClass postal;

    public static EditPostClass initialize(getPostData post){
        if(postal==null){
            postal=new EditPostClass(post);
            forumViewScene.jk().controller.stackData.getChildren().add(postal);
        }
        postal.PostHeader.setText(post.PostTitle);
        postal.PostDescription.setText(post.PostDescription);
        postal.codeEditor.replaceText(getContentsOfTheFile(post.fileContent));
        return postal;
    }
    @FXML
    public Button DiscardButton;
    @FXML
    public Button Post;
    @FXML
    public Button addImage;
    @FXML
    public TextField PostHeader;
    @FXML
    public TextField PostDescription;
    @FXML
    public Button preViewThePostButton;

    MarkDownCodeEditor codeEditor;

    Stage stage = new Stage();


    public EditPostClass(getPostData data){
        stage.initOwner(SceneManager.globalStage);
        Scene scene = new Scene(preViewShower.initialize());
        stage.setScene(scene);
        stage.initModality(Modality.NONE);

        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.
                class.getResource("writePost.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        this.codeEditor=new MarkDownCodeEditor();
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(DiscardButton!=null){
            DiscardButton.setOnMouseClicked((e)->{
                PostHeader.clear();
                PostDescription.clear();
                this.toBack();


            });
        }
        if(PostHeader!=null){
            PostHeader.setText(data.PostTitle);

        }

        if(PostDescription!=null){
            System.out.println("-----> "+data.PostDescription);
            PostDescription.setText(data.PostDescription);

        }
        this.codeEditor.replaceText(getContentsOfTheFile(data.fileContent));


        if(Post!=null){
            Post.setOnMouseClicked((e)->{

                Thread.startVirtualThread(()->{
                    if(PostHeader.getText().isBlank() || PostDescription.getText().isBlank()){
                        return;
                    }
                    System.out.println("edit post was called ");
                    String title=PostHeader.getText();
                    String description=PostDescription.getText();
                    String markDownCode =codeEditor.getText();
                    byte[] byte1=new byte[0];
                    File Folder=new File("Posts");
                    data.PostTitle=title;
                    data.PostDescription=description;

                    try{
                        Folder.mkdir();
                    }catch (Exception e1){
                        System.out.println(e1.getMessage());
                    }
                    File temp=new File("Posts/temp.md");
                    try(FileOutputStream fs=new FileOutputStream(temp)) {
                        temp.createNewFile();
                        fs.write(markDownCode.getBytes());

                    } catch (FileNotFoundException ex) {
                        throw new RuntimeException(ex);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }

                    try(FileInputStream fs = new FileInputStream(temp)){
                        byte1= Files.readAllBytes(temp.toPath()) ;

                    }catch (Exception e2 ){
                        System.out.println("encoded unsuccessful");
                    }

                    try{
                        temp.delete();
                    }catch (Exception e1 ){
                        e1.printStackTrace();
                    }

                    data.fileContent=byte1;
                    EditFile  data2= new EditFile(data.id,Owner.nameId, title,description,byte1);
                    constantStream.payloadBlockingQueue.add(
                            data2
                    );
                    Platform.runLater(()->{
                        PostHeader.clear();
                        PostDescription.clear();
                        codeEditor.clear();

                        forumViewScene.jk().controller.mainPostHolder.toFront();
                    });

                });
            });
        }


        this.getChildren().add(codeEditor);


        if(addImage!=null){
            addImage.setOnMouseClicked((e)->{

                WritePost.onUploadButton(e ,this , codeEditor);

            });

        }

        if(preViewThePostButton!=null){
            preViewThePostButton.setOnMouseClicked((e)->{
                Platform.runLater(() -> {

                    preViewShower.initialize().showContent(PostHeader.getText(), PostDescription.getText(), codeEditor.getText());
                    stage.show();
                });
            });
        }


    }

    public static String getContentsOfTheFile(byte[] bytes){
        File file = new File("tempFolder");
        String y="";
            try{
                file.mkdir();


                File file2=new File("tempFolder/post.md");
                file2.createNewFile();

                try(FileOutputStream fs=new FileOutputStream(file2) ;
                    ){
                    fs.write(bytes);

                }catch (Exception e){
                    e.printStackTrace();
                }

                y=Files.readString(file2.toPath());
                System.out.println(y);
                file2.delete();
            }catch (Exception e){
                e.printStackTrace();
            }

            return y;
    }
}
