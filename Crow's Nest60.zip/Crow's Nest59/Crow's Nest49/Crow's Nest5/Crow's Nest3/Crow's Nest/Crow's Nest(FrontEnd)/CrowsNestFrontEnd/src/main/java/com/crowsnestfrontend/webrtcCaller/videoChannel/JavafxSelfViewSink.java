package com.crowsnestfrontend.webrtcCaller.videoChannel;

import com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper;
import dev.onvoid.webrtc.media.FourCC;
import dev.onvoid.webrtc.media.video.VideoBufferConverter;
import dev.onvoid.webrtc.media.video.VideoFrame;
import dev.onvoid.webrtc.media.video.VideoFrameBuffer;
import dev.onvoid.webrtc.media.video.VideoTrackSink;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.PixelFormat;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.nio.ByteBuffer;
import java.util.Locale;

public class JavafxSelfViewSink implements VideoTrackSink {

    private WritableImage writableImage;
    private byte[] rgbaBuffer;
    private int[] argbBuffer;

    private static final long LOG_INTERVAL_MS = 1000;
    private int frameCount = 0;
    private long lastLogTime = System.currentTimeMillis();

    // Color correction parameters
    private boolean enableColorCorrection = true;
    private double brightness = 1.0;
    private double contrast = 1.0;
    private double saturation = 1.0;

    // White balance control
    private boolean enableAutoWhiteBalance = true;
    private double wbClampMin = 0.7;
    private double wbClampMax = 1.3;

    public JavafxSelfViewSink() { }

    public void setEnableColorCorrection(boolean enable) { this.enableColorCorrection = enable; }
    public void setBrightness(double brightness) { this.brightness = brightness; }
    public void setContrast(double contrast) { this.contrast = contrast; }
    public void setSaturation(double saturation) { this.saturation = saturation; }
    public void setEnableAutoWhiteBalance(boolean enable) { this.enableAutoWhiteBalance = enable; }
    public void setWbClamp(double min, double max) { this.wbClampMin = min; this.wbClampMax = max; }

    @Override
    public void onVideoFrame(VideoFrame frame) {
        frameCount++;
        long now = System.currentTimeMillis();

        if (now - lastLogTime >= LOG_INTERVAL_MS) {
            System.out.printf("Frames: %d in %.2f s; last frame: %dx%d rot=%d ts=%dms%n",
                    frameCount, (now - lastLogTime) / 1000.0,
                    frame.buffer.getWidth(), frame.buffer.getHeight(),
                    frame.rotation, frame.timestampNs / 1_000_000);
            frameCount = 0;
            lastLogTime = now;
        }

        try {
            VideoFrameBuffer frameBuffer = frame.buffer;
            int frameWidth = frameBuffer.getWidth();
            int frameHeight = frameBuffer.getHeight();

            // Create a BufferedImage with ABGR format (compatible with RGBA conversion)
            BufferedImage image = new BufferedImage(frameWidth, frameHeight, BufferedImage.TYPE_4BYTE_ABGR);

            // Get the underlying byte array from the BufferedImage
            byte[] imageBuffer = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();

            // Convert the frame buffer from I420 format to RGBA format
            VideoBufferConverter.convertFromI420(frameBuffer, imageBuffer, FourCC.RGBA);
            // Convert to JavaFX Image
            Image fxImage = SwingFXUtils.toFXImage(image, null);

            if(GlobalResourceKeeper.controller!=null){
                Platform.runLater(() ->{
                    GlobalResourceKeeper.controller.selfView.setImage(fxImage);


                });

            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            frame.release(); // free frame buffer
        }
    }

    // -------------------------
    // Helper methods
    // -------------------------

    private void convertRgbaToArgb(byte[] rgbaBuffer, int[] argbBuffer) {
        for (int i = 0, j = 0; i < rgbaBuffer.length; i += 4, j++) {
            int r = rgbaBuffer[i] & 0xFF;
            int g = rgbaBuffer[i + 1] & 0xFF;
            int b = rgbaBuffer[i + 2] & 0xFF;
            int a = rgbaBuffer[i + 3] & 0xFF;

            // Convert RGBA to ARGB
            argbBuffer[j] = (a << 24) | (r << 16) | (g << 8) | b;
        }
    }

    private void applyColorCorrection(int[] pixels, double brightness, double contrast, double saturation) {
        for (int i = 0; i < pixels.length; i++) {
            int px = pixels[i];
            int a = (px >> 24) & 0xFF;
            int r = (px >> 16) & 0xFF;
            int g = (px >> 8) & 0xFF;
            int b = px & 0xFF;

            // Apply brightness and contrast
            r = clampInt((int) ((r - 128) * contrast + 128 * brightness), 0, 255);
            g = clampInt((int) ((g - 128) * contrast + 128 * brightness), 0, 255);
            b = clampInt((int) ((b - 128) * contrast + 128 * brightness), 0, 255);

            // Apply saturation
            int gray = (r + g + b) / 3;
            r = clampInt((int) (gray + saturation * (r - gray)), 0, 255);
            g = clampInt((int) (gray + saturation * (g - gray)), 0, 255);
            b = clampInt((int) (gray + saturation * (b - gray)), 0, 255);

            pixels[i] = (a << 24) | (r << 16) | (g << 8) | b;
        }
    }

    private void applyAutoWhiteBalance(int[] pixels, int samplePixels) {
        int sample = Math.min(pixels.length, samplePixels);
        long sumR = 0, sumG = 0, sumB = 0;
        for (int i = 0; i < sample; i++) {
            int px = pixels[i];
            sumR += (px >> 16) & 0xFF;
            sumG += (px >> 8) & 0xFF;
            sumB += px & 0xFF;
        }
        double avgR = sumR / (double) sample;
        double avgG = sumG / (double) sample;
        double avgB = sumB / (double) sample;
        double avgGray = (avgR + avgG + avgB) / 3.0;

        double gR = clamp(avgGray / (avgR + 1e-6), wbClampMin, wbClampMax);
        double gG = clamp(avgGray / (avgG + 1e-6), wbClampMin, wbClampMax);
        double gB = clamp(avgGray / (avgB + 1e-6), wbClampMin, wbClampMax);

        for (int i = 0; i < pixels.length; i++) {
            int px = pixels[i];
            int a = (px >> 24) & 0xFF;
            int r = (px >> 16) & 0xFF;
            int g = (px >> 8) & 0xFF;
            int b = px & 0xFF;

            int nr = clampInt((int) Math.round(r * gR), 0, 255);
            int ng = clampInt((int) Math.round(g * gG), 0, 255);
            int nb = clampInt((int) Math.round(b * gB), 0, 255);

            pixels[i] = (a << 24) | (nr << 16) | (ng << 8) | nb;
        }
    }

    /** Clamp int value to [lo, hi] */
    private static int clampInt(int v, int lo, int hi) {
        if (v < lo) return lo;
        if (v > hi) return hi;
        return v;
    }

    /** Clamp double value to [lo, hi] */
    private static double clamp(double v, double lo, double hi) {
        if (v < lo) return lo;
        if (v > hi) return hi;
        return v;
    }
}