package  com.crowsnestfrontend.webrtcCaller;


import dev.onvoid.webrtc.RTCIceCandidate;
import dev.onvoid.webrtc.RTCSessionDescription;

public interface SignalingChannel {
    void sendOffer(RTCSessionDescription offer);
    void sendAnswer(RTCSessionDescription answer);
    void sendCandidate(RTCIceCandidate candidate);

    void onOffer(java.util.function.Consumer<RTCSessionDescription> callback);
    void onAnswer(java.util.function.Consumer<RTCSessionDescription> callback);
    void onCandidate(java.util.function.Consumer<RTCIceCandidate> callback);
}
