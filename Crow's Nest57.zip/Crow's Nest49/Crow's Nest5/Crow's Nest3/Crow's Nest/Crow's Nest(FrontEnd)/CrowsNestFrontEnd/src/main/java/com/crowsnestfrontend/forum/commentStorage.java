package com.crowsnestfrontend.forum;

import com.PostFile.DeleteFile;
import com.PostFile.getPostData;
import com.comment.commentDataDelete;
import com.comment.commentDataReturn;
import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.Objects;
import java.util.Set;

import com.comment.commentData;

public class commentStorage extends VBox {
    static Image image1=new Image(
            Objects.requireNonNull(MainApplication.class.getResourceAsStream("images/setting.png"))
    );
    static  Image image2=new Image(
            Objects.requireNonNull(MainApplication.class.getResourceAsStream("images/block.png"))
    );
    static  Image image3=new Image(
            Objects.requireNonNull(MainApplication.class.getResourceAsStream("images/writing.png"))
    );

    @FXML
    public ComboBox<ChoiceItem> settingsChoiceBox;

    @FXML public Text commentWriter;
    @FXML public Text publishingDate;
    @FXML public Label commentText;

    public commentStorage(commentDataReturn comment) {
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("PostStorage.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(commentWriter!=null){
            System.out.println("this is the sender name ---> " +comment.senderName);
            this.commentWriter.setText(comment.senderName);
        }
        if(commentText!=null){
            System.out.println("Comment text writer  ---> "+comment.commentDescription);
            this.commentText.setText(comment.commentDescription);

        }



        if (publishingDate != null) publishingDate.setText(comment.time + " UTC");


        if(comment.senderName.equals(Owner.nameId)){
            settingsChoiceBox.getItems().addAll(
                    new ChoiceItem("Option" ,image1),
                    new ChoiceItem("Delete", image2),
                    new ChoiceItem("Edit", image3)
            );
            settingsChoiceBox.setCellFactory(listView -> new ListCell<ChoiceItem>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(ChoiceItem item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                        setText(null);
                        setStyle("");
                    } else {
                        imageView.setImage(item.getImage());
                        imageView.setFitWidth(16);
                        imageView.setFitHeight(16);
                        imageView.setPreserveRatio(true);
                        setGraphic(imageView);
                        setText(item.getName());
                        // dark background + white text
                        setStyle("-fx-background-color: #2e2e2e; -fx-text-fill: white;");
                    }
                }
            });

            settingsChoiceBox.setButtonCell(new ListCell<ChoiceItem>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(ChoiceItem item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                        setText(null);
                        setStyle("");
                    } else {
                        imageView.setImage(item.getImage());
                        imageView.setFitWidth(16);
                        imageView.setFitHeight(16);
                        imageView.setPreserveRatio(true);
                        setGraphic(imageView);
                        setText(item.getName());
                        setStyle("-fx-background-color: #2e2e2e; -fx-text-fill: white;");
                    }
                }
            });

            if (!settingsChoiceBox.getItems().isEmpty()) {
                settingsChoiceBox.getSelectionModel().selectFirst();
            }

            settingsChoiceBox.setOnAction(ev -> {
                ChoiceItem sel = settingsChoiceBox.getSelectionModel().getSelectedItem();
                if (sel != null) {

                    if(sel.getName().equals("Delete")){
                        System.out.println("Selected: " + sel.getName());
                        constantStream.payloadBlockingQueue.add(new commentDataDelete(comment.senderName , comment.PostID ,comment.commentID));
                        forumViewScene.jk().controller.contentBox.getChildren().remove(this);
                        settingsChoiceBox.getSelectionModel().selectFirst();
                    }
                    else{

//                        var t=EditPostClass.initialize(post );
//                        t.toFront();
//                        settingsChoiceBox.getSelectionModel().selectFirst();
                    }

                }

            });
        }
        else{
            settingsChoiceBox.setManaged(false);
            settingsChoiceBox.setVisible(false);
        }




    }


}
