package com.PostFile;


import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;


public class PostData extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 12491L;

    public String senderName ;
    public String PostTitle;
    public String PostDescription;
    public byte[] fileContent;

    public PostData(String senderName ,
     String PostTitle , String PostDescription , byte[] fileContent){
        super(senderName);

        this.senderName=senderName;
        this.PostTitle=PostTitle;
        this.PostDescription=PostDescription;
        this.fileContent=fileContent;

    }   
}
