package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class MessagePayload extends payload implements Serializable {

    @Serial
    private static final long serialVersionUID=909L;

    public  String sender;
    public  final int messageID;
    public  final String text;
    public final int reactionType;
    public final String dateTime;
    public int wasDeletedByOrginalWriter=0;
    public int wasDeletedByReceiver=0;
    public MessagePayload(String clientName,int messageID, String text, int reactionType, String dateTime) {
        super(clientName);
        this.messageID = messageID;
        this.text = text;
        this.reactionType = reactionType;
        this.dateTime = dateTime;
    }
    
    public MessagePayload(String clientName ,int messageID, String sender , int wasDeletedByOrginalWriter , int wasDeletedByReceiver,String text){
            this(clientName , messageID ,text,0 , ""  );
            this.wasDeletedByOrginalWriter=wasDeletedByOrginalWriter;
            this.wasDeletedByReceiver=wasDeletedByReceiver;
            this.sender=sender;
    }
    

}
