package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.deleteMessage;
import com.crowsnestfrontend.SerializedClasses.payloadMessageReaction;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.controllers.mainSceneController;
import com.sun.tools.javac.Main;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.IntegerBinding;
import javafx.beans.value.ChangeListener;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.NodeOrientation;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.StageStyle;

import java.io.IOException;

import static com.crowsnestfrontend.UserStream.constantStream.payloadBlockingQueue;

public class MessageCell extends ListCell<Message> {
    @FXML
    private Label messageLabel;

    @FXML
    private HBox OwnerMessage;

    @FXML
    private Label BubbleTime;

    @FXML
    private HBox reactionPanel;

    @FXML
    private ImageView reactionImage;

    @FXML
    private ImageView neutral;

    @FXML
    private ImageView haha;

    @FXML
    private ImageView love;

    @FXML
    private ImageView angry;
    @FXML
    private ImageView sad;

    private FXMLLoader loader;

    @FXML
    private Label replyText;
    @FXML
    private ImageView deleteButton;
    private Message currentMessage;

    private static final Image IMG_NEUTRAL = new Image(MainApplication.class.getResourceAsStream("images/neutral.png"));
    private static final Image IMG_HAHA = new Image(MainApplication.class.getResourceAsStream("images/face(haha).png"));
    private static final Image IMG_LOVE = new Image(MainApplication.class.getResourceAsStream("images/heart-eyes.png"));
    private static final Image IMG_ANGRY = new Image(MainApplication.class.getResourceAsStream("images/angry.png"));
    private static final Image IMG_SAD= new Image(MainApplication.class.getResourceAsStream("images/sad.png")) ;

    private final ChangeListener<Number> reactionListener = (obs, oldVal, newVal) -> {
        int rt = newVal == null ? 0 : newVal.intValue();
        switch (rt) {
            case 1 -> reactionImage.setImage(IMG_HAHA);
            case 2 -> reactionImage.setImage(IMG_LOVE);
            case 3 -> reactionImage.setImage(IMG_ANGRY);
            case 4 -> reactionImage.setImage(IMG_SAD);
            default -> reactionImage.setImage(IMG_NEUTRAL);
        }
    };

    @Override
    protected void updateItem(Message message, boolean empty) {
        super.updateItem(message, empty);

        if (empty || message == null) {
            if (currentMessage != null) {
                try {
                    currentMessage.reaction_type.removeListener(reactionListener);
                } catch (Exception ignored) {}
            }
            currentMessage = null;
            loader = null;
            setText(null);
            setGraphic(null);
            return;
        }

        if (currentMessage != null && currentMessage != message) {
            try {
                currentMessage.reaction_type.removeListener(reactionListener);
            } catch (Exception ignored) {}
        }

        this.currentMessage = message;

        if (loader == null) {
            loader = new FXMLLoader(MainApplication.class.getResource("chatBubble.fxml"));
            loader.setController(this);
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        messageLabel.setText(message.getText());
        BubbleTime.setText(message.formattedTime);
        message.index=this.getIndex();
        if(message.isOwnMessage()){
            reactionImage.setMouseTransparent(true);

            OwnerMessage.setStyle("-fx-alignment: center-right;");
            messageLabel.setStyle("-fx-background-color: #DCF8C6; -fx-padding: 8px; -fx-background-radius: 12px;");
        }
        else{
            OwnerMessage.setStyle("-fx-alignment: center-left;");
            messageLabel.setStyle("-fx-background-color: #FFFFFF; -fx-padding: 8px; -fx-background-radius: 12px;");
        }
        if (message.isOwnMessage() && (message.isDeletedBySender.get()==1 || message.isDeletedByReceiver.get()==1)) {


            if(message.isDeletedBySender.get() ==1){

                messageLabel.setText("You deleted this message");

            }
            reactionImage.setVisible(false);
            reactionImage.setManaged(false);
            reactionPanel.setManaged(false);
            reactionPanel.setVisible(false);
            replyText.setVisible(false);
            replyText.setManaged(false);
            BubbleTime.setVisible(false);
            BubbleTime.setManaged(false);

        }
        else if((message.isDeletedBySender.get()==1 || message.isDeletedByReceiver.get()==1)){

                String data="message was deleted";

                if(message.isDeletedByReceiver.get()==1){
                    data ="You deleted this message";
                }
                messageLabel.setText(data);
                reactionImage.setVisible(false);
                reactionImage.setManaged(false);
                reactionPanel.setManaged(false);
                reactionPanel.setVisible(false);
                replyText.setVisible(false);
                replyText.setManaged(false);
                BubbleTime.setVisible(false);
                BubbleTime.setManaged(false);


        }
        replyText.setOnMouseClicked(event -> {
            Dialog<Void> dialog = new Dialog<>();
            dialog.initStyle(StageStyle.TRANSPARENT);
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.setDialogPane(new DialogPane());
            dialog.getDialogPane().getButtonTypes().add(new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE));

            MessageReply messageReply = new MessageReply(message.messageID, ()->{
                dialog.close();

            });
            dialog.getDialogPane().setContent(messageReply);
            dialog.show();
        });

        deleteButton.setOnMouseClicked((event)->{
            String sender="";
            String receiver="";
            if ((message.ownMessage)) {
                sender=Owner.nameId;
                message.isDeletedBySender.set(1);
                receiver=SelectedUserData.name.get();
            }
            else {
                sender=SelectedUserData.name.get();
                message.isDeletedByReceiver.set(1);
                receiver=SelectedUserData.name.get();
            }

            deleteMessage obj = new deleteMessage(message.messageID,
                                                    Owner.nameId ,sender
                                                    ,receiver);

            MessagePayloadProcessing.deleteMessage(obj);
            payloadBlockingQueue.add(obj);

        });

        reactionPanel.setVisible(false);
        reactionPanel.setManaged(false);
        reactionImage.setOnMouseClicked(e -> {
            reactionPanel.setVisible(!reactionPanel.isVisible());
            reactionPanel.setManaged(reactionPanel.isVisible());
        });

        try {
            currentMessage.reaction_type.addListener(reactionListener);
        }
        catch (Exception ignored) {}

        try {
            Number currentVal = currentMessage.reaction_type.getValue();
            reactionListener.changed(null, null, currentVal == null ? 0 : currentVal);
        } catch (Exception ignored) {
            try {
                reactionListener.changed(null, null, currentMessage.reaction_type.get());
            } catch (Exception ignored2) {}
        }

        neutral.setOnMouseClicked(e -> setReaction(currentMessage.messageID, 0, IMG_NEUTRAL));
        haha.setOnMouseClicked(e -> setReaction(currentMessage.messageID, 1, IMG_HAHA));
        love.setOnMouseClicked(e -> setReaction(currentMessage.messageID, 2, IMG_LOVE));
        angry.setOnMouseClicked(e -> setReaction(currentMessage.messageID, 3, IMG_ANGRY));
        sad.setOnMouseClicked(e -> setReaction(currentMessage.messageID, 4, IMG_SAD));

        message.isDeletedBySender.addListener((observable ,a,b)->{
            if(message.isOwnMessage()){
                messageLabel.setText("You deleted this message");
            }
            else{
                messageLabel.setText("This message was deleted");
            }
            reactionImage.setVisible(false);
            reactionImage.setManaged(false);
            reactionPanel.setManaged(false);
            reactionPanel.setVisible(false);
            replyText.setVisible(false);
            replyText.setManaged(false);
            BubbleTime.setVisible(false);
            BubbleTime.setManaged(false);
        });

        message.isDeletedByReceiver.addListener((a,b,c)->{
            if(!message.isOwnMessage()){
                messageLabel.setText("You deleted this message");
                BubbleTime.setVisible(false);
                BubbleTime.setManaged(false);
            }
            else{

            }
            reactionImage.setVisible(false);
            reactionImage.setManaged(false);
            reactionPanel.setManaged(false);
            reactionPanel.setVisible(false);
            replyText.setVisible(false);
            replyText.setManaged(false);

        });

        setText(null);
        setGraphic(OwnerMessage);
    }



    private void setReaction(int messageID, int reaction, Image tempImage) {
        if (currentMessage == null) return;

        if (currentMessage.reaction_type.get() == reaction) {
            reactionPanel.setVisible(false);
            reactionPanel.setManaged(false);
            return;
        }

        try {
            MessagePayloadProcessing.setMessageIDreaction(messageID, reaction);
        } catch (Exception e) {
            e.printStackTrace();
        }

        payloadBlockingQueue.add(new payloadMessageReaction(Owner.nameId, mainSceneController.name, messageID, reaction));

        Runnable uiUpdate = () -> {
            reactionImage.setImage(tempImage);
            currentMessage.reaction_type.set(reaction);
            reactionPanel.setVisible(false);
            reactionPanel.setManaged(false);
        };

        if (Platform.isFxApplicationThread()) {
            uiUpdate.run();
        } else {
            Platform.runLater(uiUpdate);
        }
    }

}
