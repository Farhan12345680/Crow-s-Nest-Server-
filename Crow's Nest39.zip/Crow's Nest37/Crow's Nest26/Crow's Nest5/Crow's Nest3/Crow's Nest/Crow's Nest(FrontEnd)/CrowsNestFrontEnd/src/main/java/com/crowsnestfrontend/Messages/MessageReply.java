package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.UserStream.constantStream;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;


import java.io.IOException;

public class MessageReply extends StackPane {
    public Runnable runner;

    int messageReplyID;
    @FXML
    public TextField replyMessageField;

    @FXML
    public Button sendButton;

    @FXML
    public Button closeButton;

    public MessageReply(int messageReplyID ,Runnable r){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("customeAlertBox.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        this.messageReplyID=messageReplyID;
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.runner=r;

        closeButton.setOnMouseClicked((a)->{

            if(runner!=null){
                runner.run();
            }

        });

        sendButton.setOnMouseClicked((event)->{
            constantStream.payloadBlockingQueue.add(new com.crowsnestfrontend.SerializedClasses.Message(
                    Owner.nameId,
                    SelectedUserData.name.get(),
                    replyMessageField.getText(),
                    0,0)
            );
            //ZonedDateTime now1=ZonedDateTime.now(ZoneOffset.UTC);
            //String formattedTime = now1.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))+" UTC";

            //messageListView.getItems().add(new Message(writeTextField.getText(), true, formattedTime ,90 ));

            Platform.runLater(()->{
                replyMessageField.clear();

            });
            if(runner!=null){
                System.out.println("Not null");
                runner.run();
            }
        });

        replyMessageField.setOnKeyPressed( (event)->{
                    if(event.getCode()== KeyCode.ENTER){
                        if(replyMessageField.getText().trim().isEmpty()){
                            return;
                        }

                        constantStream.payloadBlockingQueue.add(new com.crowsnestfrontend.SerializedClasses.Message(
                                Owner.nameId,
                                SelectedUserData.name.get(),
                                replyMessageField.getText(),
                                0,0)
                        );
                        //ZonedDateTime now1=ZonedDateTime.now(ZoneOffset.UTC);
                        //String formattedTime = now1.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))+" UTC";

                        //messageListView.getItems().add(new Message(writeTextField.getText(), true, formattedTime ,90 ));

                        Platform.runLater(()->{
                            replyMessageField.clear();

                        });
                        if(runner!=null){
                            System.out.println("Not null");
                            runner.run();
                        }

                    }
                } );
    }



}
