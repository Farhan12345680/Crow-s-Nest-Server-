package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.MessagePayload;
import com.crowsnestfrontend.SerializedClasses.deleteMessage;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import javafx.application.Platform;

import java.sql.*;

public class MessagePayloadProcessing {


    public static void messageLoader(MessagePayload msgPayload){

        String sqlString= """
                INSERT OR IGNORE INTO Messages(owner
                ,sender,
                 receiver
                ,text
                ,TextMessageID
                ,reaction,
                getTime
                ,isReplying ,isDeletedBySender,isDeletedByReceiver ) VALUES(?,?,? ,? ,?,?,?,?,?,?);
                """;


        try(Connection conn= DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
            PreparedStatement ps=conn.prepareStatement(sqlString);){

            ps.setInt(1 ,(msgPayload.clientName.equals(Owner.nameId))?1:0);
            ps.setString(2,msgPayload.clientName);
            ps.setString(3,msgPayload.sender);
            ps.setString(4,msgPayload.text);
            ps.setInt(5,msgPayload.messageID);
            ps.setInt(6,msgPayload.reactionType);
            ps.setString(7,msgPayload.dateTime);
            ps.setInt(8,0);
            ps.setInt(9 , msgPayload.wasDeletedByOrginalWriter);
            ps.setInt(10 , msgPayload.wasDeletedByReceiver);
            ps.executeUpdate();

            if(msgPayload.clientName.equals(Owner.nameId)){
                Message msg=new Message(msgPayload.text,true ,msgPayload.dateTime+" UTC", msgPayload.messageID
                        ,0,msgPayload.reactionType ,0
                        ,0 );

                Platform.runLater(() -> {
                    SceneManager.mainSceneContrller.messageListView.getItems().add(
                            msg
                    );
                });
            }else {
                if(Owner.current.containsKey(msgPayload.clientName)){
                    Owner.current.get(msgPayload.clientName).UpMessageCount();

                }



                if(SelectedUserData.name.get().equals(msgPayload.clientName)){

                        Message msg2=new Message(msgPayload.text,false ,msgPayload.dateTime+" UTC", msgPayload.messageID
                                ,0,msgPayload.reactionType ,0
                                ,0 );
                        Platform.runLater(() -> {
                            SceneManager.mainSceneContrller.messageListView.getItems().add(
                                    msg2
                            );
                        });
                    }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("A problem executing");
        }
    }

    public static void  messagePayloadProcessingUserBased(String name){
        Platform.runLater(()->{
            SceneManager.mainSceneContrller.messageListView.getItems().clear();
        });
        String sqlString= """
                SELECT owner, sender ,receiver , text , TextMessageID , reaction , getTime
                ,isReplying,isDeletedBySender,isDeletedByReceiver
                 FROM Messages WHERE sender=? OR receiver=? ORDER BY TextMessageID ASC;
                """;
        try(Connection conn=DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
            PreparedStatement  ps = conn.prepareStatement(sqlString)){

            ps.setString(1,name);
            ps.setString(2,name);
            ResultSet rs=ps.executeQuery();

            while(rs.next()){

                Message msg=new Message(rs.getString(4 ),rs.getInt(1) ==1 ,rs.getString(7)+" UTC",
                        rs.getInt("TextMessageID") ,0,rs.getInt("reaction") ,rs.getInt("isDeletedBySender")
                        ,rs.getInt("isDeletedByReceiver") );

                Platform.runLater(() -> {
                    SceneManager.mainSceneContrller.messageListView.getItems().add(
                            msg
                    );
            });
        } }catch (Exception e){
            e.printStackTrace();
        }

    }

    public static void setMessageIDreaction(int MessageID , int reaction) throws InterruptedException {

        String ss= """
                UPDATE Messages SET reaction=? WHERE  TextMessageID=?;
                """;



        try(Connection conn= DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString)
            ;PreparedStatement ps = conn.prepareStatement(ss)){

            ps.setInt(1,reaction);
            ps.setInt(2,MessageID);

            int i=ps.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void deleteMessage(deleteMessage  del){

        String data= """
                Select sender from  Messages WHERE  TextMessageID=?;
                """;
        String senderData="";
        try(Connection conn =DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
            PreparedStatement ps = conn.prepareStatement(data)){
            ps.setInt(1 , del.messageID);
            ResultSet rs=ps.executeQuery();
            rs.next();
            senderData=rs.getString("sender");

        }catch (SQLException e){
            e.printStackTrace();
        }


        if(senderData.equals(del.initiator)){
            String ss2="Update Messages SET isDeletedBySender=1 WHERE TextMessageID=? ";
            try(Connection conn =DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
                PreparedStatement ps = conn.prepareStatement(ss2)){
                ps.setInt(1 , del.messageID);
                ps.executeUpdate();

            }catch (SQLException e){
                e.printStackTrace();
            }
        }else{
            String ss2="Update Messages SET isDeletedByReceiver=1 WHERE TextMessageID=? ";
            try(Connection conn =DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
                PreparedStatement ps = conn.prepareStatement(ss2)){
                ps.setInt(1 , del.messageID);
                ps.executeUpdate();

            }catch (SQLException e){
                e.printStackTrace();
            }
        }
    }

}
