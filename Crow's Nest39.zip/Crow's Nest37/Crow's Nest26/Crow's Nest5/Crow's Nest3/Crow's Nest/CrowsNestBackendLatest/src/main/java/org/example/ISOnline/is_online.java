package org.example.ISOnline;

import java.util.concurrent.ConcurrentHashMap;

public class is_online {
    public static ConcurrentHashMap<String , Integer>active_users
            =new ConcurrentHashMap<String , Integer>();

}
