package com.PostFile;


import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;


public class getMyPost extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 12498L;

    public String senderName ;
    public int StartingRange;
    public int EndingRange;


    public getMyPost(String senderName , int StartingRange ,int EndingRange){
        super(senderName);
        this.senderName=senderName;
        this.StartingRange=StartingRange;
        this.EndingRange=EndingRange;
    } 
}
