package com.comment;

import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;

import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;
import java.io.Serializable;

public class commentDataSendingEnder extends payload implements Serializable {

    @Serial
    private static final long serialVersionUID = 13491L;

    public String senderName;
    public int PostID;

    public commentDataSendingEnder(String senderName,
            int PostID) {
        super(senderName);

        this.senderName = senderName;
        this.PostID = PostID;
    }
}
