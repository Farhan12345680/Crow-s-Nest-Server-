package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class textChange implements Serializable{
    @Serial
    private static final long serialVersionUID = 1710L;
    

    public int pos ;
    public String  inserted ;
    public String removed;

    public textChange(int pos , String inserted , String removed){
        this.pos=pos;
        this.inserted=inserted;
        this.removed=removed;
    }
    
}
