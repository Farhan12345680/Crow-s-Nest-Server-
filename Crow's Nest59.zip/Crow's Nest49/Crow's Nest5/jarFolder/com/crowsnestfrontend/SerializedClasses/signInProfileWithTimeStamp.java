package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class signInProfileWithTimeStamp extends SignInProfile implements Serializable {
    @Serial
    private static final long serialVersionUID=477L;

    public final String UTCtimeZone;

    public signInProfileWithTimeStamp(String name , String password , String UTCtimeZone ){
        super(name , password);
        this.UTCtimeZone=UTCtimeZone;
    }

    

}
