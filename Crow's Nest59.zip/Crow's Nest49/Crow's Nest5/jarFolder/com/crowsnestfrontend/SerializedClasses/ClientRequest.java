package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class ClientRequest implements Serializable {
    @Serial
    private static final long serialVersionUID = 2L;
    private final int requestNumber;
    

    public ClientRequest(int requestNumber) {
        this.requestNumber = requestNumber;
    }

    public int getRequestNumber() {
        return requestNumber;
    }


}
