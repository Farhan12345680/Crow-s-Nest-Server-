package com.crowsnestfrontend.forum.MarkDownCodeEditor;

import javafx.scene.text.Font;
import org.fxmisc.richtext.InlineCssTextArea;
import org.fxmisc.richtext.LineNumberFactory;

public class MarkDownCodeEditor extends InlineCssTextArea {

        public MarkDownCodeEditor() {
                this.setAutoHeight(true);

                this.setStyle(
                        "-fx-background-color: #495057; " +
                                "-fx-fill: #ffffff" +
                                "-fx-background-radius: 6;" +
                                "-fx-padding: 6 14;" +
                                "-fx-font-size: 20;" +
                                "-fx-font-family: 'Monospaced'"

                );

                Font monospacedFont = Font.font("Monospaced", 14);

                this.setParagraphGraphicFactory(LineNumberFactory.get(this));

                String initialText = "<!-- This is an HTML comment in Markdown -->\n";
                this.replaceText(initialText);


                String defaultTextStyle = "-fx-fill: #ffffff;";

                this.setStyle(0, initialText.length(), defaultTextStyle);

        }
}