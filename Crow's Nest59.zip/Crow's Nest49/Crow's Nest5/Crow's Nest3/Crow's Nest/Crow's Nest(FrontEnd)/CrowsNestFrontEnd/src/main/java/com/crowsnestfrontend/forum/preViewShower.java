package com.crowsnestfrontend.forum;

import com.PostFile.getPostData;
import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.Owner;
import com.vladsch.flexmark.html.HtmlRenderer;
import com.vladsch.flexmark.parser.Parser;
import com.vladsch.flexmark.util.ast.Node;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;

import java.io.IOException;

public class preViewShower extends HBox {
    public static preViewShower preViewShower1;

    public static preViewShower initialize() {
        if (preViewShower1 == null) {
            preViewShower1 = new preViewShower();

        }
        return preViewShower1;
    }

    @FXML
    public WebView markdownContentShower;
    @FXML
    public Button goBack;
    @FXML
    public VBox commentShower;

    public preViewShower() {

        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("markdownFileShower2.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (markdownContentShower != null) {
            markdownContentShower.setContextMenuEnabled(false);
        }
        if (goBack != null) {
            goBack.setOnMouseClicked((e) -> {
                forumViewScene.jk().controller.stackData.getChildren().remove(this);
            });
        }
        if(commentShower!=null){
            commentShower.setManaged(false);
            commentShower.setVisible(false);
        }
    }


    public void showContent(String title , String description ,String text) {
        Thread.startVirtualThread(() -> {

            Parser parser = Parser.builder().build();
            HtmlRenderer renderer = HtmlRenderer.builder().build();

            Node document = parser.parse(text);
            String html = renderer.render(document);


            String styledHtml = String.format("""
                            <!DOCTYPE html>
                            <html>
                            <head>
                                <meta charset="UTF-8">
                                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/5.2.0/github-markdown-dark.min.css">
                                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github-dark.min.css">
                                <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
                                <script>hljs.highlightAll();</script>
                                <style>
                                    body {
                                        box-sizing: border-box;
                                        min-width: 200px;
                                        max-width: 800px;
                                        margin: 0 auto;
                                        padding: 40px;
                                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                                        line-height: 1.6;
                                        background-color: #0d1117;
                                        color: #c9d1d9;
                                    }
                                    .author {
                                        display: flex;
                                        align-items: center;
                                        gap: 15px;
                                        margin-bottom: 20px;
                                    }
                                    .author img {
                                        width: 70px;
                                        height: 70px;
                                        border-radius: 50%%;
                                        object-fit: cover;
                                        box-shadow: 0 2px 8px rgba(0,0,0,0.4);
                                    }
                                    .author-name {
                                        font-size: 22px;
                                        font-weight: 700;
                                        color: #ffffff;
                                    }
                                    h5 {
                                        margin: 0 0 20px 0;
                                        font-size: 14px;
                                        color: #8b949e;
                                    }
                                    h2 {
                                        margin-top: 10px;
                                        font-size: 28px;
                                        color: #ffffff;
                                    }
                                    p {
                                        font-size: 16px;
                                        margin-bottom: 20px;
                                    }
                                    hr {
                                        margin: 40px 0;
                                        border: none;
                                        border-top: 1px solid #30363d;
                                    }
                                    pre {
                                        background-color: #161b22;
                                        padding: 12px;
                                        border-radius: 6px;
                                        overflow-x: auto;
                                        font-size: 14px;
                                    }
                                </style>
                            </head>
                            <body class="markdown-body">
                                <div class="author">
                                    <img src="%s" alt="Author image">
                                    <div class="author-name">%s</div>
                                </div>
                            
                                <h5><i>Publishing date: %s</i></h5>
                            
                                <h2>%s</h2>
                            
                                <p>%s</p>
                                <hr>
                            
                                %s
                            </body>
                            </html>
                            """,
                    localDataBaseGenerator.getUserImageString(Owner.nameId),
                    Owner.nameId,
                    "Current Date",
                    title,
                    description,
                    html
            );


            Platform.runLater(() -> {
                this.markdownContentShower.getEngine().loadContent(styledHtml, "text/html");

            });
        });

    }
}