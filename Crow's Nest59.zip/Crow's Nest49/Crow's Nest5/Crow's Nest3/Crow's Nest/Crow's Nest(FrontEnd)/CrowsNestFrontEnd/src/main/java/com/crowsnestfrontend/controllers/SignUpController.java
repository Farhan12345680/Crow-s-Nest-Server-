package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.*;
import com.crowsnestfrontend.User.Owner;

import com.crowsnestfrontend.Utility.SyncManager;
import com.crowsnestfrontend.webLogin.ClientSideLogIN;
import com.crowsnestfrontend.webrtcCaller.Caller;
import com.crowsnestfrontend.webrtcCaller.callerWaitingScene;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.event.ActionEvent;
import javafx.stage.StageStyle;
import javafx.scene.web.*;

import java.io.*;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ResourceBundle;

import static com.crowsnestfrontend.webrtcCaller.Caller.callerObject;


public class SignUpController implements Initializable {

    @FXML
    public VBox containerVBox;
    @FXML
    public Button logInViaGithub;
    @FXML
    private TextField signup1;

    @FXML
    private PasswordField signup2;

    @FXML
    private Button sign_in;

    @FXML
    private Button Signup;

    @FXML
    private Text text;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        text.setText("");


        signup1.textProperty().addListener((e) -> {
            Platform.runLater(()->{
                text.setText("");
            });
        });
        signup2.textProperty().addListener((c)-> {
            {
                Platform.runLater(()->{
                    text.setText("");
                });
            }
        });
        sign_in.setOnAction(this::onSignIn);
        Signup.setOnAction(this::onSignUp);
        logInViaGithub.setOnAction(this::onGitHubSignIn);
    }



    @FXML
    private void onSignIn(ActionEvent event) {
        System.out.println("sign in");
        String name = signup1.getText().trim();
        String pass = signup2.getText().trim();

        if (name.isEmpty() || pass.isEmpty()) {
            Platform.runLater(()->{
                text.setText("Please enter both name and password.");

            });
            return;
        }

        if(name.length() >10 ||pass.length()>10){
            Platform.runLater(()->{
                text.setText("The input length has to be less than or equal to 10");
            });
            return;
        }


        Thread.startVirtualThread(() -> {
            try (Socket clientSocket=new Socket("localhost", 12345);
                 ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                 ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
            ) {

                out.writeObject(new ClientRequest(0));
                out.writeObject(new SignInProfile(name ,pass));

                returnQuery statusObject=(returnQuery) in.readObject();


                int status = (statusObject.getStatus());
                String message = statusObject.getMessage();


                String imageUrl = FileManager.storeImageOnFile(statusObject.getImageBytes(),"profileImage");

                if (status == -1) {
                    Platform.runLater(() -> text.setText(message));
                    return;
                }
                Owner.nameId = name;
                Owner.image = imageUrl;
                Owner.password=pass;

                localDataBaseGenerator.initialize_database();

            } catch (Exception e) {
                Platform.runLater(() -> text.setText("Login failed: " + e.getMessage()));
            }
            SyncManager.signUploading.countDown();

            Platform.runLater(()->{
                try{
                    SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(Owner.image));
                    SceneManager.profileController.profileImageView.setImage(new Image(Owner.image));
                }
                catch (Exception e){
                    e.printStackTrace();
                }

                SceneManager.profileController.usernameLabel.setText(Owner.nameId);
                SceneManager.globalStage.centerOnScreen();

            });

        });

    }

    @FXML
    private void onSignUp(ActionEvent event) {
        System.out.println("sign up");

        String name = signup1.getText().trim();
        String pass = signup2.getText().trim();
        if (name.isEmpty() || pass.isEmpty()) {
            Platform.runLater(()->{
                text.setText("Please enter both name and password.\nDon't Use WhiteSpace");

            });
            return;
        }
        if(name.length() >10 ||pass.length()>10){
            Platform.runLater(()->{
                text.setText("The input length has to be less than or equal to 10");
            });
            return;
        }
        if(doesContainsOnly(name)){
            Platform.runLater(()->{
                text.setText("The name can only contain alphabets and numerical digits");
            });
            return;
        }
        Thread.startVirtualThread(() -> {

            int status = 0;
            String message = null;
            int length=0;

            Owner.image="";

            try(    Socket clientSocket=new Socket("localhost",12345);
                    ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                    ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
){

                out.writeObject(new ClientRequest(1));
                out.writeObject(new SignUpProfile(name,pass,"" ));

                returnQuery statusObject=(returnQuery) in.readObject();

                status = (statusObject.getStatus());
                message = statusObject.getMessage();


                if(status==-1){
                    String finalMessage = message;
                    Platform.runLater(()->{
                        text.setText(finalMessage);

                    });

                    return;
                }

                Owner.nameId= name;
                Owner.password=pass;
                Owner.image=FileManager.storeImageOnFile("https://res.cloudinary.com/dvpwqtobj/image/upload/v1757076286/user_xhxvc9.png",
                        "profileImage");
                localDataBaseGenerator.initialize_database();
                out.writeObject(new ImageChanger(Owner.nameId,
                        "https://res.cloudinary.com/dvpwqtobj/image/upload/v1757076286/user_xhxvc9.png" ));

                Platform.runLater(()->{
                    SceneManager.globalStage.setScene(SceneManager.loadingScene);
                });

                SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(Owner.image));;

            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            SyncManager.signUploading.countDown();

            Platform.runLater(()->{
                try{
                    SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(Owner.image));
                    SceneManager.profileController.profileImageView.setImage(new Image(Owner.image));
                }
                catch (Exception e){
                    e.printStackTrace();
                }

                SceneManager.profileController.usernameLabel.setText(Owner.nameId);
                SceneManager.globalStage.centerOnScreen();

            });
        });

    }
    
    public boolean doesContainsOnly(String str){

        for(int i=0;i<str.length(); i++){
            if(!((str.charAt(i)>='A' && str.charAt(i)<='Z')
                || (str.charAt(i)>='a' && str.charAt(i)<='z')
            || (str.charAt(i)>='0' && str.charAt(i)<='9'))){
                    return true;
            }
        }
        return false;
    }

    @FXML
    private void onGitHubSignIn(ActionEvent actionEvent){
        WebView webView = new WebView();
        WebEngine webEngine=webView.getEngine();

        Platform.runLater(()->{
            String clientId = "Ov23liEfjve5uSAPw4G5";
            String redirectUri = "http://localhost:8090/callback";
            String authUrl = "https://github.com/login/oauth/authorize" +
                    "?client_id=" + clientId +
                    "&redirect_uri=" + URLEncoder.encode(redirectUri, StandardCharsets.UTF_8) +
                    "&scope=read:user%20user:email%20repo" +
                    "&state=random123";

            webEngine.load(authUrl);
            Dialog<Void> dialog = new Dialog<>();
            dialog.setDialogPane(new DialogPane());
            ButtonType tempButton=new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
            dialog.getDialogPane().getButtonTypes().add(tempButton);
            dialog.getDialogPane().lookupButton(tempButton).setVisible(false);
            dialog.getDialogPane().lookupButton(tempButton).setManaged(false);

            ClientSideLogIN.startServer(()->{
                Platform.runLater(dialog::close);
            });

            dialog.getDialogPane().setContent(webView);
            dialog.show();



        });
    }

    @FXML
    public void changeText(String text){
        this.text.setText(text);
    }

}



