package com.crowsnestfrontend.webrtcCaller.audioChannel;


import dev.onvoid.webrtc.media.audio.AudioTrackSink;


public class JavaFXAudioSink  implements  AudioTrackSink{

    private static final long LOG_INTERVAL_MS = 1000; // Log every second
    private int frameCount = 0;
    private long lastLogTime = System.currentTimeMillis();


    @Override
    public void onData(byte[] data, int bitsPerSample, int sampleRate, int channels, int frames) {
        frameCount++;

        long now = System.currentTimeMillis();
        if (now - lastLogTime >= LOG_INTERVAL_MS) {
            System.out.printf("Received %d audio frames in the last %.1f seconds%n",
                    frameCount, (now - lastLogTime) / 1000.0);
            System.out.printf("Last audio data: %d bytes, %d bits/sample, %d Hz, %d channels, %d frames%n",
                    data.length, bitsPerSample, sampleRate, channels, frames);

            frameCount = 0;
            lastLogTime = now;
        }
    }
}
