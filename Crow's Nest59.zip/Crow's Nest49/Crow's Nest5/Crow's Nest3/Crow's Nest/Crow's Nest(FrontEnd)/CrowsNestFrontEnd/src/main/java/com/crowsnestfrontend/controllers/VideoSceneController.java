package com.crowsnestfrontend.controllers;

import com.ClientSerializedClasses.endCall;
import com.ClientSerializedClasses.startCodeBox;
import com.crowsnestfrontend.Utility.codeStackPane;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.webrtcCaller.Callee;
import com.crowsnestfrontend.webrtcCaller.Caller;
import com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper;
import com.crowsnestfrontend.webrtcCaller.VideoSceneChat;
import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import org.fxmisc.richtext.CodeArea;
import org.opencv.videoio.VideoCapture;

import java.io.IOException;


public class VideoSceneController {

    @FXML
    public ImageView otherView;
    @FXML
    public ImageView endCall;
    @FXML
    public ImageView code;
    @FXML
    public ImageView camera;
    @FXML
    public ImageView mic;

    @FXML
    public ImageView selfView;

    @FXML
    public VBox voiceHolder;
    @FXML
    public HBox buttonHolder;
    @FXML
    public VBox codeArea;
    @FXML
    public VBox videoChatHolder;
    @FXML
    public Text ClientName;
    @FXML
    public Text UserName;

    private CodeArea codeBox;
    private VideoCapture capture;

    private byte[] buffer;
    private WritableImage writableImage;
    private PixelWriter pixelWriter;
    public  int state=0;
    private volatile boolean cameraActive = false;
    private Thread cameraThread;

    @FXML
    public codeStackPane pane;


    @FXML
    public void initialize() throws IOException, InterruptedException {
        GlobalResourceKeeper.controller=this;

        ClientName.setText(SelectedUserData.name.get());
        UserName.setText(Owner.nameId);

        otherView.setImage(new Image( SelectedUserData.image));

        voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        videoChatHolder.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight()-200);
        selfView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        selfView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        otherView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        otherView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        codeArea.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);
        codeArea.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() *90f/100);


        //GlobalResourceKeeper resource=GlobalResourceKeeper.getInstance();
        //resource.selfView=selfView;
        //resource.otherView=otherView;
        //resource.codeArea=codeArea;
        //resource.voiceHolder=voiceHolder;

        pane=new codeStackPane();
        codeArea.getChildren().add(pane);

        codeArea.setVisible(false);
        codeArea.setManaged(false);
        pane.toFront();

        code.setOnMouseClicked((e)->{
           // resource.selfCameraOnOff();
            if(Callee.callee!=null){
                return;
            }
            Caller.callerObject.sendObject(new startCodeBox());

            try {
                GlobalResourceKeeper.codeCaller(codeArea , state, voiceHolder);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            state++;
            state%=2;
        });

        endCall.setOnMouseClicked((e)->{
            //resource.stopCameraPermanent();
            if(Caller.callerObject!=null){
                Caller.callerObject.sendObject(new endCall());

            }
            if(Callee.callee!=null){
                Callee.callee.sendObject(new endCall());

            }

            SceneManager.globalStage.setScene(SceneManager.mainScene);
            SceneManager.globalStage.centerOnScreen();
            SceneManager.globalStage.show();
        });

        camera.setOnMouseClicked((e)->{
            //resource.cycleCamera();
        });
        var current=new VideoSceneChat();
        buttonHolder.getChildren().add(current);

        //resource.startCamera();
    }

}
