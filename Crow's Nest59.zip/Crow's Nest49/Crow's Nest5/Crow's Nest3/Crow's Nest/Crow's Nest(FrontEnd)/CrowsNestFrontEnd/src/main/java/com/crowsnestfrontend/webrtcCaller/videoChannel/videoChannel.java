package com.crowsnestfrontend.webrtcCaller.videoChannel;
import dev.onvoid.webrtc.media.MediaDevices;
import dev.onvoid.webrtc.media.video.VideoDevice;
import dev.onvoid.webrtc.media.video.VideoCaptureCapability;
import dev.onvoid.webrtc.media.video.VideoDeviceSource;

import java.util.List;




public class videoChannel {
    public static VideoDeviceSource videoSource ;

    static{
        videoSource=new VideoDeviceSource();

        List<VideoDevice> cameras = MediaDevices.getVideoCaptureDevices();
        if (cameras.isEmpty()) {
            System.out.println("No cameras found");

        }

        VideoDevice camera = cameras.getFirst();
        videoSource.setVideoCaptureDevice(camera);


        List<VideoCaptureCapability> capabilities = MediaDevices.getVideoCaptureCapabilities(camera);

        VideoCaptureCapability capability = capabilities.get(0);
        videoSource.setVideoCaptureCapability(capability);
    }

    public static void main(String[] args){








    }
}
