package com.crowsnestfrontend.webrtcCaller;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.stage.Screen;

import java.io.IOException;

public class VideoSceneChat extends Pane {
    @FXML
    public ImageView chattingImage;
    @FXML
    public Text standingMessages;
    int counter=0;
    public VideoSceneChat(){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("chattingVideoScene.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.setOnMouseClicked((_)->{
            Platform.runLater(()->{
                Popup popup = new Popup();
                popup.setAutoHide(true);

                VideoChatBox videoChatBox = VideoChatBox.initialize();
                popup.getContent().add(videoChatBox);

                double x = Screen.getScreens().getFirst().getVisualBounds().getWidth()/2 - 200   ;
                double y = Screen.getScreens().getFirst().getVisualBounds().getHeight()/2 -
                    200;
                popup.setX(x);
                popup.setY(y);
                popup.show(SceneManager.globalStage);
            });
        });
    }

    @FXML
    public void setText(){
        if(this.counter==0){
            standingMessages.setVisible(false);
            standingMessages.setManaged(false);
        }else{
            this.counter=0;
            standingMessages.setText(String.valueOf(this.counter));
        }
    }








}
