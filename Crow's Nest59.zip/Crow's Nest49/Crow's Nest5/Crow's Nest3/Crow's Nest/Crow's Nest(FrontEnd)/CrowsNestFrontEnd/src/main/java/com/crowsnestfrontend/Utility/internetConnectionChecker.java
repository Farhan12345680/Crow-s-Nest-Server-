package com.crowsnestfrontend.Utility;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class internetConnectionChecker {
    public static boolean checkInternet(){
        try {

            URL url = new URL("http://www.google.com");
            URLConnection connection = url.openConnection();
            connection.connect();
            return true;
        } catch (MalformedURLException e) {

            System.err.println("Invalid URL: " + e.getMessage());
            return false;
        } catch (IOException e) {

            System.err.println("No internet connection: " + e.getMessage());
            return false;
        }
    }
}
