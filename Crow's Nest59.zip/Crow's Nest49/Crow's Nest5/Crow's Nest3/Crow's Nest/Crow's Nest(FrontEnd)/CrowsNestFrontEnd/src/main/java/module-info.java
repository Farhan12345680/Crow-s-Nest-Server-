module com.crowsnestfrontend {
    // JavaFX modules
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;
    requires javafx.web;

    // UI libraries
    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.fxmisc.richtext;
    requires org.kordamp.ikonli.javafx;

    // FXGL
    requires com.almasb.fxgl.all;

    // Database and image processing
    requires java.sql;
    requires net.coobird.thumbnailator;

    // WebRTC and OpenCV (automatic modules)
    requires webrtc.java;
    requires opencv;

    // Standard Java modules
    requires java.desktop;
    requires common;
    requires jdk.compiler;
    requires jdk.httpserver;
    requires java.net.http;
    requires org.json;
    requires cloudinary.core;
    requires transitive okhttp3;
    requires transitive okio;
    requires reactfx;
    requires flexmark;
    requires flexmark.util.ast;
    // FXML reflection access
    opens com.crowsnestfrontend to javafx.fxml;
    opens com.crowsnestfrontend.controllers to javafx.fxml;
    opens com.crowsnestfrontend.Messages to javafx.fxml;

    // Export packages
    exports com.crowsnestfrontend;
    exports com.crowsnestfrontend.controllers;
    exports com.crowsnestfrontend.webrtcCaller;
    exports com.crowsnestfrontend.Utility;
    exports com.crowsnestfrontend.gifObject;
    exports com.crowsnestfrontend.forum;
    exports com.crowsnestfrontend.forum.writePost;

    opens com.crowsnestfrontend.Utility to javafx.fxml;
    opens com.crowsnestfrontend.forum to javafx.fxml;
    opens com.crowsnestfrontend.webrtcCaller to javafx.fxml;


}
