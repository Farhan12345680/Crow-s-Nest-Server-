package com.crowsnestfrontend.webrtcCaller;
import com.crowsnestfrontend.MainApplication;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Screen;

import java.io.IOException;

public class VideoScene extends Scene {
    public static VideoScene curr;
    public VideoSceneChat currSceneChat;
    public VideoScene() throws IOException{
        super(new FXMLLoader(MainApplication.class.getResource("VideoScene.fxml")).load() , Screen.getScreens().getFirst().getVisualBounds().getWidth()
                ,Screen.getScreens().getFirst().getVisualBounds().getHeight());
        curr=this;

    }




}
