package com.crowsnestfrontend.ClientSideDataBase;

import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.SerializedClasses.payLoadUsers;
import com.crowsnestfrontend.SerializedClasses.updateStatus;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UserPayloadHandling {

    public static void userPayloadHandling(payLoadUsers users ,String url){
        String insertIntoProfile= """
                INSERT INTO Contacts(name_id, image ) VALUES (?, ?) ON
                CONFLICT(name_id) DO UPDATE SET image=excluded.image ,timeSent=CURRENT_TIMESTAMP;
            """;

        try(Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString)
            ;PreparedStatement ps=conn.prepareStatement(insertIntoProfile)
        ){
            System.out.println("came here 891011");
            ps.setString(1 , users.getRequestUser().getUserName());
            ps.setString(2 , url);

            int isSuccessful =ps.executeUpdate();

            if(isSuccessful==1){
                System.out.println("dd is successful");
            }else {
                System.out.println("not successful");

            }
        }catch (Exception e){
            e.printStackTrace();
        }


    }

    public static void friendUserPayloadHandling(String name , int integer){
        String ss= """
                UPDATE Contacts
                SET is_friend = ? ,timeSent=CURRENT_TIMESTAMP
                WHERE name_id = ?;""";

        try(Connection conn =DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
            PreparedStatement ps = conn.prepareStatement(ss)){
            ps.setInt(1 ,integer);
            ps.setString(2, name);
            ps.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }



}
