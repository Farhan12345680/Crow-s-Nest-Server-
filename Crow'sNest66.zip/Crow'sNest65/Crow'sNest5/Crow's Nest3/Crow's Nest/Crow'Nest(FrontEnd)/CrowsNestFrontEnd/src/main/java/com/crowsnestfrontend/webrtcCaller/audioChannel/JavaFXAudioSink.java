package com.crowsnestfrontend.webrtcCaller.audioChannel;

import dev.onvoid.webrtc.media.audio.AudioTrackSink;

import javax.sound.sampled.*;

public class JavaFXAudioSink implements AudioTrackSink {

    private static final long LOG_INTERVAL_MS = 1000; // Log every second
    private int frameCount = 0;
    private long lastLogTime = System.currentTimeMillis();

    private SourceDataLine speakerLine;
    private AudioFormat currentFormat;

    @Override
    public void onData(byte[] data, int bitsPerSample, int sampleRate, int channels, int frames) {
        frameCount++;

        long now = System.currentTimeMillis();
        if (now - lastLogTime >= LOG_INTERVAL_MS) {
            System.out.printf("Received %d audio frames in the last %.1f seconds%n",
                    frameCount, (now - lastLogTime) / 1000.0);
            System.out.printf("Last audio data: %d bytes, %d bits/sample, %d Hz, %d channels, %d frames%n",
                    data.length, bitsPerSample, sampleRate, channels, frames);

            frameCount = 0;
            lastLogTime = now;
        }

        // Build the expected format
        AudioFormat format = new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED,
                sampleRate,
                bitsPerSample,
                channels,
                (bitsPerSample / 8) * channels, // frame size
                sampleRate,
                false // little endian
        );

        // If first time or format has changed, (re)initialize
        if (speakerLine == null || !format.matches(currentFormat)) {
            setupAudioLine(format);
        }

        // Write data to output line
        if (speakerLine != null && speakerLine.isOpen()) {
            speakerLine.write(data, 0, data.length);
        }
    }

    private synchronized void setupAudioLine(AudioFormat format) {
        try {
            if (speakerLine != null) {
                speakerLine.stop();
                speakerLine.close();
            }

            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            speakerLine = (SourceDataLine) AudioSystem.getLine(info);
            speakerLine.open(format);
            speakerLine.start();

            currentFormat = format;
            System.out.println("Audio line initialized: " + format.toString());

        } catch (LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    public synchronized void close() {
        if (speakerLine != null) {
            speakerLine.stop();
            speakerLine.close();
            speakerLine = null;
        }
    }
}
