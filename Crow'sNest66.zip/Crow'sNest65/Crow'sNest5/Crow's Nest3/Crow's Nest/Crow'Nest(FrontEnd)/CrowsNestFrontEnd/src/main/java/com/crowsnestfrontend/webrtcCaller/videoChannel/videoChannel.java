package com.crowsnestfrontend.webrtcCaller.videoChannel;
import dev.onvoid.webrtc.media.MediaDevices;
import dev.onvoid.webrtc.media.video.VideoDevice;
import dev.onvoid.webrtc.media.video.VideoCaptureCapability;
import dev.onvoid.webrtc.media.video.VideoDeviceSource;

import java.util.List;




public class videoChannel {
    public static VideoDeviceSource videoSource ;



    public static boolean isAnyCameraResourceAvailable(){
        videoSource=new VideoDeviceSource();

        List<VideoDevice> cameras = MediaDevices.getVideoCaptureDevices();
        if (cameras.isEmpty()) {
            System.out.println("No cameras found");
            return false;
        }
        for (var camera : cameras){
            try {
                VideoDeviceSource tempSource = new VideoDeviceSource();
                tempSource.setVideoCaptureDevice(camera);

                List<VideoCaptureCapability> capabilities = MediaDevices.getVideoCaptureCapabilities(camera);
                if (!capabilities.isEmpty()) {
                    tempSource.setVideoCaptureCapability(capabilities.getFirst());
                }

                tempSource.start();
                videoSource.setVideoCaptureDevice(camera);
                videoSource.setVideoCaptureCapability(capabilities.getFirst());

                tempSource.stop();
                return true;
            }catch (Exception e){
                System.out.println(e.getMessage());
            }

        }





        videoSource=null;
        return false;
    }





    public static void selfViewVideoStreamGetter(){

    }
}
