package com.crowsnestfrontend.SceneManagement;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.controllers.ProfileController;
import com.crowsnestfrontend.controllers.SignUpController;
import com.crowsnestfrontend.controllers.mainSceneController;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;

public class SceneManager {
    static{

        try {


            var MainSceneloader = new FXMLLoader(MainApplication.class.getResource("mainScene.fxml"));
            mainScene = new Scene(MainSceneloader.load(), Screen.getScreens().getFirst().getVisualBounds().getWidth(),
                    Screen.getScreens().getFirst().getVisualBounds().getHeight()-50);
            mainSceneContrller = MainSceneloader.getController();

            FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("signIn.fxml"));
            signUpScene = new Scene(fxmlLoader.load(), 600 , 500);
            signUpSceneController=fxmlLoader.getController();

            fxmlLoader=new FXMLLoader(MainApplication.class.getResource("loadingScene.fxml"));
            loadingScene=new Scene(fxmlLoader.load() , 300 , 300 );


            fxmlLoader=new FXMLLoader(MainApplication.class.getResource("OwnerProfile.fxml"));
            profileScene=new Scene(fxmlLoader.load(), 800, 600);

            profileController=fxmlLoader.getController();


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public static Scene mainScene;
    public static Scene profileScene;
    public static Scene signUpScene;
    public static Scene loadingScene;
    public static Stage globalStage;

    public static ProfileController profileController;
    public static mainSceneController mainSceneContrller;
    public static SignUpController signUpSceneController;
    public static final Cloudinary cloudinary = new Cloudinary(ObjectUtils.asMap(
            "cloud_name", "dvpwqtobj",
            "api_key", "642298169966665",
            "api_secret", "fLRoefQsXvaVowTNUesQB720tTw"
    ));
}
