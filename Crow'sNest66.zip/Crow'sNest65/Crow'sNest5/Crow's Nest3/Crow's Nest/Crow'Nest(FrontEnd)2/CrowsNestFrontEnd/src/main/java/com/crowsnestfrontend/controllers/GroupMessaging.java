package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.UserStream.constantStream;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ConstraintsBase;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class GroupMessaging {

    @FXML
    public TextArea GroupTextMessageContentBox;
    @FXML
    public VBox MessageVBox;
    @FXML
    public ImageView GroupImage;
    @FXML
    public Label GroupName;

    //Group Logic Navigation

    @FXML
    public Button prev20;
    @FXML
    public Button Next20;
    @FXML
    public Button Newest;
    @FXML
    public VBox MessageContainerBox;

    @FXML
    public void initialize() throws IOException{

    }

}
