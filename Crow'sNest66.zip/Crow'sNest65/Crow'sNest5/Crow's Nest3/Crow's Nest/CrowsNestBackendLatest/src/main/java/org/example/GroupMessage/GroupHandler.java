package org.example.GroupMessage;

public class GroupHandler {


    public static void groupCreation(){

    }


    public static void deleteGroup(){

    }

    public static void changeGroupImage(){

    }

    public static void giveGroupDetails(){

    }
}
