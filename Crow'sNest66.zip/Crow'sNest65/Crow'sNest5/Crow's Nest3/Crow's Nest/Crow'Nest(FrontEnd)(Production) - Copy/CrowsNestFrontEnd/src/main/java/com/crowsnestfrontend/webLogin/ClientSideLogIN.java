package com.crowsnestfrontend.webLogin;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.SerializedClasses.githubLogin;
import com.crowsnestfrontend.SerializedClasses.returnQuery;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.Utility.SyncManager;
import com.crowsnestfrontend.cloudinaryDefaults;
import com.crowsnestfrontend.controllers.ProfileController;
import com.sun.net.httpserver.HttpPrincipal;
import com.sun.net.httpserver.HttpServer;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;

public class ClientSideLogIN {
    public static Runnable runnable;
    public static HttpServer server;
    public static void startServer(Runnable run){
        runnable=run;
        try{
            server = HttpServer.create(new InetSocketAddress(8090), 0);

            server.createContext("/callback", exchange -> {
                String query = exchange.getRequestURI().getQuery();
                String code = Arrays.stream(query.split("&"))
                        .filter(p -> p.startsWith("code="))
                        .map(p -> p.substring(5))
                        .findFirst().orElse(null);
                System.out.println("""
                        login successful! execution is done
                        """);
                String response = "<h1>Login successful! You can close this tab.</h1>";
                exchange.sendResponseHeaders(200, response.length());
                exchange.getResponseBody().write(response.getBytes());
                exchange.close();

                if (code != null) {

                    try{
                        new Thread(() -> {
                            try {
                                exchangeCodeForToken(code);
                            } catch (IOException | InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }).start();

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });

            server.start();

        }
        catch (Exception e){

        }

    }

    public static void exchangeCodeForToken(String code) throws IOException, InterruptedException {
        HttpResponse<String> response;
        try (HttpClient client = HttpClient.newHttpClient()) {
            String body = "client_id=Ov23liEfjve5uSAPw4G5&client_secret=0464774575fdd7ba905a927c635ea888401027a6" +
                    "&code=" + code +
                    "&redirect_uri=http://13.76.73.158:8090/callback";

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://github.com/login/oauth/access_token"))
                    .header("Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            response = client.send(request, HttpResponse.BodyHandlers.ofString());
        }
        String accessToken = new JSONObject(response.body()).getString("access_token");
        fetchUserProfile(accessToken);
    }

    public static void fetchUserProfile(String accessToken) {
        try {
            HttpResponse<String> res;
            try (HttpClient client = HttpClient.newHttpClient()) {

                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create("https://api.github.com/user"))
                        .header("Authorization", "Bearer " + accessToken)
                        .build();

                res = client.send(req, HttpResponse.BodyHandlers.ofString());
            }
            JSONObject json = new JSONObject(res.body());


            String ownerName="Github: " + json.getString("login");
            String image=json.getString("avatar_url");

            String password=ownerName+"1234567890";
            runnable.run();
            {
                Thread.startVirtualThread(() -> {
                    try (Socket clientSocket=new Socket("13.76.73.158", 12345);
                         ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                         ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
                    ) {

                        out.writeObject(new ClientRequest(100));
                        out.writeObject(new githubLogin(ownerName,image, password));

                        returnQuery statusObject=(returnQuery) in.readObject();


                        int status = (statusObject.getStatus());
                        String message = statusObject.getMessage();




                        if (status == -1) {
                            System.out.println("this caused here");
                            server.stop(0);

                            Platform.runLater(() -> {
                                runnable.run();
                                SceneManager.signUpSceneController.changeText(message);
                            });
                            return;
                        }
                        Owner.nameId = ownerName;
                        Owner.image = FileManager.storeImageOnFile(statusObject.getImageBytes(),
                                "profileImage");
                        Owner.password=password;



                    } catch (Exception e) {
                        Platform.runLater(() ->
                        {   runnable.run();
                            SceneManager.signUpSceneController.changeText("Login failed: " + e.getMessage());});
                    }

                    server.stop(0);



                    Platform.runLater(() -> {
                        try{
                            SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(Owner.image));
                            SceneManager.profileController.profileImageView.setImage(new Image(Owner.image));

                        }
                        catch (Exception e){
                            e.printStackTrace();
                        }

                        SceneManager.profileController.usernameLabel.setText(Owner.nameId);
                        SceneManager.globalStage.centerOnScreen();
                    });
                    localDataBaseGenerator.initialize_database();
                    SceneManager.profileController.uploadButton.setVisible(false);
                    SceneManager.profileController.uploadButton.setManaged(false);
                    SyncManager.signUploading.countDown();


                });
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();

        }
    }


}
