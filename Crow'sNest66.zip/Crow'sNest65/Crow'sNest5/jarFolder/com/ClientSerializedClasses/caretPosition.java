package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class caretPosition implements Serializable{
    @Serial
    private static final long serialVersionUID = 1704L;
    public String messageString;
    public int x;
    public int y;
    public caretPosition(int x , int y){
        this.x=x;
        this.y=y;
    }
    
}
