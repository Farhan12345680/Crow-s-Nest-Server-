package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class cameraStartOneEnd implements Serializable {
    @Serial
    private static final long serialVersionUID = 170223L;

    public cameraStartOneEnd(){
            
    }
    
}
