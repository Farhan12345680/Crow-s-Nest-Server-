package com.crowsnestfrontend.groupManagement;

import java.io.Serial;
import java.io.Serializable;

public class createGroup extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7690L;
    
    public String name ;

    public createGroup(String clientName , String name){
        super(clientName);
        this.name=name;
    }

}
