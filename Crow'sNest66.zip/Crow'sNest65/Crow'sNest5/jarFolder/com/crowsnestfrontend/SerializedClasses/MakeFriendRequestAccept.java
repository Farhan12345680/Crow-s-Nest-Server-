package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class MakeFriendRequestAccept extends payload implements Serializable {

    @Serial
    private static final long  serialVersionUID=37L;
    private String name;
    
    public MakeFriendRequestAccept(String clientName,String name ){
        super(clientName);
        this.name =name;
    }

    public String getName (){
        return this.name;
    }
}
