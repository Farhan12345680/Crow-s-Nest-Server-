package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class Unfriend extends payload implements Serializable {

    @Serial
    private static final long serialVersionUID=1000L;
    public  final String unfriendReceiver;

    public Unfriend(String clientName ,String name){
        super(clientName);
        this.unfriendReceiver=name;
    }

}
