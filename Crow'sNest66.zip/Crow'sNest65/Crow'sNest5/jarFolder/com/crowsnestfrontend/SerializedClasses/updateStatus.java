package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class updateStatus extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=35L;
    private final String name;
    private final int type;
    
    public updateStatus(String clientName , String name , int type){
            super(clientName);
            this.name=name;
            this.type=type;
    }

    public int getStatus(){
        return this.type;
    }
    public String getName(){
        return this.name;
    }

}
