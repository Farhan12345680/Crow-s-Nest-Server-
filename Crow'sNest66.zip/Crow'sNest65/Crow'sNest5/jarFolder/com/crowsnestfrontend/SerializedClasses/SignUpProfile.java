package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class SignUpProfile  implements Serializable {
    @Serial
    public static final long serialVersionUID=4L;

    private final String  name;
    private final String password;
    private final String profileImage;



    public SignUpProfile(String name, String password, String profileImage) {
        this.name = name;
        this.password = password;
        this.profileImage = profileImage;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getProfileImage() {
        return profileImage;
    }
}
