package com.crowsnestfrontend.RequestClass;

public class RequestObject {
    public String requestType;
    public String src;
    public String target;

    public RequestObject(String requestType ,String src ,String target){
        this.requestType=requestType;
        this.src=src;
        this.target=target;
    }


}
