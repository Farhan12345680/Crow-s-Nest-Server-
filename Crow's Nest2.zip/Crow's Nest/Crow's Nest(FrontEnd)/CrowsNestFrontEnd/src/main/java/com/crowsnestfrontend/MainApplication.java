package com.crowsnestfrontend;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SigningRelatedClasses.SignBranchingHandler;

import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.PrintWriter;

import java.net.Socket;
import java.util.Objects;

public class MainApplication extends Application {
    static{
        new SceneManager();
    }

    @Override
    public void start(Stage stage) throws IOException {
        SceneManager.globalStage=stage;
        try {
            stage.getIcons().add(new Image(
                    Objects.requireNonNull(MainApplication.class.getResourceAsStream("images/raven.png"))
            ));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        stage.setTitle("Crow's Nest");
        SignBranchingHandler.signBranchLogicHandler();
        stage.show();
        SceneManager.globalStage.centerOnScreen();

        stage.setResizable(false);
        stage.setOnCloseRequest(event -> {
            try(Socket socket=new Socket("localhost",12345);
                PrintWriter writer=new PrintWriter(socket.getOutputStream(),true)
            ){
                writer.println("10");
                writer.println("name");

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }

    public static void main(String[] args) {
        launch();
    }
}