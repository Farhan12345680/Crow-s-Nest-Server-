package com.crowsnestfrontend.Utility;
import net.coobird.thumbnailator.Thumbnails;

public class ImageCompressionLibarary {

    public static void ImageChangerMethod(){

    }
}
