package com.crowsnestfrontend.Utility;

import com.crowsnestfrontend.RequestClass.RequestObject;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;

public class SyncManager {
    public static CountDownLatch imageSenderLock =null;
    public static CountDownLatch messageLoading =null;
    public static CountDownLatch signUploading=null;
    static {
        processing();
    }

    public static BlockingQueue<RequestObject> allRequestProcessingQueue=new LinkedBlockingQueue<>();


    public static void processing(){
        Thread.startVirtualThread(()->{
            while(true){
                try{
                    RequestObject request=allRequestProcessingQueue.take();

                    switch (request.requestType){
                        case ("Image Change"):{
                            ImageCompressionLibarary.ImageChangerMethod();
                        }
                    }

                }catch (Exception e){
                    System.out.println(e.getMessage());
                }
            }

        });

    }
}
