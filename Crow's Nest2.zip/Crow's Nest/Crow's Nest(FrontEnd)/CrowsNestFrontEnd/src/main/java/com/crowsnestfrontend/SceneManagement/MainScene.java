package com.crowsnestfrontend.SceneManagement;

public class MainScene {
}
