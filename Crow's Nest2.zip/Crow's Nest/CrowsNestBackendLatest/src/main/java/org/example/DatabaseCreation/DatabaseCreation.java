package org.example.DatabaseCreation;
import java.sql.*;

public class DatabaseCreation {
    private static final String URL = "jdbc:sqlite:main_database_page.db";

    public static void main(String[] args) throws SQLException {
        initializeSchema();
        System.out.println("Database setup complete.");
    }

    public static void initializeSchema() throws SQLException {
        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement()) {

            stmt.execute("PRAGMA foreign_keys = ON;");

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS Profiles (
                  name_id  TEXT PRIMARY KEY NOT NULL,
                  password TEXT NOT NULL,
                  image    BLOB
                );
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS Contacts (
                  owner_name TEXT NOT NULL,
                  target     TEXT NOT NULL,
                  is_friend  INTEGER NOT NULL DEFAULT 0,
                  FOREIGN KEY(owner_name) REFERENCES Profiles(name_id) ON DELETE CASCADE,
                  FOREIGN KEY(target)     REFERENCES Profiles(name_id) ON DELETE CASCADE,
                  PRIMARY KEY(owner_name, target)
                );
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS Messages (
                  id         INTEGER PRIMARY KEY AUTOINCREMENT,
                  content TEXT NOT NULL,
                  isReplyTo INTEGER ,
                  receiver   TEXT NOT NULL,
                  sender     TEXT NOT NULL,
                  time_sent  DATETIME DEFAULT CURRENT_TIMESTAMP,
                  is_seen    INTEGER DEFAULT 0,
                  reaction   INTEGER DEFAULT 0,
                  isDeletedBySender BOOLEAN FALSE,
                  FOREIGN KEY(receiver) REFERENCES Profiles(name_id),
                  FOREIGN KEY(sender)   REFERENCES Profiles(name_id),
                  FOREIGN KEY(receiver) REFERENCES Messages(id)
                );
            """);

            stmt.execute("""
                    CREATE TABLE IF NOT EXISTS recentReaction(
                        messageID INTEGER,
                        reactionSender TEXT NOT NULL,
                        reactionChange INTEGER ,
                        isDeleted BOOLEAN,
                        FOREIGN KEY(messageID) REFERENCES Messages(id),
                        FOREIGN KEY(reactionSender) REFERENCES Profiles(name_id)
                    );
                    """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS Call_Type (
                  id         INTEGER PRIMARY KEY AUTOINCREMENT,
                  receiver   TEXT NOT NULL,
                  sender     TEXT NOT NULL,
                  time_sent  DATETIME DEFAULT CURRENT_TIMESTAMP,
                  call_type  INTEGER NOT NULL,
                  is_seen    INTEGER DEFAULT 0,
                  FOREIGN KEY(receiver) REFERENCES Profiles(name_id),
                  FOREIGN KEY(sender)   REFERENCES Profiles(name_id) ON DELETE CASCADE
                );
            """);

            stmt.execute("CREATE INDEX IF NOT EXISTS idx_contacts_owner ON Contacts(owner_name);");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_messages_recv_sndr ON Messages(receiver, sender);");
            stmt.execute("CREATE INDEX IF NOT EXISTS get_unseen_messages ON Messages(receiver ,sender, is_seen);");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_reactionType ON recentReaction(messageID);");
        }
    }




//
//    public static List<User> getAllContacts(String ownerName) {
//        String sql = "SELECT target, is_friend, image FROM Contacts WHERE owner_name = ?;";
//        List<User> list = new ArrayList<>();
//        try (Connection conn = DriverManager.getConnection(URL);
//             PreparedStatement ps = conn.prepareStatement(sql)) {
//
//            ps.setString(1, ownerName);
//            try (ResultSet rs = ps.executeQuery()) {
//                while (rs.next()) {
////                    String target    = rs.getString("target");
////                    boolean isFriend = rs.getInt("is_friend") != 0;
////                    byte[] imgBytes  = rs.getBytes("image");
////                    list.add(new User(target, imgBytes, isFriend));
//                }
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return list;
//    }

    public static  void addImagetoTheTable(byte[] bytes,String name){
        System.out.println("called");
        String insertIntoDatabaseStateMent= """
                UPDATE Profiles SET image = ? WHERE name_id = ?;
                """;

        try(Connection conn =DriverManager.getConnection(DatabaseCreation.URL )){
            try(PreparedStatement ps =conn.prepareStatement(insertIntoDatabaseStateMent)){
                ps.setBytes(1 , bytes);
                ps.setString(2 , name);
                ps.execute();
                System.out.println("image insertion successful");
            }catch (SQLException e){
                System.out.println(e.getMessage());
            }
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    public static  byte[] getUserImageData(String nameid){

        System.out.println("called");
        String insertIntoDatabaseStateMent= """
                Select * from Profiles WHERE name_id = ?;
                """;

        try(Connection conn =DriverManager.getConnection(DatabaseCreation.URL )){
            try(PreparedStatement ps =conn.prepareStatement(insertIntoDatabaseStateMent)){
                ps.setString(1 , nameid);
                ResultSet rs =ps.executeQuery();

                if (rs.next()) {
                    byte[] image_arr = rs.getBytes("image");
                    System.out.println("Image retrieval successful");
                    return image_arr;
                } else {
                    System.out.println("No user found with name_id: " + nameid);
                }

            }catch (SQLException e){
                System.out.println(e.getMessage());
            }
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }


        return new byte[0];
    }
}
