package com.crowsnestfrontend.webrtcCaller;

import com.crowsnestfrontend.MainApplication;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;

import javax.swing.text.html.ImageView;
import java.io.IOException;

public class CallerIncoming extends Pane {
    @FXML
    public ImageView CallerImage;
    @FXML
    public ImageView rejectCall;

    @FXML
    public ImageView acceptCall;

    public CallerIncoming(){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("incomingCall.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
