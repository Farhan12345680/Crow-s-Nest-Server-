package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class pendingFriendRequest implements Serializable{
    @Serial
    private static final long serialVersionUID=12L;

    private final String name;
    
    public pendingFriendRequest(String name){
            this.name=name;
    }

    public String getName(){
        return name;
    }
}
