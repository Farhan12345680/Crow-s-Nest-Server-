package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class CallCandidate extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID = 701L;

    public String userId;
    public String candidate;
    public String sdpMid;
    public int sdpMLineIndex;

    public CallCandidate(String userId, String candidate, String sdpMid, int sdpMLineIndex) {
        super("");
        this.userId = userId;
        this.candidate = candidate;
        this.sdpMid = sdpMid;
        this.sdpMLineIndex = sdpMLineIndex;
    }
}
