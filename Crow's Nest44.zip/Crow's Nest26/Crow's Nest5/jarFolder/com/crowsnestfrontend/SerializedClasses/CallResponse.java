package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class CallResponse extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 8991231L;

    public String calleeId;
    public boolean accepted;
    public String sdpAnswer;

    public CallResponse(String calleeId, boolean accepted, String sdpAnswer) {
        super("");
        this.calleeId = calleeId;
        this.accepted = accepted;
        this.sdpAnswer = sdpAnswer;
    }
}
