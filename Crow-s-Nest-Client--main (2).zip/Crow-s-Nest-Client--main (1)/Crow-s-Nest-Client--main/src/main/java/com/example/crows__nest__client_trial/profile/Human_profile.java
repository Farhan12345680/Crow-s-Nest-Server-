package com.example.crows__nest__client_trial.profile;

import javafx.scene.image.Image;

public class Human_profile {
    public String profile_id;
    public String profile_password;
    public Image image;
    public Human_profile(){
        this.profile_id="";
        this.profile_password="";
        this.image=null;
    }
    public Human_profile(String profile_id , String profile_password ,Image image){
        this.profile_id=profile_id;
        this.profile_password=profile_password;
        this.image=image;
    }
    public boolean check_correct_Profile(Human_profile profile){

        // make some dbms call
        // make some dbms call

        return true;
    }
}
