package com.crowsnestfrontend.SceneManagement;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.controllers.ProfileController;
import com.crowsnestfrontend.controllers.mainSceneController;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SceneManager {
    static{

        try {


            var MainSceneloader = new FXMLLoader(MainApplication.class.getResource("mainScene.fxml"));
            mainScene = new Scene(MainSceneloader.load(), 1000, 650);
            mainSceneContrller = MainSceneloader.getController();

            FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("signIn.fxml"));
            signUpScene = new Scene(fxmlLoader.load(), 600 , 500);
            fxmlLoader=new FXMLLoader(MainApplication.class.getResource("loadingScene.fxml"));
            loadingScene=new Scene(fxmlLoader.load() , 300 , 300 );


            fxmlLoader=new FXMLLoader(MainApplication.class.getResource("OwnerProfile.fxml"));
            profileScene=new Scene(fxmlLoader.load(), 400, 400);

            profileController=fxmlLoader.getController();


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public static Scene mainScene;
    public static Scene profileScene;
    public static Scene signUpScene;
    public static Scene loadingScene;
    public static Stage globalStage;

    public static ProfileController profileController;
    public static mainSceneController mainSceneContrller;


}
