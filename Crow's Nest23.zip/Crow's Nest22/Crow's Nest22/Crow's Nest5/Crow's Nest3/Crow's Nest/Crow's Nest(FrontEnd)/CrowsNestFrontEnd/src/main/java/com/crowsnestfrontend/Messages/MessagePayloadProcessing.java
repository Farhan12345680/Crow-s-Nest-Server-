package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.MessageForwarding;
import com.crowsnestfrontend.SerializedClasses.MessagePayload;
import com.crowsnestfrontend.User.Owner;
import javafx.application.Platform;

import java.sql.*;

public class MessagePayloadProcessing {


    public static void messageLoader(MessagePayload msgPayload){
        String sqlString= """
                INSERT  INTO Messages(owner 
                ,sender,
                 receiver
                ,text
                ,TextMessageID
                ,reaction,
                getTime
                ,isReplying) VALUES(?,?,? ,? ,?,?,?,?);
                """;

        try(Connection conn= DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
            PreparedStatement ps=conn.prepareStatement(sqlString);){

            ps.setInt(1 ,(msgPayload.clientName.equals(Owner.nameId))?1:0);
            ps.setString(2,msgPayload.sender);
            ps.setString(3,msgPayload.clientName);
            ps.setString(4,msgPayload.text);
            ps.setInt(5,msgPayload.messageID);
            ps.setInt(6,msgPayload.reactionType);
            ps.setString(7,msgPayload.dateTime);
            ps.setInt(8,0);
            ps.executeUpdate();

            if(!(msgPayload.clientName.equals(Owner.nameId))){

                Owner.current.get(msgPayload.clientName).UpMessageCount();

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }catch (Exception e){
            System.out.println("A problem executing");
        }
    }

    public static void  messagePayloadProcessingUserBased(String name){
        Platform.runLater(()->{
            SceneManager.mainSceneContrller.messageListView.getItems().clear();
        });
        String sqlString= """
                SELECT owner, sender ,receiver , text , TextMessageID , reaction , getTime , isReplying
                 FROM Messages WHERE sender=? OR receiver=? ORDER BY getTime ASC;
                """;
        try(Connection conn=DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
            PreparedStatement  ps = conn.prepareStatement(sqlString)){

            ps.setString(1,name);
            ps.setString(2,name);
            ResultSet rs=ps.executeQuery();

            while(rs.next()){

                Message msg=new Message(rs.getString(4 ),rs.getInt(1) ==1 ,rs.getString(7));
                Platform.runLater(() -> {
                    SceneManager.mainSceneContrller.messageListView.getItems().add(
                            msg
                    );
            });
        } }catch (Exception e){
            e.printStackTrace();
        }

    }
}
