package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.Messages.MessageCell;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.User.User;
import com.crowsnestfrontend.UserFloatingButton.UserCell;
import com.crowsnestfrontend.UserStream.constantStream;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import com.crowsnestfrontend.Messages.Message;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class mainSceneController {



    @FXML public Text FriendUserName;
    @FXML public ListView<Message> messageListView;
    public ImageView sendButton;
    @FXML public Pane WelcomeScene;
    @FXML public StackPane sceneHolder;
    @FXML public VBox messageBox;
    @FXML public Pane BlockScreen;
    @FXML public Text blockUserMessage;

    @FXML private Label Title_Shower;

    // Left panel image view
    @FXML public ImageView Personal_image_id;

    // Left panel buttons
    @FXML private Button people_button;
    @FXML private Button friends_button;
    @FXML private Button requests_button;
    @FXML private Button cross_button;

    // Search icon
    @FXML private ImageView search_icon;

    // Header action image and buttons
    @FXML public ImageView user_icon;
    @FXML public Button Message;
    @FXML public Button Call;
    @FXML public Button Video_Call;

    @FXML private ImageView writingImage;
    @FXML private Button send_button;


    public TextField searchPeople;
    public ImageView clearSearchPeople;
    public TextField writeTextField;
    public Button sendTextMessage;

    @FXML public ListView<User> peopleListView;
    @FXML public ListView<User> FriendPeopleView;
    @FXML public ListView<User>requestScrollView;

    public final ObservableList<User> obsUsers           = FXCollections.observableArrayList();
    public  final ObservableList<User>friendUsers        =FXCollections.observableArrayList();
    public final ObservableList<User> friendRequestUsers =FXCollections.observableArrayList();

    @FXML
    public void profileImageSetter(Image newImage){
        this.Personal_image_id.setImage(newImage);
    }
    private   long index=1;

    @FXML
    public void initialize() {

        if (Title_Shower != null) {
            Title_Shower.setText("Crow's Nest");
        }

        if (Personal_image_id != null) {
            Personal_image_id.setOnMouseClicked(this::gg);
        }

        if (clearSearchPeople != null) {
            clearSearchPeople.setOnMouseClicked(this::clearSearch);
        }

        if (sendTextMessage != null) {
            sendTextMessage.setOnMouseClicked(this::textSender);
        }

        if (people_button != null) {
            people_button.setOnMouseClicked(this::peopleShower);
        }
        if (friends_button != null) {
            friends_button.setOnMouseClicked(this::friendShower);
        }
        if (requests_button != null) {
            requests_button.setOnMouseClicked(this::requestShower);
        }


        FilteredList<User> filteredPeople = new FilteredList<>(obsUsers, p -> true);
        FilteredList<User> filteredFriends = new FilteredList<>(friendUsers, p -> true);
        FilteredList<User> filteredRequests = new FilteredList<>(friendRequestUsers, p -> true);

        peopleListView.setItems(filteredPeople);
        FriendPeopleView.setItems(filteredFriends);
        requestScrollView.setItems(filteredRequests);

        // Set cell factories for each ListView
        peopleListView.setCellFactory(lv -> {
            try {
                return new UserCell();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        FriendPeopleView.setCellFactory(lv -> {
            try {
                return new UserCell();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        requestScrollView.setCellFactory(lv -> {
            try {
                return new UserCell();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        searchPeople.textProperty().addListener((observable, oldVal, newVal) -> {
            String filterText = newVal == null ? "" : newVal.toLowerCase();

            if (index == 1) {
                filteredPeople.setPredicate(u -> u.name.toLowerCase().contains(filterText));
            } else if (index == 2) {
                filteredFriends.setPredicate(u -> u.name.toLowerCase().contains(filterText));
            } else if (index == 3) {
                filteredRequests.setPredicate(u -> u.name.toLowerCase().contains(filterText));
            }
        });

        messageListView.setCellFactory(listView -> new MessageCell());

        SelectedUserData.name.addListener((observable, oldValue, newValue) -> {
            Platform.runLater(() -> {
                SceneManager.mainSceneContrller.user_icon.setImage(new Image(new ByteArrayInputStream(SelectedUserData.image)));
                SceneManager.mainSceneContrller.FriendUserName.setText(SelectedUserData.name.get());
            });
        });

        sendButton.setOnMouseClicked(_ -> {
            Platform.runLater(() -> {
                constantStream.payloadBlockingQueue.add(new com.crowsnestfrontend.SerializedClasses.Message(
                        Owner.nameId,
                        SelectedUserData.name.get(),
                        writeTextField.getText(),
                        0,0)
                );
                LocalDateTime now = LocalDateTime.now();
                String formattedTime = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

                messageListView.getItems().add(new Message(writeTextField.getText(), true, formattedTime));
                writeTextField.clear();
            });
        });

    }


    public void addUser(User user) {
        Platform.runLater(() -> {
                obsUsers.add(user);
        });
    }

    public void addRequestUser(User user){
            Platform.runLater(()->{
                friendRequestUsers.add(user);
            });
    }

    private void requestShower(MouseEvent event) {
        index=3;
        requestScrollView.setVisible(true);
        requestScrollView.setManaged(true);
        peopleListView.setVisible(false);
        peopleListView.setManaged(false);
        FriendPeopleView.setManaged(false);
        FriendPeopleView.setVisible(false);
    }

    private void friendShower(MouseEvent event) {
        index=2;
        requestScrollView.setVisible(false);
        requestScrollView.setManaged(false);
        peopleListView.setVisible(false);
        peopleListView.setManaged(false);
        FriendPeopleView.setManaged(true);
        FriendPeopleView.setVisible(true);
    }

    private void peopleShower(MouseEvent event) {
        index=1;

//        currentListView=requestScrollView;
        requestScrollView.setVisible(false);
        requestScrollView.setManaged(false);
        peopleListView.setVisible(true);
        peopleListView.setManaged(true);
        FriendPeopleView.setManaged(false);
        FriendPeopleView.setVisible(false);
    }

    private void textSender(MouseEvent event) {
        writeTextField.clear();
    }

    private void clearSearch(MouseEvent event) {
        searchPeople.setText("");
    }

    @FXML
    private void gg(MouseEvent event) {
//        System.out.println("Personal image clicked");
        SceneManager.globalStage.setScene(SceneManager.profileScene);
        SceneManager.globalStage.centerOnScreen();
    }

    @FXML
    private void onSendButtonClicked() {
    }

    @FXML
    private void onPeopleClicked() {
    }

    @FXML
    private void onFriendsClicked() {
    }

    @FXML
    private void onRequestsClicked() {
    }

    @FXML
    private void onCrossClicked() {
    }

    @FXML
    private void onMessageClicked() {
    }

    @FXML
    private void onCallClicked() {
    }

    @FXML
    private void onVideoCallClicked() {
    }
}
