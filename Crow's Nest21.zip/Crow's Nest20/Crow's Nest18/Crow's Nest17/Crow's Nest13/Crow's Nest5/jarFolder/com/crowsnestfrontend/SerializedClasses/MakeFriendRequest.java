package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class MakeFriendRequest extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=36L;

    private final String name;

    public MakeFriendRequest(String clientName  , String name){
        super(clientName);
        this.name = name ;
    }

    public String getName(){
        return this.name;
    }
}
