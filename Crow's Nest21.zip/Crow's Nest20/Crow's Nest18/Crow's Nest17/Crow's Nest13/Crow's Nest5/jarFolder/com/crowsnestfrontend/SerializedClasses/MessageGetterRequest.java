package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class MessageGetterRequest extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID=1000L;
    public final String name ;


    public MessageGetterRequest(String clientName,String name) {
        super(clientName);
        this.name = name;
    }
}
