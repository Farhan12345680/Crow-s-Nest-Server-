package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class payLoadUsers extends payload implements Serializable  {

    @Serial
    private static final long serialVersionUID= 16L;

    private final RequestUsers rs;

    public payLoadUsers(String clientName, RequestUsers rs) {
        super(clientName);
        this.rs = rs;
    }

    public RequestUsers getRequestUser(){
        return rs;
    }

}
