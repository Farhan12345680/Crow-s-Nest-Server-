import org.mindrot.jbcrypt.BCrypt;

import javax.swing.text.html.HTMLDocument;
import java.sql.*;
import java.util.ArrayList;

public class database_creation {
    public static String data_creation="jdbc:sqlite:main_database_page.db";
    public static void main(String[] args){
        String data_creation="jdbc:sqlite:main_database_page.db";
        String create_table_creation= """
                CREATE TABLE IF NOT EXISTS Profiles(
                    name_id TEXT PRIMARY KEY NOT NULL,
                    password TEXT NOT NULL,
                    image BLOB
                );
                
                CREATE TABLE IF NOT EXISTS Contacts(
                    owner_name TEXT NOT NULL,
                    target TEXT NOT NULL,
                    is_friend INTEGER NOT NULL,
                    FOREIGN KEY (owner_name) REFERENCES Profiles(name_id),
                    FOREIGN KEY (target) REFERENCES Profiles(name_id)
                );
                
                CREATE TABLE IF NOT EXISTS Messages(
                    receiver TEXT NOT NULL,
                    sender TEXT NOT NULL,
                    time_sent DATETIME DEFAULT CURRENT_TIMESTAMP,
                    is_seen INTEGER DEFAULT 0,
                    FOREIGN KEY (receiver) REFERENCES Profiles(name_id),
                    FOREIGN KEY (sender) REFERENCES Profiles(name_id)
                );
                
                CREATE TABLE IF NOT EXISTS Call_Type(
                    receiver TEXT NOT NULL,
                    sender TEXT NOT NULL,
                    time_sent DATETIME DEFAULT CURRENT_TIMESTAMP,
                    call_type INTEGER NOT NULL,
                    is_seen INTEGER DEFAULT 0,
                    FOREIGN KEY (receiver) REFERENCES Profiles(name_id),
                    FOREIGN KEY (sender) REFERENCES Profiles(name_id)
                );
                
                CREATE INDEX IF NOT EXISTS idx_contacts_owner ON Contacts(owner_name);
                CREATE INDEX IF NOT EXISTS idx_messages_receiver_sender ON Messages(receiver, sender);
                CREATE INDEX IF NOT EXISTS get_message_index on Contacts(owner_name , is_friend );
                """;

        try(Connection conn =  DriverManager.getConnection(data_creation)){
            if(conn!=null){
                PreparedStatement ps =conn.prepareStatement(create_table_creation);
                ps.execute();
                Statement stmt = conn.createStatement();
                stmt.execute("PRAGMA foreign_keys = ON;");
                System.out.println("Database establishment successful");



            }
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }


    public static boolean whether_is_user(String name){

        try(Connection conn= DriverManager.getConnection(data_creation)){
            String select_string = """
                    SELECT name_id FROM Profiles WHERE name_id = ? ;                    
                    """;

            PreparedStatement ps =  conn.prepareStatement(select_string);
            ps.setString(1,name );

            ResultSet rs = ps.executeQuery();


            return (rs.next())?true:false;
        }catch (SQLException e){

        }
        return false;
    }

    public static boolean does_password_match(String name ,String password){
        try(Connection conn= DriverManager.getConnection(data_creation)){
            String select_string = """
                    SELECT name_id,password FROM Profiles where name_id= ?;
                    """;

            PreparedStatement ps =  conn.prepareStatement(select_string);
            ps.setString(1,name );


            ResultSet rs = ps.executeQuery();
            rs.next();
            return BCrypt.checkpw(  password,rs.getString("password"));

        }catch (SQLException e){

        }
        return false;

    }

    public static void insert_the_User( String name , String password){

        try(Connection conn = DriverManager.getConnection(data_creation)){

            if(conn!=null){
                String insert_into_table_values= """
                INSERT INTO Profiles(name_id , password ) VALUES(? ,?);
                """;

                PreparedStatement insert_ps=conn.prepareStatement(insert_into_table_values);
                password= BCrypt.hashpw( password , BCrypt.gensalt());

                insert_ps.setString(1 , name);
                insert_ps.setString(2 , password);
                System.out.println("inserted");
                insert_ps.executeUpdate();
            }


        }catch (SQLException e){
            System.out.println("Problems with inserting");
        }
    }

    public static ArrayList<User> get_all_contacts(String name)  {
        ArrayList<User>arrayList=new ArrayList<User>();
        try(  Connection conn=DriverManager.getConnection(data_creation)){
            String query_statement= """
                 SELECT * FROM Contacts where owner_name = ?;
                    """;
            PreparedStatement ps=conn.prepareStatement(query_statement);
            ps.setString(1, name);
            ResultSet rs= ps.executeQuery();

            while(rs.next()){
                User user1 =new User(rs.getString(""));
            }

        }catch (SQLException e){


        }

        return arrayList;
    }
}
