public class user_authentication {

    public static void  is_correct_new_user(String name , String password){

    }

    public static void is_existing_user(String name , String password){


    }
}
