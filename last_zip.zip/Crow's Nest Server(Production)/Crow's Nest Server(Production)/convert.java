import org.mindrot.jbcrypt.BCrypt;

public class convert {

    public static void main(String[] args){
        String password="1234";
        password= BCrypt.hashpw(password, BCrypt.gensalt());
        System.out.println(password);
    }
}
