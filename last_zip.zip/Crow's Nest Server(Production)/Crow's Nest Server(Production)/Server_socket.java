import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server_socket{

    public static final int ip_port=12345;
    public static final String host_name="127.0.0.1";

    public static void main(String[] args) throws Exception {
        ServerSocket socket = new ServerSocket(ip_port);

        while(true){
            Socket client=socket.accept();

            Thread.startVirtualThread(()->{
                while(!client.isClosed()){
                    check_endpoints(client);
                }
            });
        }
    }


    public static void check_endpoints(Socket socket) {
        try (
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter    writer = new PrintWriter(socket.getOutputStream(), true)
        ) {

            while (!socket.isClosed()) {
                int request_type = Integer.parseInt(reader.readLine());

                if (request_type == 1) {
                    String name = reader.readLine();
                    String password = reader.readLine();

                    if (database_creation.whether_is_user(name)) {
                        writer.println("-1");
                        writer.println("Username already exists. Choose another.");
                        socket.close();
                    }
                    if(is_online.active_users.get(name)==null){
                        is_online.active_users.put(name ,new ArrayList<>());

                    }
                    is_online.active_users.get(name).add(" ");
                    database_creation.insert_the_User(name, password);
                    writer.println("1");
                    writer.println("User created successfully");

                } else if (request_type == 0) {
                    String name = reader.readLine();
                    String password = reader.readLine();
                    if (!database_creation.whether_is_user(name)) {
                        writer.println("-1");
                        writer.println("User does not exist.");
                        socket.close();
                        return;
                    }
                    if (!database_creation.does_password_match(name, password)) {
                        writer.println("-1");
                        writer.println("Incorrect password.");
                        socket.close();
                        return;
                    }

                    if(is_online.active_users.get(name)==null){
                        is_online.active_users.put(name ,new ArrayList<>());

                    }
                    is_online.active_users.get(name).add(" ");
                    writer.println("1");
                    writer.println("Login successful");
                } else if (request_type == 10) {
                    String name = reader.readLine();

                    System.out.println("Client closing request");
                    is_online.active_users.get(name).remove(" ");
                    if(is_online.active_users.get(name).isEmpty()){
                        is_online.active_users.remove(name);
                    }

                    socket.close();

                }
            } }catch(Exception e){
            }

        }
    }
