public class User {

    public String name_id;
    public int Unseen_messages_count;
    public int is_friend;
    public byte[]  image;
    public User(String name_id , String password , int Unseen_message_count ,int is_friend , byte[] arr){

        this.name_id=name_id;
        this.Unseen_messages_count =Unseen_message_count;
        this.is_friend=is_friend;
        this.image = image;
    }
}
