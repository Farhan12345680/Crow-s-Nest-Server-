package com.example.crows__nest__client_trial;

import com.example.crows__nest__client_trial.layout.main_layout;
import com.example.crows__nest__client_trial.layout.signup_layout;
import com.example.crows__nest__client_trial.profile.Human_profile;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;


public class MainApplication extends Application {
    public static Socket curr_socket = null;
    public static  Human_profile Human=null;
    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) throws IOException {

        stage.setTitle("Crow's Nest");
        try {
            stage.getIcons().add(new Image(MainApplication.class.getResourceAsStream("images/raven.png")));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        stage.setResizable(false);
        Human_profile current_human = new Human_profile();
        Scene main_scene = main_layout.main_layout_sender(stage);


        Scene Signup_scene = signup_layout.signup_sheet(current_human, main_scene, stage, curr_socket);
        stage.setScene(Signup_scene);
        signup_layout.centerStage(stage);

        stage.show();
        stage.setOnCloseRequest(event -> {

            if(curr_socket==null){

                return;
            }

            PrintWriter printWriter=null;
            try {
                printWriter=new PrintWriter(curr_socket.getOutputStream(), true);
                printWriter.println("10");
                printWriter.println("name");

                curr_socket.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        });

    }
}