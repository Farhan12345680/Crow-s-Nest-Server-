package com.example.crows__nest__client_trial.profile;

import javafx.scene.image.Image;

import java.util.List;

public class Human_profile {
    public static Human_profile owner_human;
    public static List<Human_profile> contacts;


    public String profile_id=null;
    public Image image=null;
    public int is_friend;

    public Human_profile() {
        this.profile_id = "";

    }


}
