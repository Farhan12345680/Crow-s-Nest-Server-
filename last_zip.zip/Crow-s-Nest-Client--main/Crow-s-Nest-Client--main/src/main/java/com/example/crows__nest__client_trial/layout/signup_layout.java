package com.example.crows__nest__client_trial.layout;

import com.example.crows__nest__client_trial.MainApplication;
import com.example.crows__nest__client_trial.dbms.dbms1_call;
import com.example.crows__nest__client_trial.profile.Human_profile;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;


public class signup_layout {
    public static Scene signup_sheet(Human_profile profile      , Scene main_scene, Stage stage, Socket socket) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("Sign_Up.fxml"));
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();


        double sceneWidth = screenBounds.getWidth() / 2;
        double sceneHeight = screenBounds.getHeight() / 1.5;
        Scene scene = new Scene(fxmlLoader.load(), sceneWidth, sceneHeight);

        Text error_txt = (Text) scene.getRoot().lookup("#text");
        TextField profile_id_input = (TextField) scene.getRoot().lookup("#signup1");
        PasswordField profile_password_input = (PasswordField) scene.getRoot().lookup("#signup2");

        profile_id_input.textProperty().addListener((a, b, c) -> {
            error_txt.setText("");
        });
        profile_password_input.textProperty().addListener((obs, old_value, new_value) -> {
            error_txt.setText("");
        });


        // Sign up button
        Button sign_up = (Button) scene.getRoot().lookup("#Signup");
        sign_up.setOnAction((event) -> {
            if(profile_id_input.getText().isEmpty() || profile_password_input.getText().isEmpty()){
                error_txt.setText("Input field can not be empty");

                return ;
            }
            if(profile_id_input.getText().isBlank() || profile_password_input.getText().isEmpty()){
                error_txt.setText("Input field have to contain characters other that white spaces ");
                return;
            }
            if(profile_id_input.getText().charAt(0)==' '){
                error_txt.setText("The name have to start with a character other than whitespace ");
                return;
            }
            Thread.startVirtualThread(() -> {
                int status = 0;
                String message = null;
                Socket echoSocket=null;
                PrintWriter out=null;
                BufferedReader in = null;
                try

                {
                    echoSocket= new Socket("localhost", 12345);
                    out = new PrintWriter(echoSocket.getOutputStream(), true);
                    in = new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));
                    out.println("1");

                    out.println(profile_id_input.getText());
                    out.println(profile_password_input.getText());


                    status = (Integer.parseInt(in.readLine()));
                    message = (in.readLine());


                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (status == -1) {
                    error_txt.setText(message);
                    return;
                }
                profile.profile_id=profile_id_input.getText();
                Platform.runLater(() -> {
                    stage.setScene(main_scene);
                    centerStage(stage);
                    stage.show();
                    dbms1_call.initialize_database();
                });
                MainApplication.curr_socket=echoSocket;


            });

        });


        Button sign_in = (Button) scene.getRoot().lookup("#sign_in");
        sign_in.setOnAction((event) -> {
            if(profile_id_input.getText().isEmpty() || profile_password_input.getText().isEmpty()){
                error_txt.setText("Input field can not be empty");
                return ;
            }
            if(profile_id_input.getText().isBlank() || profile_password_input.getText().isEmpty()){
                error_txt.setText("Inputs field have to contain characters other that white spaces ");
                return;
            }
            if(profile_id_input.getText().charAt(0)==' '){
                error_txt.setText("The name have to start with a valid characters");
                return;
            }
            AtomicInteger status = new AtomicInteger(-1);
            AtomicReference<String> message = new AtomicReference<>(null);

            Thread.startVirtualThread(() -> {
                Socket echoSocket=null;
                PrintWriter out=null;
                BufferedReader in = null;

                try {
                        echoSocket = new Socket("localhost", 12345);
                        out = new PrintWriter(echoSocket.getOutputStream(), true);
                        in = new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));

                    out.println("0");
                    out.println(profile_id_input.getText());
                    out.println(profile_password_input.getText());

                    status.set(Integer.parseInt(in.readLine()));
                    message.set(in.readLine());


                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (status.get() == -1) {
                    error_txt.setText(message.get());
                    return;
                }
                profile.profile_id=profile_id_input.getText();

                Platform.runLater(() -> {
                    stage.setScene(main_scene);
                    centerStage(stage);
                    stage.show();
                    dbms1_call.initialize_database();
                });
                MainApplication.curr_socket=echoSocket;

            });


        });

        stage.setScene(scene);
        centerStage(stage);
        return scene;
    }


    public static void centerStage(Stage stage) {
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        stage.setX(screenBounds.getWidth() / 2 - stage.getScene().getWidth() / 2);
        stage.setY(screenBounds.getHeight() / 2 - (stage.getScene().getHeight() / 2));
    }
}
