package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;
import com.crowsnestfrontend.SerializedClasses.*;

public class currentlyBusy extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 1801L;

    public currentlyBusy(){
        super("");
    }   
}
