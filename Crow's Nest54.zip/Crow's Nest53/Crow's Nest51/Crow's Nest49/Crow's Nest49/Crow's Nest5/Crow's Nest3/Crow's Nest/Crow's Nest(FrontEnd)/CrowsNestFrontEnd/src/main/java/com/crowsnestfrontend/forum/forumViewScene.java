package com.crowsnestfrontend.forum;

import com.PostFile.getPostRequest;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.controllers.forumController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Screen;

import java.io.IOException;

public class forumViewScene {

    public static Scene view = null;
    public forumController controller;
    public Scene scene;
    public static forumViewScene kl;
    public static Scene initialize() {
        if (view == null) {
            try {
                System.out.println("this data has never been shown");
                constantStream.payloadBlockingQueue.add(new getPostRequest(Owner.nameId, -1, -1));
                kl =new forumViewScene ();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return view;
    }
    public static forumViewScene jk(){
        if(kl==null){
            initialize();
        }
        return kl;
    }
    public forumViewScene() throws IOException {
        FXMLLoader loader = new FXMLLoader(MainApplication.class.getResource("forumView.fxml"));
        markdownHBox.initialize();
        scene = new Scene(loader.load(),
                Screen.getPrimary().getVisualBounds().getWidth(),
                Screen.getPrimary().getVisualBounds().getHeight());
        view=scene;
        controller = loader.getController();


    }
}
