package com.crowsnestfrontend.forum;

import com.crowsnestfrontend.MainApplication;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class NoneFound extends VBox {
    public static NoneFound node;

    public static NoneFound initialize(){
        if(node==null){
            node
                    =new NoneFound();
            forumViewScene.jk().controller.stackData.getChildren().add(node);
        }

        return node;
    }
    public NoneFound(){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.
                class.getResource("NoPostFound.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }





}
