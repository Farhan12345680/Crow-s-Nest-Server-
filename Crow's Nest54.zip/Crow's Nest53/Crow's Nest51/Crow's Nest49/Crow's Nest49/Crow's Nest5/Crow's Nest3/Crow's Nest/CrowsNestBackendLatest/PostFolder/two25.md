<!-- This is an HTML comment in Markdown -->
# The Planets of Our Solar System

Our Solar System consists of eight planets orbiting the Sun. Below is an overview of each planet with images and brief descriptions.

---

## ☀️ The Sun

*The center of our Solar System, a glowing ball of hot plasma.*

---

## 🪐 Mercury

![Mercury](https://upload.wikimedia.org/wikipedia/commons/4/4a/Mercury_in_true_color.jpg)  
**Mercury** is the smallest planet and closest to the Sun. It has a rocky surface covered with craters.

---

## 🪐 Venus

![Venus](https://upload.wikimedia.org/wikipedia/commons/e/e5/Venus-real_color.jpg)  
**Venus** is the second planet from the Sun and is similar in size to Earth. Its thick atmosphere causes a strong greenhouse effect, making it the hottest planet.

---

## 🪐 Earth

![Earth](https://upload.wikimedia.org/wikipedia/commons/9/97/The_Earth_seen_from_Apollo_17.jpg)  
**Earth** is the third planet and the only known world to support life. It has vast oceans, an atmosphere, and diverse ecosystems.

---

## 🪐 Mars

![Mars](https://upload.wikimedia.org/wikipedia/commons/0/02/OSIRIS_Mars_true_color.jpg)  
**Mars**, the "Red Planet," is known for its iron oxide-rich soil giving it a reddish appearance. It has the tallest volcano and deepest canyon in the Solar System.

---

## 🪐 Jupiter

![Jupiter](https://upload.wikimedia.org/wikipedia/commons/e/e2/Jupiter.jpg)  
**Jupiter** is the largest planet in the Solar System, a gas giant famous for its Great Red Spot — a giant storm larger than Earth.

---

## 🪐 Saturn

![Saturn](https://upload.wikimedia.org/wikipedia/commons/c/c7/Saturn_during_Equinox.jpg)  
**Saturn** is renowned for its spectacular ring system made of ice and rock. It is the second-largest planet and also a gas giant.

---

## 🪐 Uranus

![Uranus](https://upload.wikimedia.org/wikipedia/commons/3/3d/Uranus2.jpg)  
**Uranus** is an ice giant with a blue-green color caused by methane in its atmosphere. It rotates on its side, making its seasons extreme.

---

## 🪐 Neptune

![Neptune](https://upload.wikimedia.org/wikipedia/commons/5/56/Neptune_Full.jpg)  
**Neptune** is the farthest planet from the Sun, an ice giant known for its strong winds and deep blue color.

---

## 🪐 Pluto *(Dwarf Planet)*

![Pluto](https://upload.wikimedia.org/wikipedia/commons/2/2a/Nh-pluto-in-true-color_2x_JPEG-edit-frame.jpg)  
**Pluto** was formerly classified as the ninth planet but is now considered a dwarf planet. It has a rocky and icy surface with a thin atmosphere.

---

*Explore our Solar System to learn more about these fascinating worlds!*
