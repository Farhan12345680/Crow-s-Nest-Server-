package com.crowsnestfrontend.Utility;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.webrtcCaller.Callee;
import com.crowsnestfrontend.webrtcCaller.Caller;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.ArrayList;

public class VideoChatBox extends Pane {
    public static VideoChatBox videoChatbox=null;

    @FXML
    public Button sendButton;
    @FXML
    public TextArea messageBox;
    @FXML
    public ListView<String> messageListView;


    public static VideoChatBox initialize(){
        if(videoChatbox==null){
            videoChatbox=new VideoChatBox();
        }
        return videoChatbox;
    }
    public VideoChatBox(){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("chatBox.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        sendButton.setOnMouseClicked((_)->{

            setSendButton();
        }
        );
    }
    public void insertIntoMessage(String userName  , String data){
        StringBuilder sb= new StringBuilder("Sender : "+userName+"\n");
        sb.append(data+"\n\n");
        Platform.runLater(()->{
            messageListView.getItems().add(sb.toString());
            messageBox.clear();
        });

    }

    public void setSendButton(){
        String data=messageBox.getText().trim();
        if(messageBox.getText().trim().isBlank()){
            return;
        }

        if(Caller.callerObject==null){
            Thread.startVirtualThread(()->{
                Callee.callee.sendMessage(data);
            });
        }else{
            Thread.startVirtualThread(()->{
                Caller.callerObject.sendMessage(data);
            });
        }

        insertIntoMessage(Owner.nameId, data);

    }







}
