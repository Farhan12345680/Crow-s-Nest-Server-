package com.crowsnestfrontend.webrtcCaller;

import com.ClientSerializedClasses.accept;
import com.ClientSerializedClasses.offer;
import com.ClientSerializedClasses.offerReject;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.iceObject;
import com.crowsnestfrontend.SerializedClasses.webrtcConnection;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.Utility.VideoChatBox;
import dev.onvoid.webrtc.*;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.image.Image;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.crowsnestfrontend.MainApplication.client;

public class Caller {
    public static Caller callerObject;
    public RTCPeerConnection pc;
    RTCDataChannel dataChannel;
    private PeerConnectionFactory factory;

    private final AtomicBoolean cleaned = new AtomicBoolean(false);
    private final ExecutorService cleanupExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "caller-cleanup");
        t.setDaemon(true);
        return t;
    });

    public Caller() {
        System.out.println("new caller object creation request came");
        factory = new PeerConnectionFactory();
        RTCConfiguration config = new RTCConfiguration();
        callerObject = this;

        RTCIceServer iceServer = new RTCIceServer();
        iceServer.urls.add("stun:stun.l.google.com:19302");
        config.iceServers.add(iceServer);

        this.pc = factory.createPeerConnection(config, candidate -> {
            System.out.println("Caller ICE: " + candidate.sdp);
            var obj = new iceObject(
                    Owner.nameId,
                    SelectedUserData.name.get(),
                    candidate.sdp,
                    candidate.sdpMid,
                    candidate.sdpMLineIndex
            );
            constantStream.payloadBlockingQueue.add(obj);
        });

        RTCDataChannelInit dataChannelConfig = new RTCDataChannelInit();
        dataChannelConfig.maxPacketLifeTime = -1;
        dataChannelConfig.maxRetransmits = -1;

        this.dataChannel = pc.createDataChannel("chat", dataChannelConfig);
        this.dataChannel.registerObserver(new RTCDataChannelObserver() {
            @Override
            public void onBufferedAmountChange(long previousAmount) {
                long currentAmount = dataChannel.getBufferedAmount();
                System.out.println("Buffered amount changed from " + previousAmount + " to " + currentAmount + " bytes");
            }

            @Override
            public void onStateChange() {
                RTCDataChannelState state = dataChannel.getState();
                System.out.println("Data channel state changed to: " + state);

                switch (state) {
                    case CONNECTING:
                        System.out.println("Data channel is being established");
                        break;

                    case OPEN:
                        System.out.println("Data channel is open and ready to use");
                        Thread.startVirtualThread(() -> {
                            // only send when channel is open
                            if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
                                sendObject(new offer(Owner.nameId, FileManager.getImageUniqueId()));
                                //sendMessage("hello peer how are you doing");
                            }
                        });
                        break;

                    case CLOSING:
                    case CLOSED:
                        scheduleCleanupAndUiNotify();
                        break;
                }
            }

            @Override
            public void onMessage(RTCDataChannelBuffer buffer) {
                try {
                    if (!buffer.binary) {
                        buffer.data.rewind();
                        String msg = StandardCharsets.UTF_8.decode(buffer.data).toString();
                        VideoChatBox.initialize().insertIntoMessage(SelectedUserData.name.get(),
                                msg);
                        return;
                    }

                    ByteBuffer bb = buffer.data;
                    byte[] bytes = new byte[bb.remaining()];
                    bb.get(bytes);

                    Thread.startVirtualThread(() -> handleBinaryMessage(dataChannel, bytes));
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }
        });
    }
    private void handleBinaryMessage(RTCDataChannel channel, byte[] bytes) {
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bytes))) {
            Object obj = ois.readObject();

            if (obj instanceof String str) {
                System.out.println("Received serialized String: " + str);
            } else if (obj instanceof accept) {
                System.out.println("Received accept -> schedule cleanup and showing the videoScene");
                Platform.runLater(()->{
                    callerWaitingScene.callerWaitingInstance.run.run();
                    callerWaitingScene.callerWaitingInstance=null;

                    try {
                        SceneManager.globalStage.setScene(new VideoScene());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            } else {
                System.out.println("Unknown binary object: " + obj.getClass().getName());
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public static Caller initialize() {
        if (callerObject != null) return callerObject;
        callerObject = new Caller();
        return callerObject;
    }


    public void stopCaller() {
        Thread.startVirtualThread(() -> {
            try {
                if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
                    HttpUrl url = HttpUrl.parse("http://localhost:8080/removeBusy?"+SelectedUserData.name.get())
                            .newBuilder().build();
                    Request request = new Request.Builder()
                            .url(url)
                            .get()
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String responseBody = response.body().string();
                            System.out.println(responseBody);
                            }
                        }
                        catch (Exception e){
                        e.printStackTrace();
                    }
                }
                if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
                    HttpUrl url = HttpUrl.parse("http://localhost:8080/removeBusy?"+Owner.nameId)
                            .newBuilder().build();
                    Request request = new Request.Builder()
                            .url(url)
                            .get()
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String responseBody = response.body().string();
                            System.out.println(responseBody);
                        }
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }

                sendObject(new offerReject());

            } catch (Exception ignored) {}

            scheduleCleanup();
        });
    }


    public void StoppedByCallee() {
        scheduleCleanupAndUiNotify();
    }

    private void scheduleCleanupAndUiNotify() {
        scheduleCleanup();
        Platform.runLater(() -> {
            if (callerWaitingScene.callerWaitingInstance != null && callerWaitingScene.callerWaitingInstance.run != null) {
                try {
                    callerWaitingScene.callerWaitingInstance.run.run();
                } catch (Exception ignored) {}
                callerWaitingScene.callerWaitingInstance = null;
            }
        });
    }

    private void scheduleCleanup() {
        if (!cleaned.compareAndSet(false, true)) return;
        cleanupExecutor.execute(() -> {
            try {
                if (dataChannel != null) {
                    try {
                        dataChannel.unregisterObserver();
                    } catch (Throwable ignored) {}
                    try {
                        dataChannel.close();
                    } catch (Throwable ignored) {}
                    try {
                        dataChannel.dispose();
                    } catch (Throwable ignored) {}
                    dataChannel = null;
                }

                if (pc != null) {
                    try {
                        pc.close();
                    } catch (Throwable t) {
                        System.err.println("pc.close() error: " + t.getMessage());
                    }
                    pc = null;
                }

                if (factory != null) {
                    try {
                        factory.dispose();
                    } catch (Throwable t) {
                        System.err.println("factory.dispose() error: " + t.getMessage());
                    }
                    factory = null;
                }

                callerObject = null;

            } finally {
            }
        });
    }

    public void sendObject(Object object) {
        Thread.startVirtualThread(() -> {
            try {
                if (dataChannel == null || dataChannel.getState() != RTCDataChannelState.OPEN) {
                    System.err.println("sendObject: dataChannel not open");
                    return;
                }
                try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
                     ObjectOutputStream oos = new ObjectOutputStream(baos)) {
                    oos.writeObject(object);
                    oos.flush();
                    byte[] bytes = baos.toByteArray();
                    dataChannel.send(new RTCDataChannelBuffer(ByteBuffer.wrap(bytes), true));
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
        });
    }

    public void sendMessage(String message) {
        Thread.startVirtualThread(() -> {
            try {
                if (dataChannel == null || dataChannel.getState() != RTCDataChannelState.OPEN) {
                    System.err.println("sendMessage: dataChannel not open");
                    return;
                }
                dataChannel.send(new RTCDataChannelBuffer(ByteBuffer.wrap(message.getBytes()), false));
            } catch (Throwable t) {
                t.printStackTrace();
            }
        });
    }

    public void makeOffer() {
        if (pc == null) {
            System.err.println("makeOffer ignored: pc is null");
            return;
        }
        RTCOfferOptions options = new RTCOfferOptions();
        pc.createOffer(options, new CreateSessionDescriptionObserver() {
            @Override
            public void onSuccess(RTCSessionDescription offer) {
                if (pc == null) return;
                pc.setLocalDescription(offer, new SetSessionDescriptionObserver() {
                    @Override
                    public void onSuccess() {
                        System.out.println("Caller local SDP set");
                        var obj = new webrtcConnection(
                                Owner.nameId,
                                SelectedUserData.name.get(),
                                offer.sdpType.toString(),
                                offer.sdp
                        );
                        constantStream.payloadBlockingQueue.add(obj);
                    }

                    @Override
                    public void onFailure(String error) {
                        System.err.println("Caller failed to set local: " + error);
                    }
                });
            }

            @Override
            public void onFailure(String error) {
                System.err.println("Caller failed to create offer: " + error);
            }
        });
    }

    public void onAnswerReceived(RTCSessionDescription answer) {
        if (pc == null) {
            System.err.println("onAnswerReceived ignored: pc is null");
            return;
        }
        pc.setRemoteDescription(answer, new SetSessionDescriptionObserver() {
            @Override
            public void onSuccess() {
                System.out.println("Caller remote SDP set");
            }

            @Override
            public void onFailure(String error) {
                System.err.println("Caller failed to set remote: " + error);
            }
        });
    }

    public void onIceCandidate(RTCIceCandidate candidate) {
        if (pc != null) pc.addIceCandidate(candidate);
    }
}
