package com.crowsnestfrontend.Utility;

import com.crowsnestfrontend.MainApplication;
import javafx.scene.image.Image;

public class ImageObjectHolder {
    public static final Image IMG_NEUTRAL = new Image(MainApplication.class.getResourceAsStream("images/neutral.png"));
    public static final Image IMG_HAHA = new Image(MainApplication.class.getResourceAsStream("images/face(haha).png"));
    public static final Image IMG_LOVE = new Image(MainApplication.class.getResourceAsStream("images/heart-eyes.png"));
    public static final Image IMG_ANGRY = new Image(MainApplication.class.getResourceAsStream("images/angry.png"));
    public static final Image IMG_SAD= new Image(MainApplication.class.getResourceAsStream("images/sad.png")) ;

}
