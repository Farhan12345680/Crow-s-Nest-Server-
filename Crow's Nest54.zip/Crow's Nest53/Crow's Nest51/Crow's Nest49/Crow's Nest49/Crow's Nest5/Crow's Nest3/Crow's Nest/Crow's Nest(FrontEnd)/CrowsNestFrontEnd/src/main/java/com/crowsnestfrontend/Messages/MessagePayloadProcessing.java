package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.MessagePayload;
import com.crowsnestfrontend.SerializedClasses.deleteMessage;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import javafx.application.Platform;

import java.sql.*;

public class MessagePayloadProcessing {

    public static void messageLoader(MessagePayload msgPayload) {

        String sqlString = """
                INSERT OR IGNORE INTO Messages(owner, sender, receiver, text, TextMessageID, reaction, getTime, isReplying, isDeletedBySender, isDeletedByReceiver ,messageType
                ,imageURL) 
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?);
                """;

        try (Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
             PreparedStatement ps = conn.prepareStatement(sqlString)) {

            ps.setInt(1, (msgPayload.clientName.equals(Owner.nameId)) ? 1 : 0);
            ps.setString(2, msgPayload.clientName);
            ps.setString(3, msgPayload.sender);
            ps.setString(4, msgPayload.text);
            ps.setInt(5, msgPayload.messageID);
            ps.setInt(6, msgPayload.reactionType);
            ps.setString(7, msgPayload.dateTime);
            ps.setInt(8, msgPayload.isReply);
            ps.setInt(9, msgPayload.wasDeletedByOrginalWriter);
            ps.setInt(10, msgPayload.wasDeletedByReceiver);
            ps.setInt(11 , msgPayload.messageType);
            ps.setString(12 , msgPayload.imageURL);
            ps.executeUpdate();
            System.out.println("this is the the image URL 12345---> "+ msgPayload.imageURL);

            if (msgPayload.clientName.equals(Owner.nameId)) {
                Message msg = new Message(msgPayload.text, true, msgPayload.dateTime + " UTC", msgPayload.messageID,
                        msgPayload.isReply, msgPayload.reactionType, 0, 0, msgPayload.messageType,msgPayload.imageURL);
                Owner.messageConcurrentHashMap.put(msgPayload.messageID, msg);

                Platform.runLater(() -> SceneManager.mainSceneContrller.messageListView.getItems().add(msg));

            } else {
                if (Owner.current.containsKey(msgPayload.clientName)) {
                    Owner.current.get(msgPayload.clientName).UpMessageCount();
                }

                Message msg2 = new Message(msgPayload.text, false, msgPayload.dateTime + " UTC",
                        msgPayload.messageID, msgPayload.isReply, msgPayload.reactionType,
                        msgPayload.wasDeletedByOrginalWriter, msgPayload.wasDeletedByReceiver , msgPayload.messageType,msgPayload.imageURL);
                Owner.messageConcurrentHashMap.put(msgPayload.messageID, msg2);

                if (SelectedUserData.name.get().equals(msgPayload.clientName)) {
                    Platform.runLater(() -> SceneManager.mainSceneContrller.messageListView.getItems().add(msg2));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("A problem executing");
        }
    }

    public static void messagePayloadProcessingUserBased(String name) {
        Platform.runLater(() -> SceneManager.mainSceneContrller.messageListView.getItems().clear());

        String sqlString = """
                SELECT messageType ,imageURL,owner, sender, receiver, text, TextMessageID, reaction, getTime, isReplying, isDeletedBySender, isDeletedByReceiver
                FROM Messages
                WHERE sender=? OR receiver=?
                ORDER BY TextMessageID ASC;
                """;

        try (Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
             PreparedStatement ps = conn.prepareStatement(sqlString)) {

            ps.setString(1, name);
            ps.setString(2, name);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Message msg = new Message(rs.getString("text"), rs.getInt("owner") == 1,
                        rs.getString("getTime") + " UTC",
                        rs.getInt("TextMessageID"), rs.getInt("isReplying"),
                        rs.getInt("reaction"), rs.getInt("isDeletedBySender"),
                        rs.getInt("isDeletedByReceiver") ,rs.getInt("messageType"),
                        rs.getString("imageURL"));
                int messageID = rs.getInt("TextMessageID");

                Platform.runLater(() -> {
                    if(Owner.messageConcurrentHashMap.containsKey(messageID))
                    {
                        Owner.messageConcurrentHashMap.get(messageID).reaction_type=msg.reaction_type;
                    }else{
                       Owner.messageConcurrentHashMap.putIfAbsent(messageID,msg);
                    }

                    SceneManager.mainSceneContrller.messageListView.getItems().add(msg);
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setMessageIDreaction(int MessageID, int reaction) {

        String sql = "UPDATE Messages SET reaction=? WHERE TextMessageID=?;";

        try (Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, reaction);
            ps.setInt(2, MessageID);

            Platform.runLater(() -> {
                if (Owner.messageConcurrentHashMap.containsKey(MessageID)) {
                    Owner.messageConcurrentHashMap.get(MessageID).reaction_type.set(reaction);
                }
            });

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteMessage(deleteMessage del) {
        System.out.println("Delete message called");

        String query = "SELECT sender FROM Messages WHERE TextMessageID=?;";
        String senderData = "";

        try (Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, del.messageID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                senderData = rs.getString("sender");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        String updateSql;
        if (senderData.equals(del.initiator)) {
            updateSql = "UPDATE Messages SET isDeletedBySender=1 WHERE TextMessageID=?;";
            try (Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
                 PreparedStatement ps = conn.prepareStatement(updateSql)) {

                ps.setInt(1, del.messageID);
                ps.executeUpdate();

                Platform.runLater(() -> {
                    if (Owner.messageConcurrentHashMap.containsKey(del.messageID)) {
                        Owner.messageConcurrentHashMap.get(del.messageID).isDeletedBySender.set(1);
                    }
                });

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            updateSql = "UPDATE Messages SET isDeletedByReceiver=1 WHERE TextMessageID=?;";
            try (Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
                 PreparedStatement ps = conn.prepareStatement(updateSql)) {

                ps.setInt(1, del.messageID);
                ps.executeUpdate();

                Platform.runLater(() -> {
                    if (Owner.messageConcurrentHashMap.containsKey(del.messageID)) {
                        Owner.messageConcurrentHashMap.get(del.messageID).isDeletedByReceiver.set(1);
                    }
                });

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
