package com.comment;


import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;


public class commentDataDelete extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 13498L;

    public String senderName ;
    public int PostID;
    public int commentID;

    public commentDataDelete(String senderName ,
     int PostID ,int commentID){
        super(senderName);

        this.senderName=senderName;
        this.PostID=PostID;

        this.commentID=commentID;
    }   
}
