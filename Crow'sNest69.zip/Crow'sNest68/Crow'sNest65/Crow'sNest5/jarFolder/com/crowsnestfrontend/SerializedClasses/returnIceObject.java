package com.crowsnestfrontend.SerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class returnIceObject extends payload implements Serializable  {
    @Serial
    private static final long serialVersionUID = 703L;

    public String userId;
    public String candidate;
    public String sdpMid;
    public int sdpMLineIndex;
    public String sdp;
    public returnIceObject(String userId, String candidate,String sdp, String sdpMid, int sdpMLineIndex) {
        super(userId);
        this.userId = userId;
        this.sdp=sdp;
        this.candidate = candidate;
        this.sdpMid=sdpMid;
        this.sdpMLineIndex=sdpMLineIndex;
    }  
}
