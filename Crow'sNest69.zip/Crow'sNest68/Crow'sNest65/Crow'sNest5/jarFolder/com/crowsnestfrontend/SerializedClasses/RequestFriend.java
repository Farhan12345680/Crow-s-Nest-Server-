// Source code is decompiled from a .class file using FernFlower decompiler.
package com.crowsnestfrontend.SerializedClasses;

import java.io.Serializable;

public class RequestFriend implements Serializable {
   public static final long serialVersionUID = 11L;
   private final String friendName;

   public RequestFriend(String var1) {
      this.friendName = var1;
   }
   public String getFriName(){
    return this.friendName;
   }
}
