package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class createGroup extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7690L;
    
    public String groupName ;
    public String groupDescription;
    public String groupImageURL;

    public createGroup(String clientName , String groupName ,String groupDescription,String groupImageURL ){
        super(clientName);
        this.groupName=groupName;
        this.groupDescription=groupDescription;
        this.groupImageURL=groupImageURL;

    }

    public createGroup(String clientName , String groupName ,String groupDescription){
        this(clientName ,groupName , groupDescription, null);
        
    }

}
