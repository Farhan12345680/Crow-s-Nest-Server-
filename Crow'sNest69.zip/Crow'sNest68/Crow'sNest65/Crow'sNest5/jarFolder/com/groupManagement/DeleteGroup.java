package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;

public class DeleteGroup extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7696L;
    
    public String memberName ;
    public int ChannelID;

    public DeleteGroup(String clientName , int ChannelID){
        super(clientName);
        this.ChannelID=ChannelID;
    }

}
