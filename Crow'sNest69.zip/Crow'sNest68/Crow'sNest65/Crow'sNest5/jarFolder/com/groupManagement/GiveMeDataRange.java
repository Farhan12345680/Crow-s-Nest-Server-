package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;

public class GiveMeDataRange extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7697L;
    
    public String memberName ;
    public int start;
    public int end;

    public GiveMeDataRange(String clientName , int first , int end){
        super(clientName);
        this.start=first;
        this.end=end;

    }

}
