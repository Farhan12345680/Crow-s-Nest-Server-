package com.crowsnestfrontend.Utility;

import com.CodingFileLocks.giveUpLock;
import com.CodingFileLocks.newCodingFile;
import com.cloudinary.utils.ObjectUtils;
import com.crowsnestfrontend.ClientSideDataBase.changeOwnerClientDatabase;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.ImageChanger;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.webrtcCaller.Callee;
import com.crowsnestfrontend.webrtcCaller.Caller;
import com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Screen;
import javafx.stage.Window;
import org.fxmisc.richtext.CodeArea;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import static com.crowsnestfrontend.SceneManagement.SceneManager.cloudinary;
import static com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper.controller;

public class codeStackPane extends StackPane {

    public final CodeArea codeBox;
    @FXML
    public VBox FolderCreationPage;
    @FXML
    public Pane cursorPane;
    @FXML
    public Button OpenANewFile;
    @FXML
    public Button Save;
    @FXML
    public Label ControlLabel;

    @FXML
    public Button GiveUpLock;

    @FXML
    public Label currentFileLabel;


    public String CodeFileStringName=null;

    public String absolutePath =null;

    public codeStackPane() {
        codeBox = new codeArea();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("StackPaneCodingObject.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        FolderCreationPage.getChildren().add(codeBox);


        double height = Screen.getScreens().getFirst().getVisualBounds().getHeight() * 0.9;
        double width = Screen.getScreens().getFirst().getVisualBounds().getWidth() * 0.65;

        for (Node node : this.getChildren()) {
            if (node instanceof Region region) {
                region.setMinHeight(height);
                region.setMinWidth(width);
            }
        }

        FolderCreationPage.setMinHeight(height);
        FolderCreationPage.setMinWidth(width);

        codeBox.setMinWidth(width);
        codeBox.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 0.7);

        if(GiveUpLock!=null){
            GiveUpLock.setOnMouseClicked((e)->{
                System.out.println(GlobalResourceKeeper.isCodeBlockOwnerMe.get() +
                        " this is the global code block lock");
                if(GlobalResourceKeeper.isCodeBlockOwnerMe.get()){
                    if(Caller.callerObject!=null){
                        Caller.callerObject.sendObject(new giveUpLock());

                    }
                    if(Callee.callee!=null){
                        Callee.callee.sendObject(new giveUpLock());

                    }
                    GlobalResourceKeeper.isCodeBlockOwnerMe.set(false);
                    GlobalResourceKeeper.controller.pane.GiveUpLock.setVisible(false);
                    GlobalResourceKeeper.controller.pane.GiveUpLock.setManaged(false);
                    controller.pane.codeBox.setEditable(false);
                }
            });
        }

        if(OpenANewFile!=null){
            OpenANewFile.setOnMouseClicked((e)->{
                onUploadButton();
            });
        }

        if(Save!=null && absolutePath!=null){
            Save.setOnMouseClicked((e)->{
                File file = new File(absolutePath);

                try(FileWriter writer = new FileWriter(file)) {

                    writer.write(codeBox.getText());

                }catch (Exception e12){
                    e12.printStackTrace();
                }
            });
        }
    }

    @FXML
    private void onUploadButton() {
        Window ownerWindow = this.getScene().getWindow();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Code Files");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Code Files",
                        "*.java", "*.py", "*.c","*.fxml", "*.cpp", "*.js", "*.html", "*.css", "*.ts",
                        "*.json", "*.md", "*.rs", "*.go", "*.kt")
        );

        File selectedFile = fileChooser.showOpenDialog(ownerWindow);
        if (selectedFile != null) {
            Thread.startVirtualThread(() -> {
                StringBuilder fileContent = new StringBuilder();
                try (FileReader reader = new FileReader(selectedFile)) {
                    int character;
                    while ((character = reader.read()) != -1) {
                        fileContent.append((char) character);
                    }


                    Platform.runLater(() -> {
                        this.codeBox.clear();
                        this.codeBox.replaceText(fileContent.toString());
                        this.currentFileLabel.setText("Working on: "+selectedFile.getName());
                        System.out.println("File content:\n" + fileContent);
                    });
                    Caller.callerObject.sendObject(new newCodingFile(selectedFile.getName(), fileContent.toString()));

                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        }
    }


    public void changeCaretPostion(int x , int y){
        codeBox.moveTo(y , x);
    }

    public CodeArea getCodeBox() {
        return codeBox;
    }
}
