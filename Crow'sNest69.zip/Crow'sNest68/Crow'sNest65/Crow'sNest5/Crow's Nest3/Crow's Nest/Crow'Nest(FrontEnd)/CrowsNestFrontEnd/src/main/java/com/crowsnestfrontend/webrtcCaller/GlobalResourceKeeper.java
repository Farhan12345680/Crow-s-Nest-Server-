package com.crowsnestfrontend.webrtcCaller;

import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.Utility.SyncManager;
import com.crowsnestfrontend.controllers.VideoSceneController;
import dev.onvoid.webrtc.PeerConnectionFactory;
import dev.onvoid.webrtc.RTCPeerConnection;
import dev.onvoid.webrtc.media.audio.AudioTrack;
import dev.onvoid.webrtc.media.video.VideoDesktopSource;
import dev.onvoid.webrtc.media.video.VideoTrack;
import dev.onvoid.webrtc.media.video.desktop.ScreenCapturer;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import nu.pattern.OpenCV;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;

import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class GlobalResourceKeeper {
    private static GlobalResourceKeeper instance;



    public static VideoSceneController controller;

    public static synchronized GlobalResourceKeeper getInstance(){
        if(instance==null){
            instance = new GlobalResourceKeeper();
        }

        return instance;
    }

    public static VideoDesktopSource videoSource=new VideoDesktopSource();




    public static void startDesktopVideoCapture(){

        videoSource.setFrameRate(30);
        videoSource.setMaxFrameSize(1280 , 720);

        videoSource.setSourceId(0, false);

        videoSource.start();


    }

    public static void endDesktopVideoCapture(){
        if(videoSource!=null){
            videoSource.stop();


        }



    }

    public static AtomicBoolean isSelfCameraActive = new AtomicBoolean(true);
    public static AtomicBoolean isOtherCameraActive = new AtomicBoolean(true);


    public static AtomicBoolean isCodeBlockActive =new AtomicBoolean(false);
    public static AtomicBoolean isScreeenShareActive= new AtomicBoolean(false);
    public static AtomicBoolean isVideoShareActive= new AtomicBoolean(false);
    public static AtomicBoolean isVideoShareOwnerMe=new AtomicBoolean(false);

    public static  void codeCaller(VBox codeArea , StackPane pane  , VBox voiceHolder ) throws  Exception{
        if(isScreeenShareActive.get()){
            return;
        }

        if(!isCodeBlockActive.get()){



            

            codeArea.setVisible(true);
            codeArea.setManaged(true);
            GlobalResourceKeeper.controller.screenShare.setVisible(false);
            GlobalResourceKeeper.controller.screenShare.setManaged(false);
            GlobalResourceKeeper.controller.pane.setVisible(true);
            GlobalResourceKeeper.controller.pane.setManaged(true);

            voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *30f/100);
        }
        else{



            codeArea.setVisible(false);
            codeArea.setManaged(false);

            GlobalResourceKeeper.controller.screenShare.setVisible(false);
            GlobalResourceKeeper.controller.screenShare.setManaged(false);
            GlobalResourceKeeper.controller.pane.setVisible(true);
            GlobalResourceKeeper.controller.pane.setManaged(true);
            voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        }

        isCodeBlockActive.set(!isCodeBlockActive.get());

    }


    // VideoResource
    public static VideoTrack videoTrack;
    public static AudioTrack audioTrack;




    // codeArea flags

    public static AtomicBoolean isCodeBlockOwnerMe=new AtomicBoolean(false);
    public static AtomicInteger codeEditorRole =new AtomicInteger(0);






}
