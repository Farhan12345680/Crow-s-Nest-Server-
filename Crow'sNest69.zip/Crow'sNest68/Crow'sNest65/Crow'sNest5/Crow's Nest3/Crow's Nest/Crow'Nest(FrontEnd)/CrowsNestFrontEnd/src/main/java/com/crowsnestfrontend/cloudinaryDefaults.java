package com.crowsnestfrontend;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.Map;

import static com.crowsnestfrontend.MainApplication.client;


public class cloudinaryDefaults {

    public static final Cloudinary cloudinary = new Cloudinary(ObjectUtils.asMap(
            "cloud_name", "dvpwqtobj",
            "api_key", "642298169966665",
            "api_secret", "fLRoefQsXvaVowTNUesQB720tTw"
    ));
    public static String gifKey="HvU4kuDcXCesuBKCHgsf2e980Tq18cW4juAEicDAwKEQsxKMKOzGYUZPIDHoexcr";
    public static void main(String[] args) {

//            // Upload first default image
//            Map uploadResult1 = cloudinary.uploader().upload(
//                    new File("C:/Users/User/Desktop/Crow's Nest49/Crow's Nest49/Crow's Nest5/Crow's Nest3/Crow's Nest/Crow's Nest(FrontEnd)/CrowsNestFrontEnd/src/main/resources/com/crowsnestfrontend/images/user.png"),
//                    ObjectUtils.asMap("folder", "default_profiles")
//            );
//            System.out.println("Default 1 uploaded: " + uploadResult1.get("secure_url"));
//
//            OkHttpClient client = new OkHttpClient().newBuilder()
//                    .build();
//            MediaType mediaType = MediaType.parse("application/json");
//            RequestBody body = RequestBody.create(mediaType, "");
//            Request request = new Request.Builder()
//                    .url("https://api.klipy.com/api/v1/{HvU4kuDcXCesuBKCHgsf2e980Tq18cW4juAEicDAwKEQsxKMKOzGYUZPIDHoexcr}/gifs/trending?page={1}&per_page={10}&customer_id={customer_id}&locale={locale}")
//                    .method("GET", body)
//                    .addHeader("Content-Type", "application/json")
//                    .build();
//            Response response = client.newCall(request).execute();

    }



    public static  String githubToCloudinary(String url){
        String returnURL="";
        try {
            // Upload first default image
            Map uploadResult1 = cloudinary.uploader().upload(
                    url,
                    ObjectUtils.asMap("folder", "default_profiles")
            );
            returnURL=(String)uploadResult1.get("secure_url");




        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnURL;
    }

}