package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.groupManagement.GiveMeDataRange;
import com.groupManagement.groupData;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ConstraintsBase;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.util.ArrayList;

public class GroupMessaging {
    public static GroupMessaging object;

    public static ArrayList<groupData>groupList;


    @FXML
    public TextArea GroupTextMessageContentBox;
    @FXML
    public VBox MessageVBox;
    @FXML
    public ImageView GroupImage;
    @FXML
    public Label GroupName;

    //Group Logic Navigation

    @FXML
    public Button prev20;
    @FXML
    public Button Next20;
    @FXML
    public Button Newest;
    @FXML
    public VBox MessageContainerBox;
    @FXML
    public Button goBack;
    @FXML
    public Button createGroup;

    @FXML
    public void initialize() throws IOException{
        object=this;
        constantStream.payloadBlockingQueue.add(new GiveMeDataRange(Owner.nameId , -1 , -1));
        groupList=new ArrayList<>();

        if(goBack!=null){
            goBack.setOnMouseClicked((e)->{
                groupList=null;
                object=null;
                SceneManager.globalStage.setScene(SceneManager.mainScene);
            });
        }

        if(Newest!=null){
            constantStream.payloadBlockingQueue.add(new GiveMeDataRange(Owner.nameId , -1 , -1 ));
        }

        if(createGroup!=null){

        }
    }

}
