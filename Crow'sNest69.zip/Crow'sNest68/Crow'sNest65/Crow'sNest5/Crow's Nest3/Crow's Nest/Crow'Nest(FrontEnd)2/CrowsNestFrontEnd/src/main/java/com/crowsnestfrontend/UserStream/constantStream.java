package com.crowsnestfrontend.UserStream;

import com.ClientSerializedClasses.currentlyBusy;
import com.ClientSerializedClasses.currentlyInactive;
import com.PostFile.*;
import com.comment.*;
import com.crowsnestfrontend.Messages.MessagePayloadProcessing;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.SerializedClasses.*;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.Utility.SyncManager;
import com.crowsnestfrontend.forum.*;
import com.crowsnestfrontend.webrtcCaller.Callee;
import com.crowsnestfrontend.webrtcCaller.Caller;
import com.crowsnestfrontend.webrtcCaller.callerWaitingScene;
import com.groupManagement.GiveMeDataRange;
import dev.onvoid.webrtc.RTCIceCandidate;
import dev.onvoid.webrtc.RTCSdpType;
import dev.onvoid.webrtc.RTCSessionDescription;
import javafx.application.Platform;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class constantStream {

    public static BlockingQueue<payload> payloadBlockingQueue = new LinkedBlockingQueue<>();

    public static void streamGetter(SignInProfile user) {
        try {
            Socket socket = new Socket("localhost", 12346);
            ObjectOutputStream writer = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream reader = new ObjectInputStream(socket.getInputStream());

                synchronized (writer) {
                    writer.writeObject(user);
                    writer.flush();
                }

            Thread.startVirtualThread(() -> {
                Object obj=null;
                try {
                    while (true) {
                        obj = reader.readObject();

                        if (obj instanceof payload) {
                            payloadBlockingQueue.add((payload) obj);
                        } else {
                            System.err.println("Received unknown object: " + obj.getClass());
                        }
                    }
                } catch (EOFException e) {
                    System.err.println("Server closed connection.");
                } catch (IOException | ClassNotFoundException e) {
                    System.err.println("Error reading from server: " + e.getMessage());
                    e.printStackTrace();
                }
            });

            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        payload obj = payloadBlockingQueue.take();

                        switch (obj) {
                            case GiveMeDataRange range ->{
                                synchronized (writer){
                                    writer.writeObject(range);
                                    writer.flush();
                                }
                            }

                            case commentDataDelete del ->{
                                synchronized (writer){
                                    writer.writeObject(del);
                                    writer.flush();
                                }
                            }
                            case commentEdit edit ->{
                                synchronized (writer){
                                    writer.writeObject(edit);
                                    writer.flush();
                                }
                            }
                            case commentDataSendingEnder a ->{
                                if(!markdownHBox.arr.isEmpty()){
                                    Platform.runLater(()->{
                                        markdownHBox.initialize().commentsContainer.getChildren().clear();

                                    });
                                    for(var i: markdownHBox.arr){
                                        Platform.runLater(()->{
                                            markdownHBox.initialize().commentsContainer.getChildren().add(i);

                                        });
                                    }
                                    markdownHBox.arr.clear();
                                }
                                for( var t:markdownHBox.initialize().commentsContainer.getChildren()){
                                    if(t instanceof commentLoading){
                                        Platform.runLater(()->{
                                                    markdownHBox.initialize().commentsContainer.getChildren().remove(t);

                                                }
                                        );
                                    }
                                }
                                System.out.println( "is the comment loading visible "+commentLoading.commentLoading().isVisible());
                            }
                            case commentDataReturn ret ->{
                                if(markdownHBox.post==null){
                                    continue;
                                }
                                if(markdownHBox.post.id!=ret.PostID){
                                    continue;
                                }
                                markdownHBox.arr.add(new commentStorage(ret));

                            }
                            case commentDataRequest req ->{
                                synchronized (writer){
                                    writer.writeObject(req);
                                    writer.flush();
                                }
                            }
                            case commentData data ->{
                                synchronized (writer){
                                    writer.writeObject(data);
                                    writer.flush();
                                }
                            }
                            case getMyPost my->{
                                synchronized (writer){
                                    writer.writeObject(my);
                                    writer.flush();
                                }
                            }
                            case maximumID id ->{
                                //System.out.println(id.EndingRange);
                                Platform.runLater(()->{
                                    if(id.EndingRange >=forumViewScene.jk().controller.maximumID){
                                        forumViewScene.jk().controller.maximumID=id.EndingRange;

                                    }
                                    if(forumViewScene.jk().controller.highest==-1){
                                        forumViewScene.jk().controller.highest= id.EndingRange;
                                        forumViewScene.jk().controller.lowest=id.EndingRange-14;
                                    }
                                });

                            }
                            case DeleteFile file ->{
                                //System.out.println("delete file request came");
                                synchronized (writer){
                                    writer.writeObject(file);
                                    writer.flush();
                                }
                            }
                            case EditFile file ->{
                                synchronized (writer){
                                    writer.writeObject(file);
                                    writer.flush();
                                }
                            }
                            case postDataSendingFinished finished->{
                                Platform.runLater(()->{
                                    if(!forumViewScene.jk().controller.PostDataArraylist.isEmpty()){

                                            forumViewScene.jk().controller.contentBox.getChildren().clear();
                                            int maximum=Integer.MIN_VALUE;
                                            int minimum=Integer.MAX_VALUE;

                                            for(var  i: forumViewScene.jk().controller.PostDataArraylist){
                                                maximum=Math.max(maximum,i.id);
                                                minimum=Math.min(minimum,i.id);
                                                var t= new PostStorage(i);

                                                forumViewScene.jk().controller.addPostStorage(t);

                                            }
                                            forumViewScene.jk().controller.lowest=minimum;
                                            forumViewScene.jk().controller.highest=maximum;
                                        forumViewScene.jk().controller.textData.setText("id "+minimum +" to "+maximum);
                                        NoneFound.initialize().toBack();

                                    }
                                    forumViewScene.jk().controller.changeScene();
                                    forumViewScene.jk().controller.PostDataArraylist.clear();
                                });



                            }
                            case getPostData post->{
                                Platform.runLater(()->{
                                    if(!forumViewScene.jk().controller.PostDataArraylist.contains(post)){
                                        forumViewScene.jk().controller.PostDataArraylist.add(post);

                                    }
                                });


                            }
                            case getPostRequest req->{
                                synchronized (writer){
                                    writer.writeObject(req);
                                    writer.flush();
                                }
                            }
                            case PostData post ->{
                                synchronized (writer){
                                    writer.writeObject(post);
                                    writer.flush();
                                }
                            }
                            case currentlyBusy busy ->{
                                //System.out.println("busy caller request came through");
                                if(callerWaitingScene.callerWaitingInstance!=null ){
                                    callerWaitingScene.changeCurrentlyCallingText("the callee is busy");
                                }
                            }
                            case currentlyInactive inactive ->{
                                //System.out.println("inactive caller request came through");

                                if(callerWaitingScene.callerWaitingInstance!=null ){

                                    callerWaitingScene.changeCurrentlyCallingText("the callee is Inactive");
                                }
                            }
                            case iceObject ice->{
                                if(ice.clientName.equals(Owner.nameId)){
                                    synchronized (writer){
                                        writer.writeObject(ice);
                                        writer.flush();
                                    }
                                }else{
                                    RTCIceCandidate iceCandidate=new RTCIceCandidate(
                                            ice.sdpMid,ice.sdpMLineIndex,ice.sdp
                                    );

                                    Callee.callee.onIceCandidate(iceCandidate);
                                }
                            }
                            case returnIceObject ice->{
                                if(ice.clientName.equals(Owner.nameId)){
                                    synchronized (writer){
                                        writer.writeObject(ice);
                                        writer.flush();
                                    }
                                }else{
                                    RTCIceCandidate iceCandidate=new RTCIceCandidate(
                                            ice.sdpMid,ice.sdpMLineIndex,ice.sdp
                                    );

                                    Caller.callerObject.onIceCandidate(iceCandidate);
                                }
                            }
                            case webrtcConnection o->{
                                if(o.clientName.equals(Owner.nameId)){

                                    synchronized (writer){
                                        writer.writeObject(o);
                                        writer.flush();
                                    }
                                }else{
                                    if(o.type.equals("ANSWER")){
                                        RTCSessionDescription rtcSession= new RTCSessionDescription(RTCSdpType.ANSWER , o.sdp);
                                        Caller.callerObject.onAnswerReceived(rtcSession);
                                    }
                                    else if(o.type.equals("OFFER")){
                                        Callee.initialize(o.clientName);
                                        if(Callee.callee.pc==null){
                                            Callee.callee=new Callee(o.clientName);
                                        }
                                        RTCSessionDescription rtcSession= new RTCSessionDescription(RTCSdpType.OFFER , o.sdp);
                                        Callee.callee.onOfferReceived(rtcSession , o.clientName);
                                    }

                                }

                            }
                            case deleteMessage del ->{
                                if(del.initiator.equals(Owner.nameId)){
                                    //System.out.println("this was sent ");
                                    synchronized (writer){
                                        writer.writeObject(del);
                                        writer.flush();
                                    }
                                }else{
                                    MessagePayloadProcessing.deleteMessage(del);
                                }
                            }
                            case payLoadUsers users -> constantUserStreamGetter.streamCaller(users);
                            case MessagePayload messagePayload -> {
                                Thread.startVirtualThread(()->{
                                    MessagePayloadProcessing.messageLoader(messagePayload);
                                }).join();
                            }
                            case MessageGetterRequest e -> {
                                synchronized (writer) {
                                    writer.writeObject(obj);
                                    writer.flush();
                                }
                            }
                            case Unfriend uf -> {
                                synchronized (writer) {
                                    writer.writeObject(uf);
                                    writer.flush();
                                }
                            }
                            case updateStatus us -> UpdateStream.updater(us);
                            case payloadFriendRequest request -> constantFriendRequestStream.streamCaller(request);
                            case MakeFriendRequest mk -> {
                                synchronized (writer) {
                                    writer.writeObject(mk);
                                    writer.flush();
                                }
                            }
                            case deleteFriendRequest del -> {
                                synchronized (writer) {
                                    writer.writeObject(del);
                                    writer.flush();
                                }
                            }
                            case MakeFriendRequestAccept mk -> {
                                synchronized (writer) {
                                    writer.writeObject(mk);
                                    writer.flush();
                                }
                            }
                            case removeIncomingFriendRequest IFR -> {
                                synchronized (writer) {
                                    writer.writeObject(IFR);
                                    writer.flush();
                                }
                            }
                            case MakeBlock makeBlock -> {
                                synchronized (writer) {
                                    writer.writeObject(makeBlock);
                                    writer.flush();
                                }
                            }
                            case payloadMessageReaction msg ->{
                                if(msg.clientName.equals(Owner.nameId)){

                                    synchronized (writer) {
                                        writer.writeObject(msg);
                                        writer.flush();
                                    }
                                }else{
                                    MessagePayloadProcessing.setMessageIDreaction(msg.messageID , msg.reactionType);
                                }
                            }
                            case Message message -> {
                                synchronized (writer) {
                                    writer.writeObject(message);
                                    writer.flush();
                                }
                            }
                            default -> System.err.println("Unhandled payload type: " + obj.getClass());
                        }

                    }
                } catch (InterruptedException e) {
                    //System.err.println("Processor thread interrupted.");
                    Thread.currentThread().interrupt();
                } catch (IOException e) {
                   // System.out.println(e.getMessage());
                }
            });


        }
        catch (IOException e) {
            System.err.println("Failed to connect to server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
