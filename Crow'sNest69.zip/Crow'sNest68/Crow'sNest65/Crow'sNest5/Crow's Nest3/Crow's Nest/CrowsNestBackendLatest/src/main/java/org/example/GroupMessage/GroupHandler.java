package org.example.GroupMessage;

import com.groupManagement.*;
import org.example.DatabaseCreation.DatabaseCreation;

import java.io.ObjectOutputStream;
import java.sql.*;

public class GroupHandler {


    public static void groupCreation(createGroup groupReq ){

            String QueryString ="Insert into GroupChannel(ChannelName, groupDescription , groupImageURL , groupCreator) values(?,?,?,?)";


            try(Connection conn = DriverManager.getConnection(DatabaseCreation.URL);
                PreparedStatement ps = conn.prepareStatement(QueryString , Statement.RETURN_GENERATED_KEYS)) {

                ps.setString(1 , groupReq.groupName);
                ps.setString(2 , groupReq.groupDescription);
                ps.setString(4,  groupReq.clientName);

                if(groupReq.groupImageURL!=null){

                    ps.setString(3,  groupReq.groupImageURL);
                }else{
                    ps.setString(3,"https://res.cloudinary.com/dvpwqtobj/image/upload/v1758977719/crowd_gfvbey.png");

                }


                ps.executeUpdate();
            }
            catch (Exception e){
                e.printStackTrace();
            }


    }


    public static void deleteGroup(DeleteGroup grp){
        String queryString="Delete from GroupChannel WHERE channelID=?";

        try(Connection conn = DriverManager.getConnection(DatabaseCreation.URL);
            PreparedStatement ps = conn.prepareStatement(queryString)){
            ps.setInt(1, grp.ChannelID);

            ps.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void changeGroupImage(){

    }

    public static void giveGroupDetails(){

    }




    public static void giveGroupDataRange(GiveMeDataRange range , ObjectOutputStream out) {
        String queryString =
                "SELECT gc.channelID, gc.ChannelName, gc.groupImageURL, gc.groupDescription, " +
                        "strftime('%Y-%m-%d %H:%M:%S', gc.groupCreationDate) AS formattedCreationDate, gc.groupCreator, gm.roleID ,gm.memberID" +
                        "FROM GroupChannel gc, GroupMembers gm " +
                        "WHERE gm.memberName = ? " +
                        "AND gc.channelID = gm.channelID " +
                        "AND gc.id > ? " +
                        "Order by DESC"+
                        "LIMIT 15";

        String queryString2=
                "SELECT gc.channelID, gc.ChannelName, gc.groupImageURL, gc.groupDescription, " +
                        "strftime('%Y-%m-%d %H:%M:%S', gc.groupCreationDate) AS formattedCreationDate, gc.groupCreator, gm.roleID ,gm.memberID" +
                        "FROM GroupChannel gc, GroupMembers gm " +
                        "WHERE gm.memberName = ? " +
                        "AND gc.channelID = gm.channelID " +
                        "AND gc.id < ? " +
                        "Order by DESC"+
                        "LIMIT 15";
        String queryString3=
                        "SELECT gc.channelID, gc.ChannelName, gc.groupImageURL, gc.groupDescription, " +
                        "strftime('%Y-%m-%d %H:%M:%S', gc.groupCreationDate) AS formattedCreationDate, gc.groupCreator, gm.roleID ,gm.memberID" +
                        "FROM GroupChannel gc, GroupMembers gm " +
                        "WHERE gm.memberName = ? " +
                        "AND gc.channelID = gm.channelID " +
                        "Order by DESC"+
                        "LIMIT 15";
        ResultSet rs = null;

        try(Connection conn = DriverManager.getConnection(DatabaseCreation.URL);

        ){
            if(range.start==-1 && range.end==-1){
                try(PreparedStatement ps = conn.prepareStatement(queryString3)) {
                    ps.setString(1 , range.clientName);

                    rs=ps.executeQuery();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }else if(range.start==-1){
                try(PreparedStatement ps = conn.prepareStatement(queryString)) {
                    ps.setString(1 , range.clientName);
                    ps.setInt(2, range.end);
                    rs=ps.executeQuery();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }else{
                try(PreparedStatement ps = conn.prepareStatement(queryString2)) {
                    ps.setString(1 , range.clientName);
                    ps.setInt(2, range.start);
                    rs=ps.executeQuery();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            synchronized (out){
                while (rs!=null && rs.next()){
                    int groupID = rs.getInt(1);
                    String groupName = rs.getString(2);
                    String groupImageURL = rs.getString(3);
                    String groupDesc = rs.getString(4);
                    String groupCreationTime=rs.getString(5);
                    String groupCreator = rs.getString(6);
                    int roleID = rs.getInt(7);
                    int memberID = rs.getInt(8);
                    out.writeObject(new groupData(null , groupName ,groupDesc , groupImageURL , groupCreator , groupID,
                            roleID, memberID , groupCreationTime));
                    out.flush();
                }

                out.writeObject(new groupDataSendingEnder());
                out.flush();
            }


        }catch (Exception e){
            e.printStackTrace();
        }



    }
}
