package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.updateStatus;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.User;

public class UpdateStream {

    public static void updater(updateStatus us) {
        System.out.println("Processing request update");

        String name = us.getName();
        User user = Owner.current.get(name);

        if (user == null) {
            return;
        }

        int status = us.getStatus();

        switch (status) {
            case 1:
                if (!Owner.friendRequest.containsKey(name)) {
                    Owner.friendRequest.put(name, " ");
                    user.setIsFriend(2);
                    SceneManager.mainSceneContrller.addRequestUser(user);
                }
                break;

            case -1:
                if (Owner.friendRequest.remove(name) != null) {
                    user.setIsFriend(0);
                    SceneManager.mainSceneContrller.friendRequestUsers.remove(user);
                }
                break;

            case 0:
                user.setIsFriend(0);
                break;

            case 3, 11:
                user.setIsFriend(3);
                break;

            case 10:
                user.setIsFriend(1);
                break;

            default:
                System.out.println("Unknown status: " + status);
        }
    }
}
