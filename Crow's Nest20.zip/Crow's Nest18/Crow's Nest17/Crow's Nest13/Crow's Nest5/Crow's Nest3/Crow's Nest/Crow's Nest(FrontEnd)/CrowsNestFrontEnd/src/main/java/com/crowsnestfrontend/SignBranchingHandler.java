package com.crowsnestfrontend;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.CountDownLatch;

import com.crowsnestfrontend.ClientSideDataBase.AccessOwnerDataFromDatabase;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.MessageGetterRequest;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.Utility.SyncManager;
import javafx.application.Platform;
import javafx.scene.image.Image;

public class SignBranchingHandler {


    public static void signBranchLogicHandler() throws IOException {

        String clientSideDatabaseFilePath="clientData.db";
        File file = new File(clientSideDatabaseFilePath);

        if (file.isFile() && file.canRead() ) {
            AccessOwnerDataFromDatabase.initializeUserDataFromTheClientDatabase();

            try(Socket socket=new Socket("localhost" ,12345);
                ObjectOutputStream out= new ObjectOutputStream(socket.getOutputStream())){

                out.writeObject(new ClientRequest(3));
                out.writeObject(new SignInProfile(Owner.nameId,""));
            }

            Platform.runLater(()->{
                SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.profileImageView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.usernameLabel.setText(Owner.nameId);
            });
            SceneManager.globalStage.setScene(SceneManager.mainScene);
            SyncManager.allLoadingLatch.countDown();
        }
        else {
            SceneManager.globalStage.setScene(SceneManager.signUpScene);
            SceneManager.globalStage.centerOnScreen();

            Thread.startVirtualThread(()->{
                SyncManager.signUploading=new CountDownLatch(1);

                try{

                    SyncManager.signUploading.await();
                    Platform.runLater((()->{
                        SceneManager.globalStage.setScene(SceneManager.mainScene);

                    }));
                }catch (Exception e){
                    System.out.println(e.getMessage());
                }
                Thread.startVirtualThread(()->{
                    constantStream.payloadBlockingQueue.add(new MessageGetterRequest(Owner.nameId,Owner.nameId));

                });

                SyncManager.allLoadingLatch.countDown();

                });




        }





    }
}
