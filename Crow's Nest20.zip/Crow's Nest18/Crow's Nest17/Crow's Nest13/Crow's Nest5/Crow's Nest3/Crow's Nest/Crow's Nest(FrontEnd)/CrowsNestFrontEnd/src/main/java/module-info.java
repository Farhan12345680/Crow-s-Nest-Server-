module com.crowsnestfrontend {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires com.almasb.fxgl.all;
    requires java.sql;
    requires net.coobird.thumbnailator;
    requires jdk.compiler;
    requires java.desktop;
    requires org.apache.commons.io;
    requires common;

    opens com.crowsnestfrontend.Messages to javafx.fxml;
    opens com.crowsnestfrontend to javafx.fxml;
    exports com.crowsnestfrontend;
    exports com.crowsnestfrontend.controllers;
    opens com.crowsnestfrontend.controllers to javafx.fxml;
}