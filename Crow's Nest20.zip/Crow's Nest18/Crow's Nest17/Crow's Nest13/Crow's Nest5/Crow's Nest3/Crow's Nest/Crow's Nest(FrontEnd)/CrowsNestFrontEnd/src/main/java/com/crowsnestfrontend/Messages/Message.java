package com.crowsnestfrontend.Messages;


public class Message {
    public int reaction_type=0;
    public int is_seen;
    public String text;
    public boolean ownMessage;
    public Message(String text ,boolean ownMessage){
        this.text=text;
        this.ownMessage = ownMessage;
    }

    public String getText() {
        return text;
    }

    public boolean isOwnMessage() {
        return ownMessage;
    }

}