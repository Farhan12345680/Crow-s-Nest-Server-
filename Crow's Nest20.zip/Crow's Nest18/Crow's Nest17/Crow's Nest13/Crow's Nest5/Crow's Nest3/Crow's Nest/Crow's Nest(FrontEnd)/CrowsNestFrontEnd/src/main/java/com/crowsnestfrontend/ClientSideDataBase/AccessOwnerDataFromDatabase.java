package com.crowsnestfrontend.ClientSideDataBase;

import com.crowsnestfrontend.User.Owner;

import java.sql.*;

public class AccessOwnerDataFromDatabase {

    public static void initializeUserDataFromTheClientDatabase(){
        String getUserInformationQuery= """
                SELECT * FROM owner_personal_data;
                """;

        try(Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
            PreparedStatement ps = conn.prepareStatement(getUserInformationQuery)
        ){
            ResultSet rs = ps.executeQuery();
            rs.next();
            Owner.nameId=rs.getString("name_id");
            Owner.password=rs.getString("password");
            Owner.image=rs.getBytes("image_bytes");


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


}
