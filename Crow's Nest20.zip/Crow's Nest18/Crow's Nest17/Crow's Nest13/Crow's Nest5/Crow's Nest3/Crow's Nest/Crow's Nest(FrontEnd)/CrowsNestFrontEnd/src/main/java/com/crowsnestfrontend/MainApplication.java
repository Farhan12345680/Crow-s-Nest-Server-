package com.crowsnestfrontend;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.Utility.SyncManager;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Objects;

import static com.crowsnestfrontend.UserStream.constantStream.streamGetter;

public class MainApplication extends Application {

    @Override
    public void start(Stage stage) throws IOException, ClassNotFoundException {
        SceneManager.globalStage=stage;
        try {
            stage.getIcons().add(new Image(
                    Objects.requireNonNull(MainApplication.class.getResourceAsStream("images/raven.png"))
            ));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        Class.forName("com.crowsnestfrontend.Utility.SyncManager");

        stage.setTitle("Crow's Nest");
        SignBranchingHandler.signBranchLogicHandler();

        stage.show();

        stage.setResizable(false);
        stage.setOnCloseRequest(event -> {
            System.out.println(Owner.nameId);
            try(Socket socket=new Socket("localhost",12345);
                ObjectOutputStream writer=new ObjectOutputStream(socket.getOutputStream());
            ){

                writer.writeObject(new ClientRequest(10));
                writer.writeObject(new SignInProfile(Owner.nameId ,""));

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try(Socket socket=new Socket("localhost",12345);
                ObjectOutputStream writer=new ObjectOutputStream(socket.getOutputStream());
            ){

                writer.writeObject(new ClientRequest(10));
                writer.writeObject(new SignInProfile(Owner.nameId ,""));

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }));
        



        Thread.startVirtualThread(()->{
            try{
                SyncManager.allLoadingLatch.await();
                streamGetter() ;
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });
    };

    public static void main(String[] args) {
        launch();
    }
}