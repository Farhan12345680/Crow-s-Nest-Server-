package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.MainApplication;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.StackPane;
import java.io.IOException;

public class ChatBubble extends StackPane {


    public ChatBubble(String text) {

        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("chatBubble.fxml"));

        fxmlLoader.setRoot(this);

        try {
            fxmlLoader.load();
        } catch (IOException e) {
            System.out.println("Ërror occured " +e.getMessage());
        }
    }
}
