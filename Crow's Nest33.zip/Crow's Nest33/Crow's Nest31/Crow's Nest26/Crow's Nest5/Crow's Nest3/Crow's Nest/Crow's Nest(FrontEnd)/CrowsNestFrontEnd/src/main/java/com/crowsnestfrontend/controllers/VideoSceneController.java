package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.Utility.codeArea;
import javafx.animation.AnimationTimer;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import nu.pattern.OpenCV;
import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.LineNumberFactory;
import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;

import java.io.ByteArrayInputStream;
import java.util.Collection;
import java.util.regex.Matcher;
import java.util.Collection;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VideoSceneController {

    @FXML
    public ImageView otherView;   // remote peer video
    @FXML
    public ImageView endCall;
    @FXML
    public ImageView code;
    @FXML
    public ImageView camera;
    @FXML
    public ImageView mic;

    @FXML
    public ImageView selfView;

    @FXML
    public Pane videoContainer;
    @FXML
    public AnchorPane globalBox;
    @FXML
    public VBox voiceHolder;
    @FXML
    public HBox buttonHolder;
    @FXML
    public VBox codeArea;
    @FXML
    public VBox videoChatHolder;
    @FXML
    public Text ClientName;
    @FXML
    public Text UserName;

    private CodeArea codeBox;
    private AnimationTimer timer;
    private VideoCapture capture;

    private byte[] buffer;
    private WritableImage writableImage;
    private PixelWriter pixelWriter;
    private static final long ONE_FRAME_NS = 33_333_333;
    private static long curr=0;
    private int state=0;


    @FXML
    public void initialize() {

        UserName.setText(SelectedUserData.name.get());
        ClientName.setText(Owner.nameId);

        otherView.setImage(new Image(new ByteArrayInputStream(SelectedUserData.image)));

        codeBox=new codeArea();




        codeArea.getChildren().add(codeBox);
        codeArea.setVisible(false);
        codeArea.setManaged(false);


        voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        videoChatHolder.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight()-200);
        selfView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        selfView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        otherView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        otherView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        codeArea.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);
        codeArea.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() *90f/100);


        code.setOnMouseClicked((_)->{
            if(state==0){
                codeArea.setVisible(true);
                codeArea.setManaged(true);

                voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *30f/100);
            }
            else{
                codeArea.setVisible(false);
                codeArea.setManaged(false);
                voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
            }
            state++;
            state%=2;
        });
        endCall.setOnMouseClicked((_)->{
            stopCamera();
            SceneManager.globalStage.setScene(SceneManager.mainScene);
            SceneManager.globalStage.centerOnScreen();
            SceneManager.globalStage.show();
        });

        camera.setOnMouseClicked((_)->{
            cycleCamera();
        });


        startCamera();
    }

private void startCamera(){

        OpenCV.loadShared();

        capture= new VideoCapture(0 , Videoio.CAP_ANY);
        if(!capture.isOpened()){
            selfView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
            return;
        }

        Mat frame=new Mat();
        Mat rotated=new Mat();
        Mat converted=new Mat();

        timer=new AnimationTimer() {
            @Override
            public void handle(long now) {
                if(now-curr< ONE_FRAME_NS){
                    return;
                }
                curr=now;
                if(!capture.read(frame) || frame.empty()){
                    selfView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                    return;
                }

                Core.rotate(frame,rotated,Core.ROTATE_90_CLOCKWISE);
                Imgproc.cvtColor(rotated , converted ,Imgproc.COLOR_BGR2BGRA);


                int width=converted.width();
                int height=converted.height();

                if(buffer==null || buffer.length!=width*height*4){
                    buffer=new byte[width* height*4];
                    writableImage=new WritableImage(width,height);
                    pixelWriter=writableImage.getPixelWriter();
                    selfView.setImage(writableImage);
                }

                converted.get(0 , 0 , buffer);

                pixelWriter.setPixels(0 , 0 , width ,height , PixelFormat.getByteBgraInstance()
                        , buffer, 0 , width*4);
            }
        };

        timer.start();
}


    private void stopCamera() {
        if (timer != null) {
            timer.stop();
            timer = null;
        }
        if (capture != null) {
            if (capture.isOpened()) capture.release();
            System.out.println(capture.toString());
            capture = null;

        }
        pixelWriter=null;
        writableImage=null;
        Platform.runLater(() -> selfView.setImage(new Image(new ByteArrayInputStream(Owner.image))));
    }

    private void cycleCamera(){
        if(capture==null){
            startCamera();

        }else{
            stopCamera();
        }
    }

}
