package com.CodingFileLocks;

import java.io.Serializable;
import java.io.Serial;

public class newCodingFile implements Serializable {
        @Serial
    private static final long serialVersionUID = 99803L;

    public String fileName ;
    public String codeContent;

    public newCodingFile(String fileName , String codeContent ){
        this.fileName=fileName;
        this.codeContent=codeContent;
    }
}
