package com.PostFile;


import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;


public class DeleteFile extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 12492L;
    
    public int id;
    

    public DeleteFile(int id, String senderName ,
     String PostTitle , String PostDescription , byte[] fileContent){
        super(senderName);
        this.id=id;
    }   
}
