package com.ClientSerializedClasses;

import java.io.Serializable;

import com.crowsnestfrontend.SerializedClasses.payload;

import java.io.Serial;

public class currentlyInactive extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 1802L;

    public currentlyInactive(){
        super("");
    }   
}
