package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class askForScreenShareOwnerShip implements Serializable {
    @Serial
    private static final long serialVersionUID = 1720L;

    public askForScreenShareOwnerShip(){

    }
}
