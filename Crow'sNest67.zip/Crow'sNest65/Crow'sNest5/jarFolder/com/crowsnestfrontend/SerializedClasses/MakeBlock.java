package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class MakeBlock extends payload implements Serializable {
        
    @Serial
    private static final long serialVersionUID=35L;
    private final String name;
    
    public MakeBlock(String clientName , String name){
        super(clientName);
        this.name=name;
    }
    
    public String nameGetter(){
        return this.name;
    }
}
