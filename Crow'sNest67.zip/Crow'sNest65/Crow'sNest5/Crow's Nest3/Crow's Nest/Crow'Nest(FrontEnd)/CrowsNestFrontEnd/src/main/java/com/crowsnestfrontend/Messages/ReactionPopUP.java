package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SerializedClasses.payloadMessageReaction;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.Utility.ImageObjectHolder;
import com.crowsnestfrontend.controllers.mainSceneController;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Popup;
import org.opencv.imgproc.Imgproc;

import java.io.IOException;

import static com.crowsnestfrontend.UserStream.constantStream.payloadBlockingQueue;

public class ReactionPopUP extends HBox {
    @FXML
    public ImageView angry;
    @FXML
    public ImageView sad;
    @FXML
    public ImageView neutral;

    @FXML
    public ImageView love;
    @FXML
    public ImageView haha;
    public int messageID;

    @FXML
    public ImageView view;

    public ReactionPopUP(int messageID , Popup popup ,ImageView view){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("reactionPopUp.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        this.messageID=messageID;

        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.setOnMouseClicked(event -> popup.hide());
        this.setStyle("-fx-background-color: white; -fx-padding: 8; -fx-background-radius: 10; -fx-border-color: gray; -fx-border-radius: 10;");

        angry.setImage(ImageObjectHolder.IMG_ANGRY);
        sad.setImage(ImageObjectHolder.IMG_SAD);
        neutral.setImage(ImageObjectHolder.IMG_NEUTRAL);
        love.setImage(ImageObjectHolder.IMG_LOVE);
        haha.setImage(ImageObjectHolder.IMG_HAHA);
        neutral.setOnMouseClicked(e -> {setReaction(messageID, 0);
            view.setImage(ImageObjectHolder.IMG_NEUTRAL);
        });
        haha.setOnMouseClicked(e -> {setReaction(messageID, 1);
                view.setImage(ImageObjectHolder.IMG_HAHA);
        });
        love.setOnMouseClicked(e -> {setReaction(messageID, 2);
                view.setImage(ImageObjectHolder.IMG_LOVE);
        });
        angry.setOnMouseClicked(e ->{ setReaction(messageID, 3);
                            view.setImage(ImageObjectHolder.IMG_ANGRY);
        });
        sad.setOnMouseClicked(e -> {setReaction(messageID, 4);
                        view.setImage(ImageObjectHolder.IMG_SAD);
        });
    }
    private void setReaction(int messageID, int reaction) {

            Owner.messageConcurrentHashMap.get(messageID).reaction_type.set(reaction);
        localDataBaseGenerator.setUserReaction(reaction ,messageID);
            payloadBlockingQueue.add(new payloadMessageReaction(Owner.nameId, mainSceneController.name, messageID, reaction));

    }

}
