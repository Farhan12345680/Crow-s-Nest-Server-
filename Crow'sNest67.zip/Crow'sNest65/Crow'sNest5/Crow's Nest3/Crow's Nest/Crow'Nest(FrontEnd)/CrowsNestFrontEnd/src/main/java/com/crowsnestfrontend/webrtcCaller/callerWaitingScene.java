package com.crowsnestfrontend.webrtcCaller;

import com.ClientSerializedClasses.currentlyInactive;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class callerWaitingScene extends Pane {
    public static callerWaitingScene callerWaitingInstance;

    @FXML
    public ImageView CallingUserImage;

    @FXML
    public Text CallingUserName;

    @FXML
    public ImageView StopCalling;

    @FXML
    public Text currentlyCallingText;

    public Runnable run;

    public static callerWaitingScene initialize(Runnable run){
        if(callerWaitingInstance ==null){
            callerWaitingInstance=new callerWaitingScene(run);
        }

        return callerWaitingInstance;
    }
    public callerWaitingScene(Runnable run){

        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("currentlyCallingWaiting.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try{
            CallingUserImage.setImage(new Image(SelectedUserData.image));
        }catch (Exception e){
            e.printStackTrace();
        }

        CallingUserName.setText(SelectedUserData.name.get());
        StopCalling.setOnMouseClicked((a)->{
            Thread.startVirtualThread(()->{
                Platform.runLater(run);
                if(Caller.callerObject!=null){
                    Caller.callerObject.stopCaller();

                }
            });
            callerWaitingScene.callerWaitingInstance=null;
        });


        this.run=run;
    }

    public static void changeCurrentlyCallingText(String text){

        Platform.runLater(()->{
            callerWaitingInstance.currentlyCallingText.setStyle("-fx-font: 24");
            callerWaitingInstance.currentlyCallingText.setText(text);
        });
    }
}
