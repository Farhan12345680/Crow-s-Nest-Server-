package com.crowsnestfrontend.webrtcCaller.audioChannel;

import dev.onvoid.webrtc.media.audio.AudioSource;
import dev.onvoid.webrtc.media.audio.AudioTrackSource;

public class audioChannel {
    public static AudioTrackSource audioSource;
    
}
