package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.ClientSideDataBase.UserPayloadHandling;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.*;
import com.crowsnestfrontend.SerializedClasses.payloadFriendRequest;
import com.crowsnestfrontend.User.Owner;
import javafx.scene.layout.VBox;



public class constantFriendRequestStream {

    public static void streamCaller(payloadFriendRequest obj)  {

        Thread.startVirtualThread(()->{
                    pendingFriendRequest req=obj.getPfr();
                        if(Owner.current.containsKey(req.getName())){
                            if(!(Owner.friendRequest.containsKey(req.getName()))){
                                Owner.friendRequest.put(req.getName() ," ");

                                Owner.current.get(req.getName()).setIsFriend(2);
                                SceneManager.mainSceneContrller.addRequestUser(Owner
                                        .current.get(req.getName()));

                            }
                        }

                });

    }
}
