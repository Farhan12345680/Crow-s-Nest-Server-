package com.crowsnestfrontend.forum;

import com.crowsnestfrontend.MainApplication;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class forumViewLoading  extends VBox{
    public static forumViewLoading forumView;

    public static forumViewLoading initialize(){
        if(forumView==null){
            forumView=new forumViewLoading();
        }

        return forumView;
    }



    public forumViewLoading(){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.
                class.getResource("progressIndicatorVBox.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
