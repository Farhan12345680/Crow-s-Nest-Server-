package com.crowsnestfrontend.gifObject;

import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.UserStream.constantStream;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.awt.image.ImagingOpException;


public class gifObjectImageView extends ImageView {
    public String imageURL;

    public gifObjectImageView(String imageURL){
        super();

        this.imageURL=imageURL;

        this.setOnMouseClicked((e)->{
            if(this.imageURL==null
            ){
                return;
            }
            System.out.println("this gif message was clicked\n"+this.imageURL);
            constantStream.payloadBlockingQueue.add(new com.crowsnestfrontend.SerializedClasses.Message(

                    Owner.nameId,
                    SelectedUserData.name.get(),
                    "",
                    0, -1 , 2,this.imageURL)
            );
            String str=FileManager.storeImageOnFile(this.imageURL , "gif");
            System.out.println("ImageUrl sent to the other side "+str);
        });
    }

    public void setImageURL( String url){
        System.out.println("has this ever been called here \n1\n2\n3\n4");
        this.imageURL=url;

        super.setImage(new Image(url,true));
    }

    public void setNull(){
        this.imageURL=null;
        super.setImage(null);
    }
}
