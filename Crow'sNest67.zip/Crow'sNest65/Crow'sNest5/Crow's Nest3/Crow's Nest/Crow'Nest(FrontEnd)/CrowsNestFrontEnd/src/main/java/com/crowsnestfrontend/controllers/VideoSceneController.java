package com.crowsnestfrontend.controllers;

import com.ClientSerializedClasses.*;
import com.crowsnestfrontend.Utility.codeStackPane;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.webrtcCaller.*;
import com.crowsnestfrontend.webrtcCaller.videoChannel.DesktopVideoSink;
import com.crowsnestfrontend.webrtcCaller.videoChannel.videoChannel;
import dev.onvoid.webrtc.media.video.VideoTrack;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;

import okhttp3.Call;
import org.fxmisc.richtext.CodeArea;
import org.opencv.videoio.VideoCapture;

import java.io.IOException;
import java.util.Collections;

import static com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper.*;


public class VideoSceneController {

    @FXML
    public ImageView otherView;
    @FXML
    public ImageView endCall;
    @FXML
    public ImageView code;
    @FXML
    public ImageView camera;
    @FXML
    public ImageView mic;

    @FXML
    public ImageView selfView;

    @FXML
    public VBox voiceHolder;
    @FXML
    public HBox buttonHolder;
    @FXML
    public VBox codeArea;
    @FXML
    public VBox videoChatHolder;
    @FXML
    public Text ClientName;
    @FXML
    public Text UserName;

    public CodeArea codeBox;
    public VideoCapture capture;



    public volatile boolean cameraActive = false;
    @FXML
    public ImageView videoShare;

    public ScreenShare screenShare;

    public static int videoShower=0;

    public VBox ScreenShareController;



    @FXML
    public codeStackPane pane;

    {
        pane=new codeStackPane();

    }
    public VideoSceneChat current;
    @FXML
    public void initialize() throws IOException, InterruptedException {
        GlobalResourceKeeper.controller=this;

        ClientName.setText(SelectedUserData.name.get());
        UserName.setText(Owner.nameId);

        otherView.setImage(new Image( SelectedUserData.image));

        voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        videoChatHolder.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight()-200);
        selfView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        selfView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        otherView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        otherView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        codeArea.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);
        codeArea.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() *90f/100);


        pane=new codeStackPane();
        codeArea.getChildren().add(pane);

        codeArea.setVisible(false);
        codeArea.setManaged(false);
        pane.toFront();

        screenShare=new ScreenShare();
        codeArea.getChildren().add(screenShare);
        screenShare.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);

        code.setOnMouseClicked((e)->{
            if(Callee.callee!=null){
                return;
            }

            if(GlobalResourceKeeper.isScreeenShareActive.get()){
                return;
            }
            controller.pane.codeBox.setEditable(true);
            isCodeBlockOwnerMe.set(true);
            codeEditorRole.set(1);
            Caller.callerObject.sendObject(new startCodeBox());

            codeArea.setManaged(true);
            codeArea.setVisible(true);
            pane.setVisible(true);
            pane.setVisible(true);
            screenShare.setVisible(false);
            screenShare.setVisible(false);
            try {
                GlobalResourceKeeper.codeCaller(codeArea ,pane , voiceHolder);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        endCall.setOnMouseClicked((e)->{

            if(Caller.callerObject!=null){
                Caller.callerObject.sendObject(new endCall());
                Caller.callerObject.scheduleCleanup();
            }
            if(Callee.callee!=null){
                Callee.callee.sendObject(new endCall());
                Callee.callee.scheduleCleanup();
            }


            SceneManager.globalStage.setScene(SceneManager.mainScene);
            SceneManager.globalStage.centerOnScreen();
            SceneManager.globalStage.show();
        });

        camera.setOnMouseClicked((e)->{

            if(GlobalResourceKeeper.isSelfCameraActive.get()){
                GlobalResourceKeeper.isSelfCameraActive.set(false);
                try {
                    if(Caller.callerObject!=null){
                        if(videoChannel.videoSource!=null){
                            try{
                                videoChannel.videoSource.stop();
                                GlobalResourceKeeper.controller.selfView.setImage(new Image(Owner.image));
                            }catch (Throwable t1){
                                t1.printStackTrace();
                            }
                        }
                        Caller.callerObject.sendObject(new cameraStopOneEnd());
                    }else{
                        if(videoChannel.videoSource!=null){
                            try{
                                videoChannel.videoSource.stop();
                                GlobalResourceKeeper.controller.selfView.setImage(new Image(Owner.image));
                            }catch (Throwable t1){
                                t1.printStackTrace();
                            }
                            Callee.callee.sendObject(new cameraStopOneEnd());

                        }
                    }
                }catch (Throwable a){
                    a.printStackTrace();
                }
                GlobalResourceKeeper.isSelfCameraActive.set(false);
                return;
            }
            GlobalResourceKeeper.isSelfCameraActive.set(true);

            try {
                if(Caller.callerObject!=null){
                    if(videoChannel.videoSource!=null){
                        try{
                            videoChannel.videoSource.start();
                            GlobalResourceKeeper.controller.selfView.setImage(new Image(Owner.image));
                        }catch (Throwable t1){
                            t1.printStackTrace();
                        }
                        Caller.callerObject.sendObject(new cameraStartOneEnd());

                    }
                }else{
                    if(videoChannel.videoSource!=null){
                        try{
                            videoChannel.videoSource.start();
                            GlobalResourceKeeper.controller.selfView.setImage(new Image(Owner.image));
                        }catch (Throwable t1){
                            t1.printStackTrace();
                        }
                        Callee.callee.sendObject(new cameraStartOneEnd());

                    }
                }
            }catch (Throwable a){
                a.printStackTrace();
            }

            GlobalResourceKeeper.isSelfCameraActive.set(true);
            return;

        });

        videoShare.setOnMouseClicked((e)->{
            helperFunc();

        });



        current=new VideoSceneChat();
        buttonHolder.getChildren().add(current);

        //resource.startCamera();
    }

    public  void helperFunc(){

        if(isScreeenShareActive.get() && !(isVideoShareOwnerMe.get())){
            return;
        }

        if(GlobalResourceKeeper.isCodeBlockActive.get()){

            return;
        }


        if(!isScreeenShareActive.get()){
            pane.setVisible(false);
            pane.setManaged(false);
            if(Caller.callerObject!=null){
                Caller.callerObject.sendObject(new startScreenShare());
            }else {
                Callee.callee.sendObject(new startScreenShare());
            }

            GlobalResourceKeeper.isScreeenShareActive.set(true);
            GlobalResourceKeeper.isVideoShareOwnerMe.set(true);

            GlobalResourceKeeper.startDesktopVideoCapture();
            controller.screenShare.StatusLabel.setText("You are sharing the screen ");

            codeArea.setManaged(true);
            codeArea.setVisible(true);
            screenShare.setVisible(true);
            screenShare.setManaged(true);

            screenShare.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);
            screenShare.ScreenImage.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);

            voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *30f/100);
            isScreeenShareActive.set(true );
        }
        else{
            pane.setVisible(false);
            pane.setManaged(false);
            isScreeenShareActive.set(false );
            GlobalResourceKeeper.isVideoShareOwnerMe.set(false);

            GlobalResourceKeeper.endDesktopVideoCapture();

            if(Caller.callerObject!=null){
                Caller.callerObject.sendObject(new endScreenShare());
            }else {
                Callee.callee.sendObject(new endScreenShare());
            }


            voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
            screenShare.setManaged(false);
            screenShare.setVisible(false);


        }


        videoShower++;
        videoShower%=2;
    }

    public void CalleeStartHelperFunc() {

        GlobalResourceKeeper.isScreeenShareActive.set(true);
        pane.setVisible(false);
        pane.setManaged(false);


        codeArea.setManaged(true);
        codeArea.setVisible(true);
        screenShare.setVisible(true);
        screenShare.setManaged(true);
        isScreeenShareActive.set(true);

        GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
        screenShare.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);
        screenShare.ScreenImage.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);

        voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *30f/100);
    }

    public void CalleeEndHelperFunc(){
        pane.setVisible(false);
        pane.setManaged(false);
        GlobalResourceKeeper.isScreeenShareActive.set(false);


        isScreeenShareActive.set(false);
        GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
        voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        screenShare.setManaged(false);
        screenShare.setVisible(false);

    }

    public void CallerStartHelperFunc() {

        GlobalResourceKeeper.isScreeenShareActive.set(true);

        pane.setVisible(false);
        pane.setManaged(false);


        screenShare.setVisible(true);
        screenShare.setManaged(true);
        isScreeenShareActive.set(true);
        GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
        screenShare.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);
        screenShare.ScreenImage.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);

        voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *30f/100);
    }

    public void CallerEndHelperFunc(){
        pane.setVisible(false);

        isScreeenShareActive.set(false);
        GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
        voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        screenShare.setManaged(false);
        screenShare.setVisible(false);

    }
}
