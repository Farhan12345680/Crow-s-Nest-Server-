package com.crowsnestfrontend.webrtcCaller;

import com.ClientSerializedClasses.*;
import com.CodingFileLocks.giveUpLock;
import com.CodingFileLocks.newCodingFile;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.returnIceObject;
import com.crowsnestfrontend.SerializedClasses.webrtcConnection;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.Utility.codeArea;
import com.crowsnestfrontend.webrtcCaller.audioChannel.JavaFXAudioSink;
import com.crowsnestfrontend.webrtcCaller.videoChannel.DesktopVideoSink;
import com.crowsnestfrontend.webrtcCaller.videoChannel.JavaFXVideoSink;
import com.crowsnestfrontend.webrtcCaller.videoChannel.JavafxSelfViewSink;
import com.crowsnestfrontend.webrtcCaller.videoChannel.videoChannel;
import dev.onvoid.webrtc.*;
import dev.onvoid.webrtc.media.MediaDevices;
import dev.onvoid.webrtc.media.MediaStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import dev.onvoid.webrtc.media.MediaStreamTrack;
import dev.onvoid.webrtc.media.audio.*;
import dev.onvoid.webrtc.media.video.VideoTrack;
import javafx.application.Platform;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.StageStyle;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;

import java.util.Queue;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.crowsnestfrontend.MainApplication.client;
import static com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper.videoTrack;
import static com.crowsnestfrontend.webrtcCaller.audioChannel.audioChannel.audioSource;
import static com.crowsnestfrontend.webrtcCaller.videoChannel.videoChannel.videoSource;

public class Callee {
    public static Callee callee;

    private PeerConnectionFactory factory;
    public RTCPeerConnection pc;
    private RTCDataChannel dataChannel;
    private final String name;

    private final List<RTCIceCandidate> pendingIce = Collections.synchronizedList(new ArrayList<>());

    private final AtomicBoolean cleaned = new AtomicBoolean(false);
    private final ExecutorService cleanupExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "callee-cleanup");
        t.setDaemon(true);
        return t;
    });

    public static synchronized Callee initialize(String name) {
        if (callee == null || callee.pc == null || callee.cleaned.get()) {
            callee = new Callee(name);
        }
        return callee;
    }
    private final JavaFXAudioSink audioFrameLogger = new JavaFXAudioSink();
    private final JavaFXVideoSink videoFrameLogger = new JavaFXVideoSink();
    private JavafxSelfViewSink selfSink = new JavafxSelfViewSink();
    private  final DesktopVideoSink DesktopSink=new DesktopVideoSink();
    private  final DesktopVideoSink DesktopSink2=new DesktopVideoSink();
    private VideoTrack desktopTrack =null;

    //public audio processing
    //public audio processing
    public AudioProcessing audioProcessing;
    public  AudioProcessingConfig config1;
    public AudioDeviceModule audioModule;
    public AudioDevice defaultMic;
    public AudioDevice defaultSpeaker;
    AudioTrack audioTrackSource;
    AudioOptions audioOptions;



    public Callee(String name) {


        this.name = name;
        factory = new PeerConnectionFactory(  );
        RTCConfiguration config = new RTCConfiguration();

        RTCIceServer iceServer = new RTCIceServer();
        iceServer.urls.add("stun:stun.l.google.com:19302");
        config.iceServers.add(iceServer);


        pc = factory.createPeerConnection(config, new PeerConnectionObserver() {
            @Override
            public void onDataChannel(RTCDataChannel channel) {
                System.out.println("Callee received data channel: " + channel.getLabel());

                channel.registerObserver(new RTCDataChannelObserver() {
                    @Override
                    public void onBufferedAmountChange(long l) { }

                    @Override
                    public void onStateChange() {
                        RTCDataChannelState state = dataChannel.getState();
                        System.out.println("Data channel state changed to: " + state);

                        switch (state) {
                            case CONNECTING:
                                System.out.println("Data channel is being established");
                                break;

                            case OPEN:
                                System.out.println("Data channel is open and ready to use");
                                System.out.println("""
                                Data channel is opened
                                Data channel is opened again 
                                Data channel is opened again two
                                
                                """);
                                Thread.startVirtualThread(() -> {
                                    // only send when channel is open
                                    if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
                                        sendObject(new offer(Owner.nameId, FileManager.getImageUniqueId()));
                                        //sendMessage("hello peer how are you doing");
                                    }
                                });
                                break;

                            case CLOSING:
                            case CLOSED:
                                Platform.runLater(()->{
                                            SceneManager.globalStage.setScene(SceneManager.mainScene);
                                            SceneManager.globalStage.centerOnScreen();
                                            SceneManager.globalStage.show();
                                        }
                                );
                                scheduleCleanupAndUiNotify();
                                break;
                        }
                    }
                    @Override
                    public void onMessage(RTCDataChannelBuffer buffer) {
                        try {
                            if (!buffer.binary) {
                                buffer.data.rewind();
                                String msg = StandardCharsets.UTF_8.decode(buffer.data).toString();
                                VideoChatBox.initialize().insertIntoMessage(SelectedUserData.name.get(),
                                        msg);
                                GlobalResourceKeeper.controller.current.setVisibility();

                                return;
                            }

                            ByteBuffer bb = buffer.data;
                            byte[] bytes = new byte[bb.remaining()];
                            bb.get(bytes);

                            Thread.startVirtualThread(() -> handleBinaryMessage(channel, bytes));
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }

                });

                dataChannel = channel;
            }

            @Override
            public void onTrack(RTCRtpTransceiver transceiver) {
                MediaStreamTrack track = transceiver.getReceiver().getTrack();
                String kind = track.getKind();

                if (kind.equals(MediaStreamTrack.AUDIO_TRACK_KIND)) {
                    AudioTrack audioTrack = (AudioTrack) track;
                    audioTrack.addSink(audioFrameLogger);
                }


                String y =track.getId();


                if (kind.equals(MediaStreamTrack.VIDEO_TRACK_KIND)) {
                    System.out.println("this is the type of the video track "+ y);
                    if (y.equals("desktopTrack")) {
                        VideoTrack videoTrack = (VideoTrack) track;
                        videoTrack.addSink(DesktopSink2);
                    }
                    else{
                        GlobalResourceKeeper.isOtherCameraActive.set(true);
                        VideoTrack videoTrack = (VideoTrack) track;
                        videoTrack.addSink(videoFrameLogger);
                    }


                }

                System.out.println("Caller: Transceiver track added: " + kind);
            }


            @Override public void onIceCandidate(RTCIceCandidate candidate) {
                System.out.println("Callee ICE: " + candidate.sdp);
                var obj = new returnIceObject(
                        Owner.nameId,
                        name,
                        candidate.sdp,
                        candidate.sdpMid,
                        candidate.sdpMLineIndex
                );
                constantStream.payloadBlockingQueue.add(obj);
            }

            @Override public void onIceConnectionChange(RTCIceConnectionState state) {}
            @Override public void onIceGatheringChange(RTCIceGatheringState state) {}
            @Override public void onSignalingChange(RTCSignalingState state) {}
            @Override public void onAddStream(MediaStream stream) {}
            @Override public void onRemoveStream(MediaStream stream) {}
            @Override public void onRenegotiationNeeded() {}
        });

        try{
            boolean storage=false;
            try{
                storage=videoChannel.isAnyCameraResourceAvailable();
            }catch (Exception e){
                e.printStackTrace();

            }catch (Throwable e){
                e.printStackTrace();
            }
            if(storage){
                videoSource.start();
                videoTrack = factory.createVideoTrack("video0", videoSource);

                videoTrack.addSink(selfSink);
                pc.addTrack(videoTrack , Collections.singletonList("cameraCaptureList"));

                GlobalResourceKeeper.isSelfCameraActive.set(true);
            }else{
                if(GlobalResourceKeeper.controller!=null){
                    GlobalResourceKeeper.controller.selfView.setImage(new Image(Owner.image));

                }
                videoTrack=null;
            }


        }
        catch (Exception e){
            e.printStackTrace();
        }

        try{
            GlobalResourceKeeper.startDesktopVideoCapture();
            desktopTrack = factory.createVideoTrack("desktopTrack", GlobalResourceKeeper.videoSource);
            desktopTrack.addSink(this.DesktopSink);
            this.pc.addTrack(desktopTrack, Collections.singletonList("desktopTrack"));
            GlobalResourceKeeper.endDesktopVideoCapture();
        }
        catch (Throwable e){
            e.printStackTrace();
        }



        try{
            Thread.startVirtualThread(()->{
                List<AudioDevice> captureDevices = MediaDevices.getAudioCaptureDevices();
                if (captureDevices.isEmpty()) {
                    System.err.println("No audio capture devices found.");
                    return;
                }

                defaultMic = MediaDevices.getDefaultAudioCaptureDevice();
                defaultSpeaker = MediaDevices.getDefaultAudioRenderDevice();

                audioModule = new AudioDeviceModule();
                audioModule.setRecordingDevice(defaultMic);
                audioModule.setPlayoutDevice(defaultSpeaker);

                audioModule.initRecording();
                audioModule.initPlayout();

                audioProcessing = new AudioProcessing();
                config1 = new AudioProcessingConfig();
                config1.echoCanceller.enabled = true;
                config1.noiseSuppression.enabled = true;
                config1.noiseSuppression.level = AudioProcessingConfig.NoiseSuppression.Level.MODERATE;

                audioProcessing.applyConfig(config1);

                audioOptions = new AudioOptions();
                audioOptions.echoCancellation = true;
                audioOptions.autoGainControl = true;
                audioOptions.noiseSuppression = true;

                audioSource =  factory.createAudioSource(audioOptions);
                audioTrackSource = factory.createAudioTrack("audio1", (AudioTrackSource) audioSource);


                // Add audio track to peer connection
                pc.addTrack(audioTrackSource, Collections.singletonList("micAudioInput"));
                System.out.println("audio input completed ");
            }).join();

//            audioTrackSource = factory.createAudioTrack("audio1", (AudioTrackSource) audioSource);


//            pc.addTrack(audioTrackSource,Collections.singletonList("micAudioInput"));
            GlobalResourceKeeper.isSelfCameraActive.set(true);

        }
        catch (Throwable a){
            a.printStackTrace();
        }
    }

    private void handleBinaryMessage(RTCDataChannel channel, byte[] bytes) {
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bytes))) {
            Object obj = ois.readObject();

            if (obj instanceof offer off) {
                System.out.println("Received Offer object");
                Platform.runLater(() -> {
                    Dialog<Void> dialog = new Dialog<>();
                    dialog.setDialogPane(new DialogPane());

                    ButtonType tempButton = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
                    dialog.getDialogPane().getButtonTypes().add(tempButton);
                    dialog.getDialogPane().lookupButton(tempButton).setVisible(false);
                    dialog.getDialogPane().lookupButton(tempButton).setManaged(false);
                    dialog.initStyle(StageStyle.UNDECORATED);
                    CallerIncoming calling=null;
                    try{
                        calling = new CallerIncoming(off.name, off.image, dialog::close);

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    dialog.getDialogPane().setContent(calling);
                    dialog.show();
                });
            }
            else if (obj instanceof accept acc) {
                System.out.println("Received Accept object");
            }
            else if (obj instanceof String str) {
                System.out.println("Received serialized String: " + str);
            }
            else if (obj instanceof offerReject) {
                System.out.println("Received offerReject -> schedule cleanup");
                scheduleCleanupAndUiNotify();
            }
            else if(obj instanceof endCall){
                Platform.runLater(()->{
                    SceneManager.globalStage.setScene(SceneManager.mainScene);
                    SceneManager.globalStage.centerOnScreen();
                    SceneManager.globalStage.show();
                });

                try{
                    this.stoppedByCaller();
                }catch (Throwable t){
                    t.printStackTrace();
                }
            }
            else if(obj instanceof startCodeBox){
                System.out.println("a request came through here "+Owner.nameId);
                Platform.runLater(()->{
                    try{
                        GlobalResourceKeeper.isCodeBlockOwnerMe.set(false);
                        GlobalResourceKeeper.codeEditorRole.set(2);

                        GlobalResourceKeeper.codeCaller(GlobalResourceKeeper.controller.codeArea,GlobalResourceKeeper.controller.pane,
                                GlobalResourceKeeper.controller.voiceHolder);
                        GlobalResourceKeeper.controller.pane.ControlLabel.setText(SelectedUserData.name.get()+" has the lock");

                        GlobalResourceKeeper.controller.pane.Save.setVisible(false);
                        GlobalResourceKeeper.controller.pane.Save.setManaged(false);
                        GlobalResourceKeeper.controller.pane.OpenANewFile.setVisible(false);
                        GlobalResourceKeeper.controller.pane.OpenANewFile.setManaged(false);
                        GlobalResourceKeeper.controller.pane.GiveUpLock.setVisible(false);
                        GlobalResourceKeeper.controller.pane.GiveUpLock.setManaged(false);
                        ((codeArea)GlobalResourceKeeper.controller.pane.codeBox).extraCaret.moveTo(0,0);
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                });
            }
            else if(obj instanceof giveUpLock){
                GlobalResourceKeeper.isCodeBlockOwnerMe.set(true);
                Platform.runLater(()->{
                    GlobalResourceKeeper.controller.pane.ControlLabel.setText("You have the coding lock");
                    GlobalResourceKeeper.controller.pane.codeBox.setEditable(true);
                    GlobalResourceKeeper.controller.pane.GiveUpLock.setVisible(true);
                    GlobalResourceKeeper.controller.pane.GiveUpLock.setManaged(true);

                });
            }
            else if(obj instanceof  caretPosition){
                Platform.runLater(() -> {

                    var t = (caretPosition) obj;

                    ((codeArea)GlobalResourceKeeper.controller.pane.codeBox).extraCaret.moveTo(t.y,t.x);


                });

            }
            else if(obj instanceof  textChange){
                Platform.runLater(() -> {
                    var t= (textChange)obj;
                    int x=  GlobalResourceKeeper.controller.pane.getCodeBox().getCaretColumn();
                    int y= GlobalResourceKeeper.controller.pane.getCodeBox().getCurrentParagraph();

                    GlobalResourceKeeper.controller.pane.getCodeBox().replaceText(t.pos, t.pos + t.removed.length(), t.inserted);

                    GlobalResourceKeeper.controller.pane.getCodeBox().moveTo(y , x);
                });
            }
            else if(obj instanceof cameraStartOneEnd){
                Platform.runLater(()->{
                    GlobalResourceKeeper.isOtherCameraActive.set(true);

                });
            }
            else if (obj instanceof  cameraStopOneEnd){
                Platform.runLater(()->{
                    GlobalResourceKeeper.isOtherCameraActive.set(false);
                    GlobalResourceKeeper.controller.otherView.setImage(new Image(SelectedUserData.image));
                });
            }
            else if(obj instanceof  startScreenShare){
                Platform.runLater(()->{
                    GlobalResourceKeeper.isVideoShareActive.set(false);
                    GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
                    GlobalResourceKeeper.controller.CalleeStartHelperFunc();
                    GlobalResourceKeeper.controller.screenShare.StatusLabel.setText(SelectedUserData.name.get() + " is Sharing");

                });
            }
            else if (obj instanceof  endScreenShare){
                Platform.runLater(()->{
                    GlobalResourceKeeper.isVideoShareActive.set(false);
                    GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
                    GlobalResourceKeeper.controller.CalleeEndHelperFunc();

                });
            }
            else if(obj instanceof newCodingFile){
                Platform.runLater(() -> {
                    GlobalResourceKeeper.controller.codeBox.clear();
                    GlobalResourceKeeper.controller.codeBox.replaceText(((newCodingFile)obj).codeContent);
                    GlobalResourceKeeper.controller.pane.currentFileLabel.setText("Working on: "+((newCodingFile)obj).fileName);
                });
            }
            else {
                System.out.println("Unknown binary object: " + obj.getClass().getName());
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public synchronized  void sendMessage(String message) {
        if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
            byte[] data = message.getBytes();
            try {
                RTCDataChannelBuffer buffer = new RTCDataChannelBuffer(ByteBuffer.wrap(data), false);
                dataChannel.send(buffer);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("Callee data channel is not open");
        }
    }

    public synchronized  void sendObject(Object object) {


        Thread.startVirtualThread(() -> {

            try {
                if (dataChannel == null || dataChannel.getState() != RTCDataChannelState.OPEN) {
                    System.err.println("sendObject: dataChannel not open");
                    return;
                }
                try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
                     ObjectOutputStream oos = new ObjectOutputStream(baos)) {
                    oos.writeObject(object);
                    oos.flush();
                    byte[] bytes = baos.toByteArray();
                    dataChannel.send(new RTCDataChannelBuffer(ByteBuffer.wrap(bytes), true));
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
        });
    }

    public void onOfferReceived(RTCSessionDescription offer, String fromName) {
        if (pc == null) {
            System.err.println("onOfferReceived ignored: pc is null");
            return;
        }
        pc.setRemoteDescription(offer, new SetSessionDescriptionObserver() {
            @Override
            public void onSuccess() {
                System.out.println("Callee remote SDP set, creating answer...");
                createAnswer(fromName);
                for (RTCIceCandidate c : pendingIce) {
                    pc.addIceCandidate(c);
                }
                pendingIce.clear();
            }
            @Override
            public void onFailure(String error) {
                System.err.println("Callee failed to set remote: " + error);
            }
        });
    }

    private void createAnswer(String fromName) {
        if (pc == null) {
            System.err.println("createAnswer ignored: pc is null");
            return;
        }
        RTCAnswerOptions options = new RTCAnswerOptions();
        pc.createAnswer(options, new CreateSessionDescriptionObserver() {
            @Override
            public void onSuccess(RTCSessionDescription answer) {
                if (pc == null) return;
                pc.setLocalDescription(answer, new SetSessionDescriptionObserver() {
                    @Override
                    public void onSuccess() {
                        System.out.println("Callee local SDP set");
                        var obj = new webrtcConnection(
                                Owner.nameId,
                                fromName,
                                "ANSWER",
                                answer.sdp
                        );
                        constantStream.payloadBlockingQueue.add(obj);
                    }
                    @Override
                    public void onFailure(String error) {
                        System.err.println("Callee failed to set local: " + error);
                    }
                });
            }
            @Override
            public void onFailure(String error) {
                System.err.println("Callee failed to create answer: " + error);
            }
        });
    }

    public void onIceCandidate(RTCIceCandidate candidate) {
        if (pc == null) {
            pendingIce.add(candidate);
        } else {
            pc.addIceCandidate(candidate);
        }
    }

    private void scheduleCleanupAndUiNotify() {
        scheduleCleanup();
        Platform.runLater(() -> {
            if (CallerIncoming.incoming != null) {
                try {
                    CallerIncoming.incoming.stopCall();
                } catch (Throwable ignored) {}
                CallerIncoming.incoming = null;
            }
            if (callerWaitingScene.callerWaitingInstance != null) {
                try {
                    callerWaitingScene.callerWaitingInstance.run.run();
                } catch (Throwable ignored) {}
                callerWaitingScene.callerWaitingInstance = null;
            }
        });
    }

    public void scheduleCleanup() {
        GlobalResourceKeeper.isSelfCameraActive.set(false);
        GlobalResourceKeeper.isScreeenShareActive.set(false);
        GlobalResourceKeeper.isCodeBlockActive.set(false);
        GlobalResourceKeeper.isOtherCameraActive.set(false);
        GlobalResourceKeeper.isScreeenShareActive.set(false);
        Thread.startVirtualThread(this::cleanUpWebrtc);
    }

    private void cleanUpWebrtc(){
        if (!cleaned.compareAndSet(false, true)) return;

        cleanupExecutor.execute(() -> {
            try {

                    GlobalResourceKeeper.isSelfCameraActive.set(false);
                    GlobalResourceKeeper.isCodeBlockActive.set(false);
                    GlobalResourceKeeper.isSelfCameraActive.set(false);
                    GlobalResourceKeeper.isScreeenShareActive.set(false);
                    GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
                    GlobalResourceKeeper.isVideoShareActive.set(false);

                    try{
                        videoSource.stop();
                        videoSource.dispose();
                    }
                    catch (Throwable a){
                        a.printStackTrace();
                    }

                    try{
                        desktopTrack.removeSink(DesktopSink);
                    }catch (Throwable e){
                        e.printStackTrace();
                    }
                    try{
                        desktopTrack.setEnabled(false);
                        desktopTrack.dispose();
                    }catch (Throwable e){
                        e.printStackTrace();
                    }
                // close dataChannel first
                if (dataChannel != null) {
                    try { dataChannel.unregisterObserver(); }
                    catch (Throwable ignored) {}
                    try { dataChannel.close(); } catch (Throwable ignored) {}
                    try { dataChannel.dispose(); } catch (Throwable ignored) {}
                    dataChannel = null;
                }
                if(videoChannel.videoSource!=null){
                    try{
                        videoChannel.videoSource.stop();
                        videoChannel.videoSource.dispose();
                    }catch (Throwable t1){
                        t1.printStackTrace();
                    }
                }

                if(GlobalResourceKeeper.videoTrack!=null){
                    try{
                        GlobalResourceKeeper.videoTrack.removeSink(selfSink);
                    }catch (Throwable t){
                        t.printStackTrace();
                    }

                }

                if(GlobalResourceKeeper.videoTrack!=null){
                    try{
                        GlobalResourceKeeper.videoTrack.dispose();
                    }catch (Throwable t){
                        t.printStackTrace();
                    }
                }

                if (pc != null) {
                    try { pc.close(); } catch (Throwable t) { System.err.println("pc.close() error: "+t.getMessage()); }
                    pc = null;
                }

                if (factory != null) {
                    try { factory.dispose(); } catch (Throwable t) { System.err.println("factory.dispose() error: "+t.getMessage()); }
                    factory = null;
                }

                // clear singleton
                callee = null;
            }
            finally {
            }
        });
    }

    private void stoppedByCaller(){
        if (!cleaned.compareAndSet(false, true)) return;
        cleanupExecutor.execute(() -> {
            try {
                GlobalResourceKeeper.isSelfCameraActive.set(false);
                GlobalResourceKeeper.isCodeBlockActive.set(false);
                GlobalResourceKeeper.isSelfCameraActive.set(false);
                GlobalResourceKeeper.isScreeenShareActive.set(false);
                GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
                GlobalResourceKeeper.isVideoShareActive.set(false);

                try{
                    videoSource.stop();
                    videoSource.dispose();
                }
                catch (Throwable a){
                    a.printStackTrace();
                }

                try{
                    desktopTrack.removeSink(DesktopSink);
                }catch (Throwable e){
                    e.printStackTrace();
                }
                try{
                    desktopTrack.setEnabled(false);
                    desktopTrack.dispose();
                }catch (Throwable e){
                    e.printStackTrace();
                }

                if (dataChannel != null  ) {
                    try { dataChannel.unregisterObserver(); }
                    catch (Throwable ignored) {ignored.printStackTrace();}
                    try { dataChannel.close(); } catch (Throwable ignored) {ignored.printStackTrace();}
                    try { dataChannel.dispose(); } catch (Throwable ignored) {ignored.printStackTrace();}
                    dataChannel = null;
                }
                if(videoChannel.videoSource!=null){
                    try{
                        videoChannel.videoSource.stop();
                        videoChannel.videoSource.dispose();
                    }catch (Throwable t1){
                        t1.printStackTrace();
                    }
                }

                if(GlobalResourceKeeper.videoTrack!=null){
                    try{
                        GlobalResourceKeeper.videoTrack.removeSink(selfSink);
                    }catch (Throwable t){
                        t.printStackTrace();
                    }

                }

                if(GlobalResourceKeeper.videoTrack!=null){
                    try{
                        GlobalResourceKeeper.videoTrack.dispose();
                    }catch (Throwable t){
                        t.printStackTrace();
                    }
                }
                if (pc != null) {
                    try { pc.close(); } catch (Throwable t) { t.printStackTrace(); }
                    pc = null;
                }

                if (factory != null) {
                    try { factory.dispose(); } catch (Throwable t) { System.err.println("factory.dispose() error: "+t.getMessage()); }
                    factory = null;
                }

                callee = null;
            } finally {
            }
        });

    }

    public void stopCallee() {
        sendObject(new endCall());
        Thread.startVirtualThread(this::scheduleCleanupAndUiNotify);
    }
}
