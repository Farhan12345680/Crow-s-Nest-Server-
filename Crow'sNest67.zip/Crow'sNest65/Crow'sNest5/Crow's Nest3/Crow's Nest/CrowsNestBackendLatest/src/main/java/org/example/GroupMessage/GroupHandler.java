package org.example.GroupMessage;

import com.groupManagement.createGroup;
import org.example.DatabaseCreation.DatabaseCreation;

import java.sql.*;

public class GroupHandler {


    public static void groupCreation(createGroup groupReq ){
        String QueryString ="Insert into GroupChannel(ChannelName, groupDescription , groupImageURL , groupCreator) values(?,?,?,?)";


            try(Connection conn = DriverManager.getConnection(DatabaseCreation.URL);
                PreparedStatement ps = conn.prepareStatement(QueryString , Statement.RETURN_GENERATED_KEYS)) {

                ps.setString(1 , groupReq.groupName);
                ps.setString(2 , groupReq.groupDescription);
                ps.setString(4,  groupReq.clientName);

                if(groupReq.groupImageURL!=null){

                    ps.setString(3,  groupReq.groupImageURL);
                }else{
                    ps.setString(3,  groupReq.groupImageURL);

                }


                ps.executeUpdate();
            }catch (Exception e){
                e.printStackTrace();
            }
            return;

    }


    public static void deleteGroup(){

    }

    public static void changeGroupImage(){

    }

    public static void giveGroupDetails(){

    }
}
