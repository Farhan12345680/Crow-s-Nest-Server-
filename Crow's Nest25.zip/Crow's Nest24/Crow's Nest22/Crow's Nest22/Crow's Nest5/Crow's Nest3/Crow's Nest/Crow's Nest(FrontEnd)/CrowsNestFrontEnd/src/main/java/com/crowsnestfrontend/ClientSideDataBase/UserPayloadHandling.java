package com.crowsnestfrontend.ClientSideDataBase;

import com.crowsnestfrontend.SerializedClasses.payLoadUsers;
import com.crowsnestfrontend.SerializedClasses.updateStatus;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UserPayloadHandling {

    public static void userPayloadHandling(payLoadUsers users){
        String insertIntoProfile= """
            Insert into Contacts(name_id ,image) VALUES (?,?);
            """;
        try(Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString)
            ;PreparedStatement ps=conn.prepareStatement(insertIntoProfile)
        ){
            ps.setString(1 , users.getRequestUser().getUserName());
            ps.setBytes(2 , users.getRequestUser().getProfilePicture());

            int isSuccessful =ps.executeUpdate();

            if(isSuccessful==1){

            }else {

            }
        }catch (Exception e){
            e.printStackTrace();
        }


    }

    public static void friendUserPayloadHandling(updateStatus user){
        String ss= """
                UPDATE is_friend=1 WHERE name_id =?;
                """;

        try(Connection conn =DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
            PreparedStatement ps = conn.prepareStatement(ss)){
            ps.setString(1 ,user.getRequestUser().getUserName());

            int i=ps.executeUpdate();
        }catch (Exception e){

        }
    }



}
