package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.MainApplication;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

import java.io.IOException;

public class MessageCell extends ListCell<Message> {

    @FXML
    private Label messageLabel;

    @FXML
    private HBox OwnerMessage;

    private FXMLLoader loader;


    @FXML
    private Label BubbleTime;
    @FXML
    private Pane reactionPanel;
    @FXML
    private ImageView reactionImage;

    @Override
    protected void updateItem(Message message, boolean empty) {
        super.updateItem(message, empty);

        if (empty || message == null) {
            setText(null);
            setGraphic(null);
            return;
        }

        if (loader == null) {
            loader = new FXMLLoader(MainApplication.class.getResource("chatBubble.fxml"));
            loader.setController(this);
;
            try {
                loader.load();
                System.out.println("loader loaded");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        messageLabel.setText(message.getText());
        if (message.isOwnMessage()) {
            OwnerMessage.setStyle("-fx-alignment: center-right;");
            messageLabel.setStyle("-fx-background-color: #DCF8C6; -fx-padding: 8px; -fx-background-radius: 12px;");
        }
        else {
            OwnerMessage.setStyle("-fx-alignment: center-left;");
            messageLabel.setStyle("-fx-background-color: #FFFFFF; -fx-padding: 8px; -fx-background-radius: 12px;");
        }

        reactionImage.setOnMouseClicked((_)->{
            reactionPanel.setVisible(!reactionPanel.isVisible());
            reactionPanel.setManaged(!reactionPanel.isManaged());
        });
        reactionPanel.setVisible(false);
        reactionPanel.setManaged(false);
        BubbleTime.setText(message.formattedTime);
        setText(null);
        setGraphic(OwnerMessage);
    }
}
