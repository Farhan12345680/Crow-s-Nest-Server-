package org.example;

import com.crowsnestfrontend.SerializedClasses.*;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Random;

public class SignUpTesting {

    private static final Random RANDOM = new Random();

    public static String randomStringGeneration() {
        StringBuilder curr = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            curr.append((char) ('A' + RANDOM.nextInt(26)));
        }
        return curr.toString();
    }

    public static void main(String[] args) {
        System.out.println(" Starting infinite signup tester...");

        Thread.startVirtualThread(() -> {
            byte[] whitePixel = new byte[] {
                    (byte)0x89, 0x50, 0x4E, 0x47,
                    0x0D, 0x0A, 0x1A, 0x0A,
                    0x00, 0x00, 0x00, 0x0D,
                    0x49, 0x48, 0x44, 0x52,
                    0x00, 0x00, 0x00, 0x01,
                    0x00, 0x00, 0x00, 0x01,
                    0x08,
                    0x02,
                    0x00,
                    0x00,
                    0x00,
                    (byte)0x90, 0x77, 0x53, (byte)0xDE,
                    0x00, 0x00, 0x00, 0x0A,
                    0x49, 0x44, 0x41, 0x54,
                    0x08, (byte)0xD7, 0x63, (byte) 0xF8, (byte) 0xCF, (byte) 0xC0, 0x00, 0x00,
                    0x04, 0x00, 0x01,
                    (byte)0x05, (byte)0xBF, 0x02, (byte)0xFE,
                    0x00, 0x00, 0x00, 0x00,
                    0x49, 0x45, 0x4E, 0x44,
                    (byte)0xAE, 0x42, 0x60, (byte)0x82
            };

            for(int j=0;j<10; j++) {
                try (
                        Socket clientSocket = new Socket("localhost", 12345);
                        ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                        ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream())
                ) {
                    System.out.println(" Connected to server");

                    for (int i = 0; i < 100; i++) {
                        String username = "Adib " +randomStringGeneration();
                        String password = randomStringGeneration();

                        out.writeObject(new ClientRequest(1));
                        out.writeObject(new SignUpProfile(username, password, new byte[0]));

                        returnQuery statusObject = (returnQuery) in.readObject();
                        int status = statusObject.getStatus();
                        String message = statusObject.getMessage();

                        if (status == -1) {
                            System.out.println(" Signup failed for " + username + ": " + message);
                            continue;
                        }

                        out.writeObject(new ImageChanger(username, whitePixel));
                        System.out.println(" User created and image (empty) sent: " + username);
                    }

                    Thread.sleep(1000);

                } catch (Exception e) {
                    System.err.println(" Error: " + e.getMessage());
                    e.printStackTrace();
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        });

        try {
            Thread.currentThread().join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
