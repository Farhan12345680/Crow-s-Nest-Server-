package com.crowsnestfrontend.SceneManagement;

public class VideoScene {
}
