package com.crowsnestfrontend.SigningRelatedClasses;

import java.io.*;
import java.net.Socket;
import java.nio.Buffer;
import java.util.concurrent.CountDownLatch;

import com.crowsnestfrontend.ClientSideDataBase.AccessOwnerDataFromDatabase;
import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.Utility.SyncManager;
import javafx.application.Platform;
import javafx.scene.image.Image;

public class SignBranchingHandler {


    public static void signBranchLogicHandler() throws IOException {

        String clientSideDatabaseFilePath="clientData.db";
        File file = new File(clientSideDatabaseFilePath);

        if (file.isFile() && file.canRead() ) {
            AccessOwnerDataFromDatabase.initializeUserDataFromTheClientDatabase();

            try(Socket socket=new Socket("localhost" ,12345);
                PrintWriter out= new PrintWriter(socket.getOutputStream(), true)){
                out.println("3");
                out.println(Owner.nameId);
            }

            Platform.runLater(()->{
                SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.profileImageView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.usernameLabel.setText(Owner.nameId);
            });
            SceneManager.globalStage.setScene(SceneManager.mainScene);

        } else {
            SceneManager.globalStage.setScene(SceneManager.signUpScene);
            SceneManager.globalStage.centerOnScreen();

            Thread.startVirtualThread(()->{
                SyncManager.signUploading=new CountDownLatch(1);

                try{

                    SyncManager.signUploading.await();
                    Platform.runLater((()->{
                        SceneManager.globalStage.setScene(SceneManager.mainScene);

                    }));
                }catch (Exception e){
                    System.out.println(e.getMessage());
                }
            });

        }




    }
}
