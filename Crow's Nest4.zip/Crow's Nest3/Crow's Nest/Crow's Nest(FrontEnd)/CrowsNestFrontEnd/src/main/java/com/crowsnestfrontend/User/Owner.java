package com.crowsnestfrontend.User;

import java.util.concurrent.ConcurrentHashMap;

public class Owner {
    public static ConcurrentHashMap<String ,Contacts> contacts;

    public static String  nameId;
    public static byte[] image=null;

}
