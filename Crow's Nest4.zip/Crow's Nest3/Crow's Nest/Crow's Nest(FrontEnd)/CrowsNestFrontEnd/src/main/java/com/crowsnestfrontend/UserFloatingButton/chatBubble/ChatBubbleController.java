package com.crowsnestfrontend.UserFloatingButton.chatBubble;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;

public class ChatBubbleController {


    @FXML private Label messageLabel;
    @FXML private Label timestampLabel;

    public void setText(String msg) {
        messageLabel.setText(msg);
    }
    public void setTime(String time) {
        timestampLabel.setText(time);
    }




//    public void setTimestamp(String time) {
//        timestampLabel.setText(time);
//    }
}
