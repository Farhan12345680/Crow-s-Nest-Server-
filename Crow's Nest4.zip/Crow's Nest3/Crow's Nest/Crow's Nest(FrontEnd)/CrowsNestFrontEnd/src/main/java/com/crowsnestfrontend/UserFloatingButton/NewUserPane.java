package com.crowsnestfrontend.UserFloatingButton;

public class NewUserPane {

    //i want to design a pane where a image will be on the left there will be a user
    //at the next of the user image there will be the user name
    //the width of this pane will be 200
    //height will be 50

/*
* package com.crowsnestfrontend.UserFloatingButton;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class NewUserPaneController {

    @FXML private ImageView userImageView;
    @FXML private Label userNameLabel;

    public void setUsername(String username) {
        userNameLabel.setText(username);
    }

    public void setUserImage(Image image) {
        userImageView.setImage(image);
    }

    public String getUsername() {
        return userNameLabel.getText();
    }

    public Image getUserImage() {
        return userImageView.getImage();
    }
}
*
* */

}
