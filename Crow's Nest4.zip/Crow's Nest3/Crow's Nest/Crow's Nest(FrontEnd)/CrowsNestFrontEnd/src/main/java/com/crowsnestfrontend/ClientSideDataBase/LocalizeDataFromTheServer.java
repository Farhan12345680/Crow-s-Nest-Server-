package com.crowsnestfrontend.ClientSideDataBase;

import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.Utility.SyncManager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class LocalizeDataFromTheServer {
    public static void migrateDatabase(){

        try(Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString)){

            String insert_contact_statement= """
                    insert into Contacts(name_id , is_friend, image) values(? ,? ,?);
                    """;
            try(PreparedStatement ps =conn.prepareStatement(insert_contact_statement)){
                for(String contact_id: Owner.contacts.keySet()){
                    ps.setString(1 , contact_id);
                    ps.setInt(2,  Owner.contacts.get(contact_id).is_friend);
                    ps.setBytes(3, Owner.contacts.get(contact_id).image_bytes);
                    ps.addBatch();
                }
                ps.executeBatch();

            }catch (SQLException e){

            }
            String insert_Messages= """
                    insert into Messages(contact, is_seen, text ,reaction ,direction) values(?,?, ? ,? ,?);
                    """;
            try(PreparedStatement ps =conn.prepareStatement(insert_Messages)){
                for(String contact_id: Owner.contacts.keySet()){
                    ps.setString(1 , contact_id);
                    for(int i=0;i<Owner.contacts.get(contact_id).text_messages.size(); i++){
                        ps.setInt(2,  Owner.contacts.get(contact_id).text_messages.get(i).is_seen);
                        ps.setString(3,  Owner.contacts.get(contact_id).text_messages.get(i).text);
                        ps.setInt(4, Owner.contacts.get(contact_id).text_messages.get(i).reaction_type);
                        ps.setInt(5 , Owner.contacts.get(contact_id).text_messages.get(i).direction);
                    }
                    ps.addBatch();

                }
                ps.executeBatch();

            }catch (SQLException e){

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
//            SyncManager.messageLoading.countDown();
        }


    }
}
