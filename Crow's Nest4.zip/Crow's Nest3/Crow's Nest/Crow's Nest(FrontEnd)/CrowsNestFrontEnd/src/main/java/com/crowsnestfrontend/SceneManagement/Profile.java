package com.crowsnestfrontend.SceneManagement;

public class Profile {
}
