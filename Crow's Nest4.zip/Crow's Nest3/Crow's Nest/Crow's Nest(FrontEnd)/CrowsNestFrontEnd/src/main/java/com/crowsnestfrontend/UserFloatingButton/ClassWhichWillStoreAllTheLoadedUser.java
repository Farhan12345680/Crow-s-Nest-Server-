package com.crowsnestfrontend.UserFloatingButton;

import java.util.concurrent.ConcurrentHashMap;

public class ClassWhichWillStoreAllTheLoadedUser {

    ConcurrentHashMap<String ,Integer>LOADED_USERS;
    ConcurrentHashMap<String , Integer>LOADED_FRIENDS;
    ConcurrentHashMap<String , Integer>LOADED_FRIENDS_REQUESTS;



}
