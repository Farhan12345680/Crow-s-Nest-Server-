package com.crowsnestfrontend.SigningRelatedClasses;

public class LocalClientDbUser {
}
