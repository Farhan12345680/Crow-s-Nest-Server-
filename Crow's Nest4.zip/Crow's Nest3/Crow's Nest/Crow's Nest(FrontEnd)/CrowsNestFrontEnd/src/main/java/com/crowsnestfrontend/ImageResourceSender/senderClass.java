package com.crowsnestfrontend.ImageResourceSender;

public class senderClass {
    public static void  sendToTheGlobalServer(){


    }
    public static void sendToTheLocalSever(){

    }

}
