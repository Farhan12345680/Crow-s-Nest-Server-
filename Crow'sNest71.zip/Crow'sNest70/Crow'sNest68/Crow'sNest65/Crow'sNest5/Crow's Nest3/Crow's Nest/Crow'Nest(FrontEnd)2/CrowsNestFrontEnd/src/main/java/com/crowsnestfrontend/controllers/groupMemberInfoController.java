package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.groupManagement.deleteGroupInvite;
import com.groupManagement.groupMessaging.deleteMember;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

public class groupMemberInfoController {
    @FXML
    public ImageView logOut;
    public int channelID;
    public String name;
    public Label MemberName;
    public ImageView MemberImage;


    public Label MemberRole;
    public void initialize(){
        logOut.setOnMouseClicked((e)->{
            System.out.println("This is the name of the member "+ MemberName.getText());
            constantStream.payloadBlockingQueue.add(new deleteMember(Owner.nameId, MemberName.getText() ,channelID));

        });
    }
}
