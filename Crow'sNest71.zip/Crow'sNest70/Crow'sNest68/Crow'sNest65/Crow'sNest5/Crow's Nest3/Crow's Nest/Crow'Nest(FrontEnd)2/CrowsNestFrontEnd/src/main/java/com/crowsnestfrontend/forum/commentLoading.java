package com.crowsnestfrontend.forum;

import com.crowsnestfrontend.MainApplication;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class commentLoading extends VBox {
    public static commentLoading comment;

    public static commentLoading commentLoading(){
        if(comment==null){
            System.out.println("New loading request came");
            comment=new commentLoading();
        }

        return comment;
    }
    public commentLoading(){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.
                class.getResource("commentProgressIndicatorVBox.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
