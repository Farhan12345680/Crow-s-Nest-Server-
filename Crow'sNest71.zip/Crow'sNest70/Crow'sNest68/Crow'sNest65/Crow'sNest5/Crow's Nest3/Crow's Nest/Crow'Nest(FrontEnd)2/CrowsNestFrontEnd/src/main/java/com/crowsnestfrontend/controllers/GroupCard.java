package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.gifObject.gifObjectImageView;
import com.groupManagement.groupMessaging.groupMessagingRange;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import com.groupManagement.groupData;
import java.io.IOException;

import static com.crowsnestfrontend.MainApplication.client;

public class GroupCard extends HBox {
    @FXML
    public ImageView groupImage;

    @FXML
    public Label GroupName;

    public groupData data;

    public GroupCard(groupData data) {
        this.data=data;
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("GroupCard.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.setOnMouseClicked((e)->{
            if(GroupMessaging.object.loadingContext==1){
                return;
            }
            GroupMessaging.object.loadingContext=1;
            GroupMessaging.object.loadingScene.toFront();

            constantStream.payloadBlockingQueue.add(new groupMessagingRange(Owner.nameId , data.groupID, -1 , -1));
            GroupMessaging.object.MessageVBox.getChildren().clear();

            GroupMessaging.object.GroupName.setText(data.groupName);
            GroupMessaging.object.GroupImage.setImage(new Image(data.groupImageURL));
            GroupMessaging.object.data=data;


        });
        groupImage.setImage(new Image(data.groupImageURL));
        GroupName.setText(data.groupName);
    }

}
