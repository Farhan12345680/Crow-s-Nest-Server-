package com.crowsnestfrontend.controllers;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import com.crowsnestfrontend.ClientSideDataBase.changeOwnerClientDatabase;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.ImageChanger;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.User.Owner;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.event.ActionEvent;
import javafx.stage.Window;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.controlsfx.control.spreadsheet.SpreadsheetCellType;
import org.reactfx.util.Try;

import java.io.File;


import java.io.*;
import java.net.*;


import java.nio.file.Files;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.CountDownLatch;

import static com.crowsnestfrontend.MainApplication.client;
import static com.crowsnestfrontend.SceneManagement.SceneManager.cloudinary;

public class ProfileController implements Initializable {

    @FXML
    public Label usernameLabel;
    @FXML
    public Button uploadButton;
    @FXML
    public Button signOutButton;
    @FXML
    public ImageView profileImageView;

    @FXML
    public Button backButton;
    public Button BusyButton;
    public int busyContextholder;
    public VBox BlockDataHolder;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        uploadButton.setOnAction(this::onUploadButton);

        signOutButton.setOnAction(this::onSignOutButton);
        backButton.setOnAction(this::setBackButton);
        BusyButton.setOnMouseClicked((_)->{
            busyContextholder++;
            busyContextholder%=2;

            Thread.startVirtualThread(()->{
                String urlString = "http://localhost:8080/makeBusy/?"+Owner.nameId;
                if(busyContextholder==1){
                    Platform.runLater(()->{
                        BusyButton.setText("Allow Calls");

                    });
                }else{
                    urlString = "http://localhost:8080/makeUNBUSY/?"+Owner.nameId;
                    Platform.runLater(()->{
                        BusyButton.setText("Don't Allow Calls");

                    });
                }
                URL url = null;
                try {
                    url = new URL(urlString);
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
                HttpURLConnection conn = null;
                try {
                    conn = (HttpURLConnection) url.openConnection();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                try {
                    conn.setRequestMethod("GET");
                } catch (ProtocolException e) {
                    throw new RuntimeException(e);
                }
                int responseCode = 0;
                try {
                    responseCode = conn.getResponseCode();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                //System.out.println("Response Code: " + responseCode);

                BufferedReader in = null;
                try {
                    in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                String inputLine;
                StringBuilder response = new StringBuilder();

                while (true) {
                    try {
                        if (!((inputLine = in.readLine()) != null)) break;
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    response.append(inputLine);
                }
                try {
                    in.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                //System.out.println("Response: " + response.toString());
            });
        });
    }


    @FXML
    private void setBackButton(ActionEvent event) {
        SceneManager.globalStage.setScene(SceneManager.mainScene);
    }


    @FXML
    private void onUploadButton(ActionEvent event) {
        Window ownerWindow = profileImageView.getScene().getWindow();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Profile Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp")
        );

        File selectedFile = fileChooser.showOpenDialog(ownerWindow);
        if (selectedFile != null) {
            CountDownLatch UPLOADER_LATCH=new CountDownLatch(1);
            Platform.runLater(()->{
                SceneManager.globalStage.setScene(SceneManager.loadingScene);
                SceneManager.globalStage.centerOnScreen();
            });

            Thread.startVirtualThread(()->{
                ByteArrayOutputStream baos = new ByteArrayOutputStream();

                try {
                    net.coobird.thumbnailator.Thumbnails.of(selectedFile)
                            .size(150, 150)
                            .outputFormat(Files.probeContentType(selectedFile.toPath()).substring(6))
                            .toOutputStream(baos);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                byte[] imageBytes = baos.toByteArray();

                Image image = new Image(new ByteArrayInputStream(imageBytes));
                profileImageView.setImage(image);

                Map uploadResult = null;
                try {
                    uploadResult = cloudinary.uploader().upload(imageBytes,
                            ObjectUtils.asMap("folder", "profile_images"));
                }
                catch (IOException e) {
                    throw new RuntimeException(e);
                }

                String imageUrl = (String) uploadResult.get("secure_url");
                Owner.image = FileManager.storeImageOnFile( imageUrl,"profileImage");

                //System.out.println("Uploaded Image URL: " + imageUrl);

                try (Socket socket = new Socket("localhost", 12345);
                     ObjectOutputStream out =new ObjectOutputStream( socket.getOutputStream());
                     ObjectInputStream in = new ObjectInputStream(socket.getInputStream())
                     ) {
                    out.writeObject(new ClientRequest(4));

                    out.writeObject(new ImageChanger(Owner.nameId ,imageUrl));

                    out.flush();

                    Object obj=in.readObject();
                    if(obj != null){
                        //System.out.println("image upload request success");
                    }

                    changeOwnerClientDatabase.addImagetoTheTable(imageUrl, Owner.nameId);
                    SceneManager.mainSceneContrller.Personal_image_id.setImage(image);

                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                } finally {
                    UPLOADER_LATCH.countDown();
                }


            });

            Thread.startVirtualThread(()->{
               try{
                   UPLOADER_LATCH.await();
                   Platform.runLater(()->{
                       SceneManager.globalStage.setScene(SceneManager.profileScene);
                       SceneManager.globalStage.centerOnScreen();

                   });
               }catch (Exception e){
                   //System.out.println(e.getMessage());
               }

            });

        }
    }


    @FXML
    private void onSignOutButton(ActionEvent event) {
        try{
            File fileToDelete = new File("clientData.db");

            Thread.startVirtualThread(()->{

                String urlString = "http://localhost:8080/signOut/?"+Owner.nameId;

                Request request=new Request.Builder().url(urlString).build();

                try(Response response= client.newCall(request).execute()){
                    //System.out.println("this came here what is the problem here");
                    if (response.isSuccessful()) {
                        //System.out.println("signout is successful");
                        if(response.body()!=null){
                            //System.out.println(response.body().string());

                        }
                    } else {
                        //System.out.println("Request failed: " + response.code());
                    }
                }
                catch (Exception e){
                    e.printStackTrace();

                }
            }).join();

            if (fileToDelete.delete()) {
                System.out.println("File deleted successfully.");

            }

            SceneManager.globalStage.close();
        }catch (Exception e){
        e.printStackTrace();
        }


    }
}
