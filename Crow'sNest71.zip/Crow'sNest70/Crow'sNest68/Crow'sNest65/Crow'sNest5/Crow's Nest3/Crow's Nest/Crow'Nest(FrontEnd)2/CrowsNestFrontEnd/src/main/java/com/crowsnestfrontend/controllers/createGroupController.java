package com.crowsnestfrontend.controllers;

import com.CodingFileLocks.newCodingFile;
import com.cloudinary.utils.ObjectUtils;
import com.crowsnestfrontend.ClientSideDataBase.changeOwnerClientDatabase;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.ImageChanger;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.webrtcCaller.Caller;
import com.groupManagement.createGroup;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Window;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import com.crowsnestfrontend.UserStream.constantStream;



import static com.crowsnestfrontend.SceneManagement.SceneManager.cloudinary;

public class createGroupController {
    public static createGroupController createGroupController1;
    public static Dialog<Void> dialog;

    public static Runnable runner ;
    public static VBox boxer;
    @FXML
    public TextField groupName;
    @FXML
    public TextArea groupDescription;
    @FXML
    public Button uploadImageButton;
    @FXML
    public Button createGroupButton;
    @FXML
    public Label errorLabel;

    public String imageURL;

    @FXML
    public void initialize() throws IOException{

        createGroupController1=this;

        if(groupName!=null){

        }


        if(groupDescription!=null){

        }

        if(uploadImageButton!=null){
            uploadImageButton.setOnMouseClicked((event )->{
                Window ownerWindow = ((Node)event.getSource()).getScene().getWindow();
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Select Code Files");
                fileChooser.getExtensionFilters().addAll(
                        new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp")
                );

                File selectedFile = fileChooser.showOpenDialog(ownerWindow);
                if (selectedFile != null) {
                    CountDownLatch UPLOADER_LATCH=new CountDownLatch(1);
                    Platform.runLater(()->{
                        dialog.getDialogPane().getChildren().clear();
                        FXMLLoader loader = new FXMLLoader(MainApplication.class.getResource("loadingScene.fxml"));
                        try {
                            dialog.getDialogPane().setContent(loader.load());
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }

                        SceneManager.globalStage.centerOnScreen();
                    });

                    Thread.startVirtualThread(()->{
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();

                        try {
                            net.coobird.thumbnailator.Thumbnails.of(selectedFile)
                                    .scale(1)
                                    .outputFormat(Files.probeContentType(selectedFile.toPath()).substring(6))
                                    .toOutputStream(baos);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }

                        byte[] imageBytes = baos.toByteArray();


                        Map uploadResult = null;
                        try {
                            uploadResult = cloudinary.uploader().upload(imageBytes,
                                    ObjectUtils.asMap("folder", "groupFolder"));
                        }
                        catch (IOException e) {
                            throw new RuntimeException(e);
                        }

                        String imageUrl = (String) uploadResult.get("secure_url");


                        this.imageURL=imageUrl;
                        System.out.println(imageUrl);
                        UPLOADER_LATCH.countDown();
                    });

                    Thread.startVirtualThread(()->{
                        try{
                            UPLOADER_LATCH.await();
                            Platform.runLater(()->{
                                dialog.getDialogPane().getChildren().clear();
                                dialog.getDialogPane().setContent(boxer);
                            });
                        }catch (Exception e){

                        }

                    });
                }
            });

        }

        if(createGroupButton!=null){

            createGroupButton.setOnMouseClicked((e)->{
                constantStream.payloadBlockingQueue.add(new createGroup(Owner.nameId ,groupName.getText() ,groupDescription.getText() ,this.imageURL));
            });

        }

        if(errorLabel!=null){
            errorLabel.setVisible(false);
            errorLabel.setManaged(false);
        }
    }
}
