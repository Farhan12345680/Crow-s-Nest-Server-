package com.crowsnestfrontend.controllers;

import com.cloudinary.utils.ObjectUtils;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.gifObject.gifObjectVbox;
import com.crowsnestfrontend.gifObject.gifObjectVbox2;
import com.crowsnestfrontend.webLogin.ClientSideLogIN;
import com.groupManagement.GiveMeDataRange;
import com.groupManagement.groupData;
import com.groupManagement.groupMessaging.EditGroupMessage;
import com.groupManagement.groupMessaging.groupMessageDataReceiver;
import com.groupManagement.groupMessaging.groupMessagingRange;
import com.groupManagement.groupMessaging.groupMessagingSender;
import com.groupManagement.showGroupInviteRange;
import com.groupManagement.showInviteGroupData;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ConstraintsBase;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Popup;
import javafx.stage.Screen;
import javafx.stage.Window;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import java.nio.channels.NonWritableChannelException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import static com.crowsnestfrontend.SceneManagement.SceneManager.cloudinary;

public class GroupMessaging {
    public static GroupMessaging object;

    public static ArrayList<groupData>groupList;
    public static ArrayList<showInviteGroupData>groupInviteList;

    public static ArrayList<groupMessageDataReceiver>messageArrayList;


    @FXML
    public TextArea GroupTextMessageContentBox;
    @FXML
    public VBox MessageVBox;


    // message loading navigation

    @FXML
    public Button prev20;
    @FXML
    public Button Next20;
    @FXML
    public Button Newest;

    //Group Logic Navigation


    @FXML
    public VBox MessageContainerBox;
    @FXML
    public Button goBack;
    @FXML
    public Button createGroup;
    @FXML
    public VBox groupVBoxContaine;


    //group loading -groupMessaging
    @FXML
    public VBox groupLoading;
    @FXML
    public ScrollPane ScrollPaneGroup;



    //


    //main logic box
    @FXML
    public VBox mainLogicBox;
    @FXML
    public ImageView GroupImage;
    @FXML
    public Label GroupName;
    @FXML
    public VBox loadingScene;

    public int context = 1;

    public int loadingContext=0;


    // group invitation handling logic
    @FXML
    public Button Groups;
    @FXML
    public Button invitation;

    @FXML
    public Button prev15;
    @FXML
    public Button Next15;
    @FXML
    public Button DetailsButton;

    public  groupData data;

    public ImageView uploadComputerImage;

    public ImageView gifImage;

    public String imageURL;
    public ImageView sendMessageButton;
    public TextField messageInput;

    public Button Newest2;
    public VBox welcome;


    //Edit message

    @FXML
    public VBox EditCommentVBoxFXML;
    public TextArea EditTextArea;
    public ImageView EditImage;
    public Button EditUploadImage;
    public Button EditGifImage;
    public Button SendEditMessage;
    public Button CancelEditMessage;

    public int EDITmessageID;
    @FXML
    public Button prev152;
    @FXML
    public Button next152;
    @FXML
    public Button RefreshMessage;

    @FXML
    public void initialize() throws IOException{
        {
            if (EditUploadImage != null) {
                EditUploadImage.setOnMouseClicked((e) -> {
                    if(EditImage.getImage()!=null){
                        EditImage.setImage(null);
                        EditUploadImage.setText("Upload Image");
                        return;
                    }


                    Window ownerWindow = ((Node) e.getSource()).getScene().getWindow();
                    FileChooser fileChooser = new FileChooser();
                    fileChooser.setTitle("Select Profile Image");
                    fileChooser.getExtensionFilters().addAll(
                            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp")
                    );

                    File selectedFile = fileChooser.showOpenDialog(ownerWindow);
                    if (selectedFile != null) {
                        CountDownLatch UPLOADER_LATCH = new CountDownLatch(1);
                        loadingContext = 1;


                        loadingScene.toFront();

                        Thread.startVirtualThread(() -> {
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();

                            try {
                                net.coobird.thumbnailator.Thumbnails.of(selectedFile)
                                        .scale(1)
                                        .outputFormat(Files.probeContentType(selectedFile.toPath()).substring(6))
                                        .toOutputStream(baos);
                            } catch (IOException e1) {
                                throw new RuntimeException(e1);
                            }

                            byte[] imageBytes = baos.toByteArray();


                            Map uploadResult = null;
                            try {
                                uploadResult = cloudinary.uploader().upload(imageBytes,
                                        ObjectUtils.asMap("folder", "profile_images"));
                            } catch (IOException e1) {
                                throw new RuntimeException(e1);
                            }

                            String imageUrl = (String) uploadResult.get("secure_url");

                            UPLOADER_LATCH.countDown();
                            loadingContext = 0;
                            try {
                                UPLOADER_LATCH.await();
                                Platform.runLater(() -> {
                                    EditUploadImage.setText("Delete existing image");
                                    EditCommentVBoxFXML.toFront();
                                    EditImage.setImage(new Image(imageUrl));
                                });
                                this.imageURL = imageUrl;

                            } catch (Exception e2) {
                                e2.printStackTrace();
                            }


                        });

                    }

                });

            }

            if (Newest2 != null) {
                Newest2.setOnMouseClicked((e) -> {
                    loadingScene.toFront();
                    constantStream.payloadBlockingQueue.add(new groupMessagingRange(Owner.nameId, data.groupID, -1, -1));
                });
            }

            groupLoading.setVisible(true);
            groupLoading.setManaged(true);

            ScrollPaneGroup.setManaged(false);
            ScrollPaneGroup.setVisible(false);

            DetailsButton.setOnMouseClicked((e) -> {

                try {
                    Dialog<Void> dialog = new Dialog<>();
                    dialog.setDialogPane(new DialogPane());
                    ButtonType tempButton = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
                    dialog.getDialogPane().getButtonTypes().add(tempButton);
                    dialog.getDialogPane().lookupButton(tempButton).setVisible(false);
                    dialog.getDialogPane().lookupButton(tempButton).setManaged(false);

                    groupDetailController.runnable = () -> {
                        dialog.close();
                        SceneManager.globalStage.setScene(SceneManager.mainScene);
                        SceneManager.globalStage.centerOnScreen();
                    };

                    groupDetailController.data = data;
                    FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.
                            class.getResource("GroupDetailsScene.fxml"));

                    VBox box = fxmlLoader.load();
                    groupDetailController x = fxmlLoader.getController();

                    if (data.memberRole != 4) {
                        x.AddMemberVBox.setVisible(false);
                        x.AddMemberVBox.setManaged(false);
                        x.AddMember.setManaged(false);
                        x.AddMember.setVisible(false);
                        x.DeleteGroup.setVisible(false);
                        x.DeleteGroup.setManaged(false);
                    }

                    x.GroupLogo.setImage(new Image(data.groupImageURL));
                    x.GroupName.setText(data.groupName);
                    x.GroupDescription.setText(data.groupDescription);


                    dialog.getDialogPane().setContent(box);
                    dialog.show();

                } catch (Exception e1) {
                    e1.printStackTrace();
                }


            });

            EditGifImage.setOnMouseClicked((e) -> {
                Popup popup = new Popup();
                popup.setAutoHide(true);

                gifObjectVbox2 temp = gifObjectVbox2.initialize();


                popup.getContent().add(temp);

                double x = Screen.getScreens().getFirst().getVisualBounds().getWidth() / 2 - 300;
                double y = Screen.getScreens().getFirst().getVisualBounds().getHeight() / 2 -
                        200;
                popup.setX(x);
                popup.setY(y);
                popup.show(SceneManager.globalStage);
                popup.setOnHidden(event -> {

                    popup.getContent().clear();
                });
            });

            SendEditMessage.setOnMouseClicked((e) -> {
                constantStream.payloadBlockingQueue.add(new EditGroupMessage(Owner.nameId, EDITmessageID, EditTextArea.getText(), this.imageURL));
                this.imageURL = null;
                EditTextArea.clear();
                mainLogicBox.toFront();
            });

            CancelEditMessage.setOnMouseClicked((e) -> {
                EditCommentVBoxFXML.toBack();
                mainLogicBox.toFront();
                this.imageURL = null;
                EditImage.setImage(null);
                EditTextArea.clear();
            });

            object = this;
            constantStream.payloadBlockingQueue.add(new GiveMeDataRange(Owner.nameId, -1, -1));
            groupList = new ArrayList<>();
            groupInviteList = new ArrayList<>();
            messageArrayList = new ArrayList<>();

            if (goBack != null) {
                goBack.setOnMouseClicked((e) -> {
                    groupList = null;
                    object = null;
                    groupInviteList = null;
                    SceneManager.globalStage.setScene(SceneManager.mainScene);
                });
            }

            if (Newest != null) {
                Newest.setOnMouseClicked((e1) -> {

                    if (this.context == 1) {
                        constantStream.payloadBlockingQueue.add(new GiveMeDataRange(Owner.nameId, -1, -1));
                        groupLoading.setVisible(true);
                        groupLoading.setManaged(true);

                        ScrollPaneGroup.setManaged(false);
                        ScrollPaneGroup.setVisible(false);
                    } else {

                        constantStream.payloadBlockingQueue.add(new showGroupInviteRange(Owner.nameId, -1, -1));
                        groupLoading.setVisible(true);
                        groupLoading.setManaged(true);

                        ScrollPaneGroup.setManaged(false);
                        ScrollPaneGroup.setVisible(false);
                    }

                });
            }

            if (prev15 != null) {
                prev15.setOnMouseClicked((e1) -> {
                    if (this.context == 1) {

                        int start = Integer.MAX_VALUE;
                        int end = Integer.MIN_VALUE;

                        for (var t : groupVBoxContaine.getChildren()) {
                            if (((GroupCard) t).data.groupID < start) {
                                start = ((GroupCard) t).data.groupID;
                            }

                            if (((GroupCard) t).data.groupID > end) {
                                end = ((GroupCard) t).data.groupID;
                            }
                        }

                        if (start == Integer.MAX_VALUE) {
                            start = -1;
                        }

                        if (end == Integer.MIN_VALUE) {
                            end = -1;
                        }

                        constantStream.payloadBlockingQueue.add(new GiveMeDataRange(Owner.nameId, start, -1));
                        groupLoading.setVisible(true);
                        groupLoading.setManaged(true);

                        ScrollPaneGroup.setManaged(false);
                        ScrollPaneGroup.setVisible(false);
                    } else {

                        int start = Integer.MAX_VALUE;
                        int end = Integer.MIN_VALUE;

                        for (var t : groupVBoxContaine.getChildren()) {
                            if (((groupCardInviteController) t).data.groupID < start) {
                                start = ((groupCardInviteController) t).data.groupID;
                            }

                            if (((groupCardInviteController) t).data.groupID > end) {
                                end = ((groupCardInviteController) t).data.groupID;
                            }
                        }

                        if (start == Integer.MAX_VALUE) {
                            start = -1;
                        }

                        if (end == Integer.MIN_VALUE) {
                            end = -1;
                        }

                        constantStream.payloadBlockingQueue.add(new showGroupInviteRange(Owner.nameId, start, -1));
                        groupLoading.setVisible(true);
                        groupLoading.setManaged(true);

                        ScrollPaneGroup.setManaged(false);
                        ScrollPaneGroup.setVisible(false);
                    }

                });
            }

            if (Next15 != null) {
                Next15.setOnMouseClicked((e1) -> {


                    if (this.context == 1) {

                        int start = Integer.MAX_VALUE;
                        int end = Integer.MIN_VALUE;

                        for (var t : groupVBoxContaine.getChildren()) {
                            if (((GroupCard) t).data.groupID < start) {
                                start = ((GroupCard) t).data.groupID;
                            }

                            if (((GroupCard) t).data.groupID > end) {
                                end = ((GroupCard) t).data.groupID;
                            }
                        }

                        if (start == Integer.MAX_VALUE) {
                            start = -1;
                        }

                        if (end == Integer.MIN_VALUE) {
                            end = -1;
                        }

                        constantStream.payloadBlockingQueue.add(new GiveMeDataRange(Owner.nameId, -1, end));
                        groupLoading.setVisible(true);
                        groupLoading.setManaged(true);

                        ScrollPaneGroup.setManaged(false);
                        ScrollPaneGroup.setVisible(false);
                    } else {
                        int start = Integer.MAX_VALUE;
                        int end = Integer.MIN_VALUE;

                        for (var t : groupVBoxContaine.getChildren()) {
                            if (((groupCardInviteController) t).data.groupID < start) {
                                start = ((groupCardInviteController) t).data.groupID;
                            }

                            if (((groupCardInviteController) t).data.groupID > end) {
                                end = ((groupCardInviteController) t).data.groupID;
                            }
                        }

                        if (start == Integer.MAX_VALUE) {
                            start = -1;
                        }

                        if (end == Integer.MIN_VALUE) {
                            end = -1;
                        }


                        constantStream.payloadBlockingQueue.add(new showGroupInviteRange(Owner.nameId, -1, end));
                        groupLoading.setVisible(true);
                        groupLoading.setManaged(true);

                        ScrollPaneGroup.setManaged(false);
                        ScrollPaneGroup.setVisible(false);
                    }

                });

            }

            if (createGroup != null) {
                createGroup.setOnMouseClicked((e) -> {
                    try {
                        Dialog<Void> dialog = new Dialog<>();
                        dialog.setDialogPane(new DialogPane());
                        ButtonType tempButton = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
                        dialog.getDialogPane().getButtonTypes().add(tempButton);
                        dialog.getDialogPane().lookupButton(tempButton).setVisible(false);
                        dialog.getDialogPane().lookupButton(tempButton).setManaged(false);
                        createGroupController.dialog = dialog;
                        createGroupController.runner = new Runnable() {
                            @Override
                            public void run() {
                                dialog.close();
                                createGroupController.runner = null;
                                createGroupController.dialog = null;

                                createGroupController.createGroupController1 = null;
                            }
                        };

                        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("createGroupPopUp.fxml"));

                        VBox box = fxmlLoader.load();
                        createGroupController.boxer = box;

                        dialog.getDialogPane().setContent(box);
                        dialog.show();

                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                });
            }


            if (Groups != null) {
                Groups.setOnMouseClicked((e) -> {
                    context = 1;
                    constantStream.payloadBlockingQueue.add(new GiveMeDataRange(Owner.nameId, -1, -1));
                    groupLoading.setVisible(true);
                    groupLoading.setManaged(true);

                    ScrollPaneGroup.setManaged(false);
                    ScrollPaneGroup.setVisible(false);
                });
            }

            if (invitation != null) {
                invitation.setOnMouseClicked((e) -> {
                    context = 2;
                    constantStream.payloadBlockingQueue.add(new showGroupInviteRange(Owner.nameId, -1, -1));
                    groupLoading.setVisible(true);
                    groupLoading.setManaged(true);

                    ScrollPaneGroup.setManaged(false);
                    ScrollPaneGroup.setVisible(false);
                });
            }

            if (uploadComputerImage != null) {
                uploadComputerImage.setOnMouseClicked((e) -> {
                    Window ownerWindow = ((Node) e.getSource()).getScene().getWindow();
                    FileChooser fileChooser = new FileChooser();
                    fileChooser.setTitle("Select Profile Image");
                    fileChooser.getExtensionFilters().addAll(
                            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp")
                    );

                    File selectedFile = fileChooser.showOpenDialog(ownerWindow);
                    if (selectedFile != null) {
                        CountDownLatch UPLOADER_LATCH = new CountDownLatch(1);
                        loadingContext = 1;


                        loadingScene.toFront();


                        Thread.startVirtualThread(() -> {
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();

                            try {
                                net.coobird.thumbnailator.Thumbnails.of(selectedFile)
                                        .scale(1)
                                        .outputFormat(Files.probeContentType(selectedFile.toPath()).substring(6))
                                        .toOutputStream(baos);
                            } catch (IOException e1) {
                                throw new RuntimeException(e1);
                            }

                            byte[] imageBytes = baos.toByteArray();


                            Map uploadResult = null;
                            try {
                                uploadResult = cloudinary.uploader().upload(imageBytes,
                                        ObjectUtils.asMap("folder", "profile_images"));
                            } catch (IOException e1) {
                                throw new RuntimeException(e1);
                            }

                            String imageUrl = (String) uploadResult.get("secure_url");

                            UPLOADER_LATCH.countDown();
                            loadingContext = 0;
                            try {
                                UPLOADER_LATCH.await();
                                Platform.runLater(() -> {
                                    mainLogicBox.toFront();

                                });
                                this.imageURL = imageUrl;

                            } catch (Exception e2) {
                                e2.printStackTrace();
                            }


                        });

                    }
                });
            }

            if (gifImage != null) {
                gifImage.setOnMouseClicked((e) -> {
                    Popup popup = new Popup();
                    popup.setAutoHide(true);

                    gifObjectVbox2 temp = gifObjectVbox2.initialize();


                    popup.getContent().add(temp);

                    double x = Screen.getScreens().getFirst().getVisualBounds().getWidth() / 2 - 300;
                    double y = Screen.getScreens().getFirst().getVisualBounds().getHeight() / 2 -
                            200;
                    popup.setX(x);
                    popup.setY(y);
                    popup.show(SceneManager.globalStage);
                    popup.setOnHidden(event -> {

                        popup.getContent().clear();
                    });
                });
            }

            if (sendMessageButton != null) {

                sendMessageButton.setOnMouseClicked((e) -> {
                    if (messageInput.getText().trim().isBlank()) {
                        return;
                    }
                    System.out.println("---> " + messageInput.getText() + " " + imageURL);
                    constantStream.payloadBlockingQueue.add(new groupMessagingSender(Owner.nameId, data.groupID, messageInput.getText(), imageURL));
                    imageURL = null;
                    messageInput.setText("");
                });
            }
        }

        prev152.setOnMouseClicked((e)->{
                int start = Integer.MAX_VALUE;
                int end = Integer.MIN_VALUE;

                for (var t : MessageVBox.getChildren()) {
                    Node l=((HBox)t).getChildren().getFirst();
                    if (((groupMessageBubble) l).dataReceiver.messageID < start) {
                        start = ((groupMessageBubble) l).dataReceiver.messageID;
                    }

                    if (((groupMessageBubble) l).dataReceiver.messageID > end) {
                        end = ((groupMessageBubble) l).dataReceiver.messageID;
                    }
                }

                if (start == Integer.MAX_VALUE) {
                    start = -1;
                }

                if (end == Integer.MIN_VALUE) {
                    end = -1;
                }

            constantStream.payloadBlockingQueue.add(new groupMessagingRange(Owner.nameId, data.groupID, start, -1));
                loadingScene.toFront();

        });

        next152.setOnMouseClicked((e)->{
            int start = Integer.MAX_VALUE;
            int end = Integer.MIN_VALUE;

            for (var t : MessageVBox.getChildren()) {
                Node l=((HBox)t).getChildren().getFirst();
                if (((groupMessageBubble) l).dataReceiver.messageID < start) {
                    start = ((groupMessageBubble) l).dataReceiver.messageID;
                }

                if (((groupMessageBubble) l).dataReceiver.messageID > end) {
                    end = ((groupMessageBubble) l).dataReceiver.messageID;
                }
            }

            if (start == Integer.MAX_VALUE) {
                start = -1;
            }

            if (end == Integer.MIN_VALUE) {
                end = -1;
            }

            constantStream.payloadBlockingQueue.add(new groupMessagingRange(Owner.nameId, data.groupID, -1, end));
            loadingScene.toFront();
        });

        RefreshMessage.setOnMouseClicked((e)->{
            int start = Integer.MAX_VALUE;
            int end = Integer.MIN_VALUE;

            for (var t : MessageVBox.getChildren()) {
                Node l=((HBox)t).getChildren().getFirst();
                if (((groupMessageBubble) l).dataReceiver.messageID < start) {
                    start = ((groupMessageBubble) l).dataReceiver.messageID;
                }

                if (((groupMessageBubble) l).dataReceiver.messageID > end) {
                    end = ((groupMessageBubble) l).dataReceiver.messageID;
                }
            }

            if (start == Integer.MAX_VALUE) {
                start = -1;
            }

            if (end == Integer.MIN_VALUE) {
                end = -1;
            }

            constantStream.payloadBlockingQueue.add(new groupMessagingRange(Owner.nameId, data.groupID, start, end));
            loadingScene.toFront();
        });
    }

}
