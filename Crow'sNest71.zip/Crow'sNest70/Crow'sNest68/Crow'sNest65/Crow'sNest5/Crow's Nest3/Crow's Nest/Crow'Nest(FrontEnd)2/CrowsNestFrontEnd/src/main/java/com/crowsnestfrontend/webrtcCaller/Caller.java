package com.crowsnestfrontend.webrtcCaller;

import com.ClientSerializedClasses.cameraStartOneEnd;
import com.ClientSerializedClasses.*;
import com.ClientSerializedClasses.cameraStartOneEnd;

import com.CodingFileLocks.giveUpLock;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.iceObject;
import com.crowsnestfrontend.SerializedClasses.webrtcConnection;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.Utility.codeArea;
import com.crowsnestfrontend.webrtcCaller.audioChannel.JavaFXAudioSink;
import com.crowsnestfrontend.webrtcCaller.videoChannel.DesktopVideoSink;
import com.crowsnestfrontend.webrtcCaller.videoChannel.JavaFXVideoSink;
import com.crowsnestfrontend.webrtcCaller.videoChannel.JavafxSelfViewSink;
import com.crowsnestfrontend.webrtcCaller.videoChannel.videoChannel;
import dev.onvoid.webrtc.*;
import dev.onvoid.webrtc.media.MediaDevices;
import dev.onvoid.webrtc.media.MediaStream;
import dev.onvoid.webrtc.media.MediaStreamTrack;
import dev.onvoid.webrtc.media.audio.*;
import dev.onvoid.webrtc.media.video.VideoFrame;
import dev.onvoid.webrtc.media.video.VideoTrack;
import javafx.application.Platform;
import javafx.scene.image.Image;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;
import dev.onvoid.webrtc.media.video.VideoTrackSink;
import org.opencv.video.Video;

import javax.swing.plaf.synth.SynthRootPaneUI;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.crowsnestfrontend.MainApplication.client;
import static com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper.audioTrack;
import static com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper.videoTrack;
import static com.crowsnestfrontend.webrtcCaller.videoChannel.videoChannel.videoSource;
import static com.crowsnestfrontend.webrtcCaller.audioChannel.audioChannel.audioSource;
import static javafx.application.Application.setUserAgentStylesheet;

public class Caller {
    public static Caller callerObject;
    public RTCPeerConnection pc;
    RTCDataChannel dataChannel;
    public PeerConnectionFactory factory;

    public final AudioTrackSink  audioFrameLogger = new JavaFXAudioSink();
    private final VideoTrackSink videoFrameLogger = new JavaFXVideoSink();
    private final JavafxSelfViewSink selfView =new JavafxSelfViewSink();
    private  final DesktopVideoSink DesktopSink=new DesktopVideoSink();
    private  final DesktopVideoSink DesktopSink2=new DesktopVideoSink();

    private VideoTrack desktopTrack =null;

    private final AtomicBoolean cleaned = new AtomicBoolean(false);
    private final ExecutorService cleanupExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "caller-cleanup");
        t.setDaemon(true);
        return t;
    });


    //public audio processing
    public AudioProcessing audioProcessing;
    public  AudioProcessingConfig config1;
    public AudioDeviceModule audioModule;
    public AudioDevice defaultMic;
    public AudioDevice defaultSpeaker;
    AudioTrack audioTrackSource;
    AudioOptions audioOptions;



    public Caller() {

        factory = new PeerConnectionFactory();
        RTCConfiguration config = new RTCConfiguration();
        callerObject = this;


        RTCIceServer iceServer = new RTCIceServer();
        iceServer.urls.add("stun:stun.l.google.com:19302");
        config.iceServers.add(iceServer);

        this.pc = factory.createPeerConnection(config, new PeerConnectionObserver() {
            @Override
            public void onIceCandidate(RTCIceCandidate candidate) {
                System.out.println("Caller ICE: " + candidate.sdp);
                var obj = new iceObject(
                        Owner.nameId,
                        SelectedUserData.name.get(),
                        candidate.sdp,
                        candidate.sdpMid,
                        candidate.sdpMLineIndex
                );
                constantStream.payloadBlockingQueue.add(obj);
            }

            @Override
            public void onAddTrack(RTCRtpReceiver receiver, MediaStream[] mediaStreams) {
                System.out.println("LocalPeer: Track added: " + receiver.getTrack().getKind());
            }

            @Override
            public void onTrack(RTCRtpTransceiver transceiver) {
                MediaStreamTrack track = transceiver.getReceiver().getTrack();
                String kind = track.getKind();

                if (kind.equals(MediaStreamTrack.AUDIO_TRACK_KIND)) {
                    AudioTrack audioTrack = (AudioTrack) track;
                    audioTrack.addSink(audioFrameLogger);
                }


                String y =track.getId();


                if (kind.equals(MediaStreamTrack.VIDEO_TRACK_KIND)) {
                    System.out.println("this is the type of the video track "+ y);
                    if (transceiver.getMid().equals("0")) {
                        VideoTrack videoTrack = (VideoTrack) track;
                        videoTrack.addSink(DesktopSink2);
                    }
                    else{
                        GlobalResourceKeeper.isOtherCameraActive.set(true);
                        VideoTrack videoTrack = (VideoTrack) track;
                        videoTrack.addSink(videoFrameLogger);
                    }
                }

                System.out.println("Caller: Transceiver track added: " + kind);
            }
        });


        RTCDataChannelInit dataChannelConfig = new RTCDataChannelInit();
        dataChannelConfig.maxPacketLifeTime = -1;
        dataChannelConfig.maxRetransmits = -1;

        this.dataChannel = pc.createDataChannel("chat", dataChannelConfig);
//        this.videoChannel=pc.
        this.dataChannel.registerObserver(new RTCDataChannelObserver() {
            @Override
            public void onBufferedAmountChange(long previousAmount) {
                long currentAmount = dataChannel.getBufferedAmount();
                System.out.println("Buffered amount changed from " + previousAmount + " to " + currentAmount + " bytes");
            }

            @Override
            public void onStateChange() {
                RTCDataChannelState state = dataChannel.getState();
                System.out.println("Data channel state changed to: " + state);

                switch (state) {
                    case CONNECTING:
                        System.out.println("Data channel is being established");
                        break;

                    case OPEN:
                        System.out.println("Data channel is open and ready to use");
                        System.out.println("""
                                Data channel is opened
                                Data channel is opened again 
                                Data channel is opened again two
                                
                                """);
                        Thread.startVirtualThread(() -> {
                            if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
                                sendObject(new offer(Owner.nameId, FileManager.getImageUniqueId()));
                            }
                        });
                        break;

                    case CLOSING:
                    case CLOSED:
                        Platform.runLater(()->{
                                    SceneManager.globalStage.setScene(SceneManager.mainScene);
                                    SceneManager.globalStage.centerOnScreen();
                                    SceneManager.globalStage.show();
                                }
                        );
                        scheduleCleanupAndUiNotify();
                        break;
                }
            }

            @Override
            public void onMessage(RTCDataChannelBuffer buffer) {
                try {
                    if (!buffer.binary) {
                        buffer.data.rewind();
                        String msg = StandardCharsets.UTF_8.decode(buffer.data).toString();
                        VideoChatBox.initialize().insertIntoMessage(SelectedUserData.name.get(),
                                msg);
                        GlobalResourceKeeper.controller.current.setVisibility();
                        return;
                    }

                    ByteBuffer bb = buffer.data;
                    byte[] bytes = new byte[bb.remaining()];
                    bb.get(bytes);

                    Thread.startVirtualThread(() -> handleBinaryMessage(dataChannel, bytes));
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }
        });


        try{
            GlobalResourceKeeper.startDesktopVideoCapture();
            desktopTrack = Caller.callerObject.factory.createVideoTrack("desktopTrack", GlobalResourceKeeper.videoSource);
            desktopTrack.addSink(DesktopSink);
            Caller.callerObject.pc.addTrack(desktopTrack, Collections.singletonList("desktopTrack"));
            GlobalResourceKeeper.endDesktopVideoCapture();
        }
        catch (Throwable e){
            e.printStackTrace();
        }

        try{
            boolean storage = videoChannel.isAnyCameraResourceAvailable();
            if(storage){
                videoSource.start();
                videoTrack = factory.createVideoTrack("video0", videoSource);
                videoTrack.addSink(selfView);
                pc.addTrack(videoTrack , Collections.singletonList("cameraCaptureList"));

                GlobalResourceKeeper.isSelfCameraActive.set(true);
            }else{
                GlobalResourceKeeper.controller.selfView.setImage(new Image(Owner.image));
                videoTrack=null;
            }
        }
        catch (Throwable e){
            e.printStackTrace();
        }



        initializeAudio();


        GlobalResourceKeeper.isSelfCameraActive.set(true);
    }


        private void initializeAudio() {
            try {
                System.out.println("Initializing audio input...");


                audioOptions = new AudioOptions();
                audioOptions.echoCancellation = true;
                audioOptions.autoGainControl = true;
                audioOptions.noiseSuppression = true;

                // Create audio source and track
                audioSource = factory.createAudioSource(audioOptions);
                audioTrackSource = factory.createAudioTrack("audio1", audioSource);

                // Add audio track to PeerConnection
                pc.addTrack(audioTrackSource, Collections.singletonList("micAudioInput"));
                System.out.println("Audio input successfully added to PeerConnection.");

            } catch (Throwable e) {
                e.printStackTrace();
            }
        }



    private void handleBinaryMessage(RTCDataChannel channel, byte[] bytes) {
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bytes))) {
            Object obj = ois.readObject();

            if (obj instanceof String str) {
                System.out.println("Received serialized String: " + str);
            }
            else if (obj instanceof accept) {
                System.out.println("Received accept -> schedule cleanup and showing the videoScene");
                Platform.runLater(()->{
                    callerWaitingScene.callerWaitingInstance.run.run();
                    callerWaitingScene.callerWaitingInstance=null;

                    try {
                        SceneManager.globalStage.setScene(new VideoScene());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
            else if(obj instanceof endCall){
                Platform.runLater(()->{
                            SceneManager.globalStage.setScene(SceneManager.mainScene);
                            SceneManager.globalStage.centerOnScreen();
                            SceneManager.globalStage.show();
                        }
                );
                    this.scheduleCleanup();
            }
            else if(obj instanceof cameraStartOneEnd ){
                Platform.runLater(()->{
                    GlobalResourceKeeper.isOtherCameraActive.set(true);

                });
            }
            else if (obj instanceof  cameraStopOneEnd){
                Platform.runLater(()->{
                    GlobalResourceKeeper.isOtherCameraActive.set(false);
                    GlobalResourceKeeper.controller.otherView.setImage(new Image(SelectedUserData.image));
                });
            }
            else if(obj instanceof giveUpLock){
                GlobalResourceKeeper.isCodeBlockOwnerMe.set(true);
                GlobalResourceKeeper.controller.pane.ControlLabel.setText("You have the coding lock");
                Platform.runLater(()->{
                    GlobalResourceKeeper.controller.pane.codeBox.setEditable(true);
                    GlobalResourceKeeper.controller.pane.ControlLabel.setText("You have the coding lock");

                    GlobalResourceKeeper.controller.pane.GiveUpLock.setVisible(true);
                    GlobalResourceKeeper.controller.pane.GiveUpLock.setManaged(true);

                });
            }
            else if(obj instanceof  startScreenShare){
                Platform.runLater(()->{
                    GlobalResourceKeeper.isVideoShareActive.set(false);
                    GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
                    GlobalResourceKeeper.controller.CallerStartHelperFunc();
                    GlobalResourceKeeper.controller.screenShare.StatusLabel.setText(SelectedUserData.name.get() + " is Sharing");

                });
            }
            else if (obj instanceof  endScreenShare){
                Platform.runLater(()->{
                    GlobalResourceKeeper.isVideoShareActive.set(false);
                    GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
                    GlobalResourceKeeper.controller.CallerEndHelperFunc();
                });
            }
            else if(obj instanceof  caretPosition){
                Platform.runLater(() -> {

                    var t = (caretPosition) obj;

                    ((codeArea)GlobalResourceKeeper.controller.pane.codeBox).extraCaret.moveTo(t.y,t.x);


                });

            }
            else if(obj instanceof  textChange){
                Platform.runLater(() -> {
                    var t= (textChange)obj;
                    int x=  GlobalResourceKeeper.controller.pane.getCodeBox().getCaretColumn();
                    int y= GlobalResourceKeeper.controller.pane.getCodeBox().getCurrentParagraph();

                    GlobalResourceKeeper.controller.pane.getCodeBox().replaceText(t.pos, t.pos + t.removed.length(), t.inserted);

                    GlobalResourceKeeper.controller.pane.getCodeBox().moveTo(y , x);
                });
            }
            else {
                System.out.println("Unknown binary object: " + obj.getClass().getName());
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public static Caller initialize() {
        if (callerObject != null) return callerObject;
        callerObject = new Caller();
        return callerObject;
    }

    public void stopCaller() {
        Thread.startVirtualThread(() -> {
            try {
                if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
                    HttpUrl url = HttpUrl.parse("http://localhost:8080/removeBusy?"+SelectedUserData.name.get())
                            .newBuilder().build();
                    Request request = new Request.Builder()
                            .url(url)
                            .get()
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String responseBody = response.body().string();
                            System.out.println(responseBody);
                            }
                        }
                        catch (Exception e){
                        e.printStackTrace();
                    }
                }
                if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
                    HttpUrl url = HttpUrl.parse("http://localhost:8080/removeBusy?"+Owner.nameId)
                            .newBuilder().build();
                    Request request = new Request.Builder()
                            .url(url)
                            .get()
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String responseBody = response.body().string();
                            System.out.println(responseBody);
                        }
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }

                sendObject(new offerReject());

            } catch (Exception ignored) {}

            scheduleCleanup();
        });
    }

    private void scheduleCleanupAndUiNotify() {
        scheduleCleanup();
        Platform.runLater(() -> {
            if (callerWaitingScene.callerWaitingInstance != null && callerWaitingScene.callerWaitingInstance.run != null) {
                try {
                    callerWaitingScene.callerWaitingInstance.run.run();
                } catch (Exception ignored) {}
                callerWaitingScene.callerWaitingInstance = null;
            }
        });
    }

    public synchronized  void  sendObject(Object object) {
        Thread.startVirtualThread(() -> {
            try {
                if (dataChannel == null || dataChannel.getState() != RTCDataChannelState.OPEN) {
                    System.err.println("sendObject: dataChannel not open");
                    return;
                }
                try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
                     ObjectOutputStream oos = new ObjectOutputStream(baos)) {
                    oos.writeObject(object);
                    oos.flush();
                    byte[] bytes = baos.toByteArray();
                    dataChannel.send(new RTCDataChannelBuffer(ByteBuffer.wrap(bytes), true));
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
        });
    }

    public synchronized  void sendMessage(String message) {
        Thread.startVirtualThread(() -> {
            try {
                if (dataChannel == null || dataChannel.getState() != RTCDataChannelState.OPEN) {
                    System.err.println("sendMessage: dataChannel not open");
                    return;
                }
                dataChannel.send(new RTCDataChannelBuffer(ByteBuffer.wrap(message.getBytes()), false));
            } catch (Throwable t) {
                t.printStackTrace();
            }
        });
    }

    public void makeOffer() {
        if (pc == null) {
            System.err.println("makeOffer ignored: pc is null");
            return;
        }
        RTCOfferOptions options = new RTCOfferOptions();
        pc.createOffer(options, new CreateSessionDescriptionObserver() {
            @Override
            public void onSuccess(RTCSessionDescription offer) {
                if (pc == null) return;
                pc.setLocalDescription(offer, new SetSessionDescriptionObserver() {
                    @Override
                    public void onSuccess() {
                        System.out.println("Caller local SDP set");
                        var obj = new webrtcConnection(
                                Owner.nameId,
                                SelectedUserData.name.get(),
                                offer.sdpType.toString(),
                                offer.sdp
                        );
                        constantStream.payloadBlockingQueue.add(obj);
                    }

                    @Override
                    public void onFailure(String error) {
                        System.err.println("Caller failed to set local: " + error);
                    }
                });
            }

            @Override
            public void onFailure(String error) {
                System.err.println("Caller failed to create offer: " + error);
            }
        });
    }

    public void onAnswerReceived(RTCSessionDescription answer) {
        if (pc == null) {
            System.err.println("onAnswerReceived ignored: pc is null");
            return;
        }
        pc.setRemoteDescription(answer, new SetSessionDescriptionObserver() {
            @Override
            public void onSuccess() {
                System.out.println("Caller remote SDP set");
            }

            @Override
            public void onFailure(String error) {
                System.err.println("Caller failed to set remote: " + error);
            }
        });
    }

    public void onIceCandidate(RTCIceCandidate candidate) {
        if (pc != null) pc.addIceCandidate(candidate);
    }

    public void scheduleCleanup() {
        GlobalResourceKeeper.isSelfCameraActive.set(false);
        GlobalResourceKeeper.isScreeenShareActive.set(false);
        GlobalResourceKeeper.isCodeBlockActive.set(false);
        GlobalResourceKeeper.isOtherCameraActive.set(false);
        GlobalResourceKeeper.isScreeenShareActive.set(false);
        Thread.startVirtualThread(this::cleanUpWebrtc);
    }

    private void stoppedByCallee(){
        this.cleanUpWebrtc();

    }


    private void cleanUpWebrtc(){
        if (!cleaned.compareAndSet(false, true)) return;
        cleanupExecutor.execute(() -> {
            try {
                    GlobalResourceKeeper.isSelfCameraActive.set(false);
                    GlobalResourceKeeper.isCodeBlockActive.set(false);
                    GlobalResourceKeeper.isSelfCameraActive.set(false);
                    GlobalResourceKeeper.isScreeenShareActive.set(false);
                    GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
                    GlobalResourceKeeper.isVideoShareActive.set(false);

                    try{
                        videoSource.stop();
                        videoSource.dispose();
                    }
                    catch (Throwable a){
                        a.printStackTrace();
                    }

                    try{
                        desktopTrack.removeSink(DesktopSink);
                    }catch (Throwable e){
                        e.printStackTrace();
                    }
                    try{
                        desktopTrack.setEnabled(false);
                        desktopTrack.dispose();
                    }catch (Throwable e){
                        e.printStackTrace();
                    }

                    System.out.println("this is the selected name "+SelectedUserData.name.get());
                    HttpUrl url = HttpUrl.parse("http://localhost:8080/removeBusy?"+SelectedUserData.name.get())
                            .newBuilder().build();
                    Request request = new Request.Builder()
                            .url(url)
                            .get()
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String responseBody = response.body().string();
                            //System.out.println(responseBody);
                        }
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }


                    url = HttpUrl.parse("http://localhost:8080/removeBusy?"+Owner.nameId)
                            .newBuilder().build();
                    request = new Request.Builder()
                            .url(url)
                            .get()
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String responseBody = response.body().string();

                        }
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }


                if (dataChannel != null) {
                    try { dataChannel.unregisterObserver(); }
                    catch (Throwable ignored) {}
                    try { dataChannel.close(); } catch (Throwable ignored) {}
                    try { dataChannel.dispose(); } catch (Throwable ignored) {}
                    dataChannel = null;
                }
                if(videoChannel.videoSource!=null){
                    try{
                        videoChannel.videoSource.stop();
                        videoChannel.videoSource.dispose();
                    }catch (Throwable t1){
                        t1.printStackTrace();
                    }
                }

                if(GlobalResourceKeeper.videoTrack!=null){
                    try{
                        GlobalResourceKeeper.videoTrack.removeSink(selfView);
                    }catch (Throwable t){
                        t.printStackTrace();
                    }

                }

                if(GlobalResourceKeeper.videoTrack!=null){
                    try{
                        videoTrack.setEnabled(false);
                        GlobalResourceKeeper.videoTrack.dispose();
                    }catch (Throwable t){
                        t.printStackTrace();
                    }
                }
                if (pc != null) {
                    try { pc.close(); } catch (Throwable t) { System.err.println("pc.close() error: "+t.getMessage()); }
                    pc = null;
                }

                if (factory != null) {
                    try { factory.dispose(); } catch (Throwable t) { System.err.println("factory.dispose() error: "+t.getMessage()); }
                    factory = null;
                }

                // clear singleton
                callerObject = null;
            } finally {
            }
        });
    }
}
