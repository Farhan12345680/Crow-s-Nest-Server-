package com.crowsnestfrontend.webrtcCaller;

import com.ClientSerializedClasses.askForScreenShareOwnerShip;
import com.ClientSerializedClasses.endScreenShare;
import com.ClientSerializedClasses.endScreenShareOwnerShip;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.SelectedUserData;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import okhttp3.Call;

import java.io.IOException;

public class ScreenShare extends VBox {


    @FXML
    public Label StatusLabel;


    @FXML
    public ImageView ScreenImage;

    public ScreenShare(){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("ScreenShareFXML.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);


        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        GlobalResourceKeeper.controller.ScreenShareController=this;




    }
    public void ScreenShareOwnerShipChanger( ){
        if(GlobalResourceKeeper.isVideoShareOwnerMe.get()){
            GlobalResourceKeeper.isVideoShareOwnerMe.set(false);
            GlobalResourceKeeper.endDesktopVideoCapture();
            StatusLabel.setText(SelectedUserData.name.get() +" is sharing screen");
            if(Caller.callerObject!=null){
                Caller.callerObject.sendObject(new endScreenShareOwnerShip());

            }else{
                Callee.callee.sendObject(new endScreenShareOwnerShip());
            }
        }else{
            GlobalResourceKeeper.isVideoShareOwnerMe.set(true);
            GlobalResourceKeeper.startDesktopVideoCapture();
            StatusLabel.setText(SelectedUserData.name.get() +" is sharing screen");
            if(Caller.callerObject!=null){
                Caller.callerObject.sendObject(new askForScreenShareOwnerShip());

            }else{
                Callee.callee.sendObject(new askForScreenShareOwnerShip());
            }
        }


    }


}
