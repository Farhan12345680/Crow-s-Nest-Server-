package  com.crowsnestfrontend.webrtcCaller.audioChannel;

import dev.onvoid.webrtc.media.audio.AudioTrackSink;

import javax.sound.sampled.*;
import java.util.concurrent.*;

/**
 * An implementation of AudioTrackSink that renders incoming audio data
 * to the local audio playback device using the Java Sound API.
 * This class automatically starts playback when the remote peer sends audio
 * and stops it after a period of silence to save resources.
 */
public class JavaFXAudioSink implements AudioTrackSink {

    private SourceDataLine sourceDataLine;
    private final BlockingQueue<byte[]> audioQueue = new LinkedBlockingQueue<>();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private volatile boolean isRunning = false;
    private volatile ScheduledFuture<?> shutdownFuture;
    private Thread audioThread;

    @Override
    public void onData(byte[] data, int bitsPerSample, int sampleRate, int channels, int frames) {
        // Automatically start the audio sink if it's not already running.
        if (!isRunning) {
            setupAndStartAudio(bitsPerSample, sampleRate, channels);
        }

        // Reset the shutdown timer whenever new data arrives.
        resetShutdownTimer();

        // Add the audio data to the queue for playback.
        if (isRunning) {
            audioQueue.add(data);
        }
    }

    private synchronized void setupAndStartAudio(int bitsPerSample, int sampleRate, int channels) {
        if (isRunning) {
            return; // Already running.
        }

        AudioFormat audioFormat = new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED,
                (float) sampleRate,
                bitsPerSample,
                channels,
                (bitsPerSample / 8) * channels, // frameSize in bytes
                (float) sampleRate,
                false // WebRTC audio is typically little-endian
        );

        DataLine.Info info = new DataLine.Info(SourceDataLine.class, audioFormat);
        if (!AudioSystem.isLineSupported(info)) {
            System.err.println("Audio format not supported: " + audioFormat);
            return;
        }

        try {
            sourceDataLine = (SourceDataLine) AudioSystem.getLine(info);
            sourceDataLine.open(audioFormat);
            sourceDataLine.start();
            System.out.println("SourceDataLine opened successfully.");
        } catch (LineUnavailableException e) {
            System.err.println("Could not open audio line: " + e.getMessage());
            return;
        }

        // Start the audio playback thread
        isRunning = true;
        audioThread = new Thread(() -> {
            try {
                while (isRunning) {
                    byte[] data = audioQueue.take(); // Wait for data
                    if (sourceDataLine != null && sourceDataLine.isRunning()) {
                        int bytesWritten = sourceDataLine.write(data, 0, data.length);
                        if (bytesWritten != data.length) {
                            System.err.println("Warning: Bytes written mismatch: " + bytesWritten + " of " + data.length);
                        }
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); // Restore interrupted status
                System.out.println("Audio playback thread interrupted.");
            } finally {
                System.out.println("Audio playback thread exiting.");
            }
        }, "AudioPlaybackThread");

        audioThread.setDaemon(true);
        audioThread.start();
    }

    private synchronized void resetShutdownTimer() {
        if (shutdownFuture != null && !shutdownFuture.isDone()) {
            shutdownFuture.cancel(false);
        }
        // If no new data arrives in 3 seconds, shut down the playback.
        shutdownFuture = scheduler.schedule(this::close, 3, TimeUnit.SECONDS);
    }

    /**
     * Cleans up all resources.
     */
    public synchronized void close() {
        if (!isRunning) {
            return;
        }
        isRunning = false;

        // Interrupt the audio playback thread
        if (audioThread != null) {
            audioThread.interrupt();
            try {
                audioThread.join(1000); // Wait for the thread to finish cleanly
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        // Close the SourceDataLine
        if (sourceDataLine != null) {
            System.out.println("Draining and closing SourceDataLine.");
            sourceDataLine.drain();
            sourceDataLine.stop();
            sourceDataLine.close();
            sourceDataLine = null;
        }
        // Cancel any pending shutdown tasks
        if (shutdownFuture != null) {
            shutdownFuture.cancel(false);
        }
    }
}
