package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class message implements Serializable{
    @Serial
    private static final long serialVersionUID = 1709L;
    public String messageString;

    public message(String messageString){
            this.messageString=messageString;
    }
    
}
