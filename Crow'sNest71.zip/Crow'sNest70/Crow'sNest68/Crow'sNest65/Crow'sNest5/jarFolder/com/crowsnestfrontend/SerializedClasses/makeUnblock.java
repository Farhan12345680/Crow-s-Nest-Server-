package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class makeUnblock extends payload implements Serializable {
        
    @Serial 
    private static final long serialVersionUID=3678L;
    public final String receiver;

    public makeUnblock(String target, String receiver){
        super(target);
        this.receiver=receiver;
    }
}
