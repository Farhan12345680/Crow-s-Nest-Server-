package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;

public class addMemberIntoGroup extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7692L;
    
    public String memberName ;
    public int ChannelID;

    public addMemberIntoGroup(String clientName , String memberName){
        super(clientName);
        this.memberName=memberName;
    }

}
