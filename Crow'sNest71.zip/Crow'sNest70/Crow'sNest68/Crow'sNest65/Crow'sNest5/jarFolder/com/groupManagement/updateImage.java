package com.crowsnestfrontend.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;

public class updateImage extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7691L;
    
    public String imageURL ;

    public updateImage(String clientName , String ImageURL){
        super(clientName);
        this.imageURL=ImageURL;
    }

}
