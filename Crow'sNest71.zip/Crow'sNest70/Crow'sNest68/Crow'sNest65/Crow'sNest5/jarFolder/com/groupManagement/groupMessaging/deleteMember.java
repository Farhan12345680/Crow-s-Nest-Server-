package com.groupManagement.groupMessaging;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class deleteMember extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7721L;
    
    public int channelID;
    public String name;


    public deleteMember(String clientName,String name,int channelID){
        super(clientName);
        this.name=name;
        this.channelID=channelID;
        
    }


}
