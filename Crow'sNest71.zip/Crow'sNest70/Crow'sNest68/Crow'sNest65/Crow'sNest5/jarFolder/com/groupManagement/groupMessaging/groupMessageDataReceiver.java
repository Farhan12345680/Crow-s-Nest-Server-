package com.groupManagement.groupMessaging;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class groupMessageDataReceiver extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7716L;
    
    public int channelID;
    public String messageText;
    public String imageURL;
    public int messageID;
    public String date;


    public groupMessageDataReceiver(String clientName,int messageID ,int channelID ,String messageText ,String imageURL,String date  ){
        super(clientName);
        this.channelID= channelID;
        this.messageText=messageText;
        this.imageURL=imageURL;
        this.messageID=messageID;
        this.date=date;
    }


}
