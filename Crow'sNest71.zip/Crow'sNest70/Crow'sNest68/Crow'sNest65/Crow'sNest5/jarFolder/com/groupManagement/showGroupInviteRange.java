package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class showGroupInviteRange extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7701L;
    public int start;
    public int end;



    public showGroupInviteRange(String name , int start , int end ){
        super(name );
        this.start=start;
        this .end=end;

    }


}