package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class groupNameAlreadyExists extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7700L;
    


    public groupNameAlreadyExists(){
        super(null);  
    }


}