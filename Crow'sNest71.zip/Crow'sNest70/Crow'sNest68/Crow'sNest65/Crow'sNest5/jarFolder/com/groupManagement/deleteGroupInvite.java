package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class deleteGroupInvite extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7712L;
    
    public int channelID;


    public deleteGroupInvite(String clientName ,int channelID  ){
        super(clientName);
        this.channelID= channelID;

    }


}
