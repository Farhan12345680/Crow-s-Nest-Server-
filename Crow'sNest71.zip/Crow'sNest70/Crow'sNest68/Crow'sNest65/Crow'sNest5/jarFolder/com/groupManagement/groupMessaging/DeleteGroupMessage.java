package com.groupManagement.groupMessaging;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class DeleteGroupMessage extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7719L;
    
    public int messageID;


    public DeleteGroupMessage(String clientName,int messageID){
        super(clientName);
        this.messageID=messageID;
        
    }


}
