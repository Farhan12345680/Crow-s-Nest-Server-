package com.comment;


import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;
import java.io.Serializable;


public class commentData extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 13491L;

    public String senderName ;
    public int PostID;
    public String CommentDescription;
    public String time;
    public int commentID;

    public commentData(String senderName ,
     int PostID, String CommentDescription,String time ,int commentID){
        super(senderName);

        this.senderName=senderName;
        this.PostID=PostID;
        this.CommentDescription=CommentDescription;
        this.time=time;
        this.commentID=commentID;
    }   
}
