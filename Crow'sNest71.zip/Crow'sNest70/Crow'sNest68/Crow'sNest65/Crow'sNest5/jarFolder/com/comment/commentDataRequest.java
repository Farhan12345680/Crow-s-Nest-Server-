package com.comment;


import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;


public class commentDataRequest extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 13492L;

    public String senderName ;
    public int PostID;
    public int start;
    public int end ;

    public commentDataRequest(String senderName ,
     int PostID, int start , int end ){
        super(senderName);

        this.senderName=senderName;
        this.PostID=PostID;
        this.start=start;
        this.end=end;
       

    }   
}
