package com.example.crows__nest__client_trial.dbms;

public class dbms1_call {


    public void send_to_the_client(){

    }


}
