import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.net.Socket;
import java.nio.Buffer;
import java.util.Objects;

public class clientSocket {

    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 12345);
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in))) {

            int isNewUser = 0;

            isNewUser = Integer.parseInt(consoleReader.readLine());

            switch (isNewUser) {
                case 1:
                    System.out.println("Enter Existing User Name");
                    String userName = consoleReader.readLine();
                    String userPassword = consoleReader.readLine();

                    int readStatus = -1;
                    while (readStatus == -1) {
                        readStatus = Integer.parseInt(reader.readLine());
                        String readMessageString = reader.readLine();
                        System.out.println("The Message" + readMessageString);

                    }
                    out.println(0);

                    break;
                case 0:
                    System.out.println("Enter New User Name");
                    userName = consoleReader.readLine();
                    userPassword = consoleReader.readLine();

                    readStatus = -1;
                    while (readStatus == -1) {
                        readStatus = Integer.parseInt(reader.readLine());
                        String readMessageString = reader.readLine();
                        System.out.println("The Message" + readMessageString);

                    }

                    out.println(0);
                    break;
                default:
                    return;
            }

        } catch (Exception e) {

        }
    }
}