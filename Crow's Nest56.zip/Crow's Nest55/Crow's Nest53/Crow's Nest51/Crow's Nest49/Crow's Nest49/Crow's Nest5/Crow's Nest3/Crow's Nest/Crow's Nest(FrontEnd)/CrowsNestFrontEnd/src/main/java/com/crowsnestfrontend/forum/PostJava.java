package com.crowsnestfrontend.forum;

import com.PostFile.getPostData;

public class PostJava {
    public static  void handlePost(getPostData data ){

    }
}
