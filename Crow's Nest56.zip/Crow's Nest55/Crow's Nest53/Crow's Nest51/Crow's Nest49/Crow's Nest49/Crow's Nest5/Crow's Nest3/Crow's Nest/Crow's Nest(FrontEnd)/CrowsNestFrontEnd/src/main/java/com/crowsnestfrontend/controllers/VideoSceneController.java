package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.Utility.codeStackPane;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.Utility.VideoSceneChat;
import com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper;
import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import org.fxmisc.richtext.CodeArea;
import org.opencv.videoio.VideoCapture;

import java.io.IOException;


public class VideoSceneController {

    @FXML
    public ImageView otherView;
    @FXML
    public ImageView endCall;
    @FXML
    public ImageView code;
    @FXML
    public ImageView camera;
    @FXML
    public ImageView mic;

    @FXML
    public ImageView selfView;

    @FXML
    public VBox voiceHolder;
    @FXML
    public HBox buttonHolder;
    @FXML
    public VBox codeArea;
    @FXML
    public VBox videoChatHolder;
    @FXML
    public Text ClientName;
    @FXML
    public Text UserName;

    private CodeArea codeBox;
    private VideoCapture capture;

    private byte[] buffer;
    private WritableImage writableImage;
    private PixelWriter pixelWriter;
    private int state=0;


    @FXML
    public void initialize() throws IOException, InterruptedException {


        ClientName.setText(SelectedUserData.name.get());
        UserName.setText(Owner.nameId);

        otherView.setImage(new Image( SelectedUserData.image));

        voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        videoChatHolder.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight()-200);
        selfView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        selfView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        otherView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        otherView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        codeArea.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);
        codeArea.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() *90f/100);


        GlobalResourceKeeper resource=GlobalResourceKeeper.getInstance();
        resource.selfView=selfView;
        resource.otherView=otherView;
        resource.codeArea=codeArea;
        resource.voiceHolder=voiceHolder;

        codeStackPane pane=new codeStackPane();
        codeArea.getChildren().add(pane);

        codeArea.setVisible(false);
        codeArea.setManaged(false);
        pane.toFront();
        code.setOnMouseClicked((e)->{
            resource.selfCameraOnOff();
        });

        endCall.setOnMouseClicked((e)->{
            resource.stopCameraPermanent();
            SceneManager.globalStage.setScene(SceneManager.mainScene);
            SceneManager.globalStage.centerOnScreen();
            SceneManager.globalStage.show();
        });

        camera.setOnMouseClicked((e)->{
            resource.cycleCamera();
        });
        var current=new VideoSceneChat();
        buttonHolder.getChildren().add(current);

        resource.startCamera();
    }

}
