package com.crowsnestfrontend.User;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class SelectedUserData {
    public static StringProperty name=new SimpleStringProperty("");
    public static byte[] image;

}
