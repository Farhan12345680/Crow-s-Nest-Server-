package com.crowsnestfrontend.forum;

import com.crowsnestfrontend.MainApplication;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class NoCommentFound extends VBox {
    public static NoCommentFound node;

    public static NoCommentFound initialize(){
        if(node==null){

            node
                    =new NoCommentFound();


        }

        return node;
    }
    public NoCommentFound(){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.
                class.getResource("NoCommentFound.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }





}
