import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class BigBMPGenerator {

    public static void main(String[] args) {
        int width = 10000;
        int height = 10000;


        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();

        for (int y = 0; y < height; y++) {
            int red = (y * 255) / height;
            for (int x = 0; x < width; x++) {
                int green = (x * 255) / width;
                int blue = 128;
                int rgb = (red << 16) | (green << 8) | blue;
                image.setRGB(x, y, rgb);
            }
        }

        g.dispose();

        // Output file
        File outputFile = new File("big_image.bmp");

        try {
            // Save the image as BMP format
            ImageIO.write(image, "bmp", outputFile);
            System.out.println("Image saved successfully: " + outputFile.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error saving image: " + e.getMessage());
        }
    }
}
