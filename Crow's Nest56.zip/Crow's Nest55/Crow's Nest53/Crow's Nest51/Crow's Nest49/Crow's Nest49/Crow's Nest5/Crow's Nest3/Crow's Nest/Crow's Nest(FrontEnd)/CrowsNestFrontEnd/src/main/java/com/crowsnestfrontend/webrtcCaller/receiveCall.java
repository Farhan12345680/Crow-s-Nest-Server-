package com.crowsnestfrontend.webrtcCaller;

import dev.onvoid.webrtc.*;
import dev.onvoid.webrtc.media.MediaStreamTrack;
import dev.onvoid.webrtc.media.audio.*;
import dev.onvoid.webrtc.media.video.*;

import java.util.ArrayList;
import java.util.List;

public class receiveCall {

    private PeerConnectionFactory factory;
    private RTCPeerConnection peerConnection;
    private AudioTrack localAudio;
    private VideoTrack localVideo;

    public receiveCall(SignalingChannel signaling) {
        factory = new PeerConnectionFactory();

        RTCConfiguration config = new RTCConfiguration();
        RTCIceServer iceServer = new RTCIceServer();
        iceServer.urls.add("stun:stun.l.google.com:19302");
        config.iceServers.add(iceServer);

        peerConnection = factory.createPeerConnection(config, new PeerConnectionObserver() {
            @Override
            public void onIceCandidate(RTCIceCandidate candidate) {
                // Send candidate to caller
                signaling.sendCandidate(candidate);
            }

            @Override
            public void onTrack(RTCRtpTransceiver transceiver) {
                MediaStreamTrack track = transceiver.getReceiver().getTrack();
                System.out.println("Callee received remote track: " + track.getKind());
            }
        });

        // Local media (mic + camera)
        AudioOptions audioOptions = new AudioOptions();
        audioOptions.echoCancellation = true;
        localAudio = factory.createAudioTrack("audio1", factory.createAudioSource(audioOptions));

        VideoDeviceSource videoSource = new VideoDeviceSource();
        localVideo = factory.createVideoTrack("video1", videoSource);

        List<String> streamIds = new ArrayList<>();
        streamIds.add("stream1");
        peerConnection.addTrack(localAudio, streamIds);
        peerConnection.addTrack(localVideo, streamIds);

        // Listen for offer from caller (via signaling)
        signaling.onOffer(offer -> {
            peerConnection.setRemoteDescription(offer, new SetSessionDescriptionObserver() {
                @Override
                public void onSuccess() {
                    System.out.println("Callee set remote offer. Creating answer...");
                    peerConnection.createAnswer(new RTCAnswerOptions(), new CreateSessionDescriptionObserver() {
                        @Override
                        public void onSuccess(RTCSessionDescription desc) {
                            peerConnection.setLocalDescription(desc, new SetSessionDescriptionObserver() {
                                @Override
                                public void onSuccess() {
                                    System.out.println("Callee local description set!");
                                    signaling.sendAnswer(desc); // <--- Send answer back
                                }
                                @Override
                                public void onFailure(String error) {
                                    System.out.println("Failed to set local desc: " + error);
                                }
                            });
                        }

                        @Override
                        public void onFailure(String error) {
                            System.out.println("Answer creation failed: " + error);
                        }
                    });
                }

                @Override
                public void onFailure(String error) {
                    System.out.println("Failed to set remote offer: " + error);
                }
            });
        });

        // Listen for remote ICE candidate
        signaling.onCandidate(candidate -> peerConnection.addIceCandidate(candidate));
    }
}
