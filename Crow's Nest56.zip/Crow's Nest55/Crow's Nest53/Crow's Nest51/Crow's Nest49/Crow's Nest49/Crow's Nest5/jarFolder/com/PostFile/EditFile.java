package com.PostFile;


import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;


public class EditFile extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 12493L;

    public String senderName ;
    public int id;
    public String PostTitle;
    public String PostDescription;
    public byte[] fileContent;

    public EditFile(int id, String senderName ,
     String PostTitle , String PostDescription , byte[] fileContent){
        super(senderName);
        this.id=id;
        this.senderName=senderName;
        this.PostTitle=PostTitle;
        this.PostDescription=PostDescription;
        this.fileContent=fileContent;

    }   
}
