package com.PostFile;


import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;


public class getPostData extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 12494L;

    public String senderName ;
    public int id;
    public String PostTitle;
    public String PostDescription;
    public byte[] fileContent;
    public String time;

    public getPostData(int id, String senderName ,
     String PostTitle , String PostDescription , byte[] fileContent ,String time){
        super(senderName);
        this.id=id;
        this.senderName=senderName;
        this.PostTitle=PostTitle;
        this.PostDescription=PostDescription;
        this.fileContent=fileContent;
        this.time=time;
    }   
}
