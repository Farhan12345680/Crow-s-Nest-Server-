package com.comment;


import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;


public class commentEdit extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 13499L;

    public String senderName ;
    public int PostID;
    public int commentID;
    public String commentData;

    public commentEdit(String senderName ,
     int PostID, int commentID,String commentData  ){
        super(senderName);

        this.senderName=senderName;
        this.PostID=PostID;
        this.commentID=commentID;
        this.commentData=commentData;

    }   
}
