package com.PostFile;


import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;


public class postDataSendingFinished extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 12495L;

    public postDataSendingFinished(){
        super("senderName");
    
    }   
}
