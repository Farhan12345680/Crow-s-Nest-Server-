package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class removeIncomingFriendRequest extends payload implements Serializable{

    @Serial
    private static final long serialVersionUID=40L;
    private final String name;

    public removeIncomingFriendRequest(String clientName , String name){
        super(clientName);
        this.name=name;
    }

    public String getString(){
        return this.name;
    }
}