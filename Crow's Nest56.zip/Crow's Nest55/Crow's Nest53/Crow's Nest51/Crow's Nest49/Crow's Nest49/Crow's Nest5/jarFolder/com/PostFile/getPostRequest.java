package com.PostFile;

import java.io.Serializable;

import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;

public class getPostRequest extends payload implements Serializable{
        @Serial
    private static final long serialVersionUID = 12496L;

    public String senderName ;
    public int StartingRange;
    public int EndingRange;

    public getPostRequest(String senderName , int StartingRange ,int EndingRange){
        super(senderName);
        this.senderName=senderName;
        this.StartingRange=StartingRange;
        this.EndingRange=EndingRange;
    }   
}
