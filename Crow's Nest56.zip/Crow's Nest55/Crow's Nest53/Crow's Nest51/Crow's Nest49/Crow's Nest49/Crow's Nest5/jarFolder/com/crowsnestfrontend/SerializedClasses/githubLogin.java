package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class githubLogin extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID=90891L;
    
    public String name;
    public String imageURL;
    public String password;

    public githubLogin(String name , String imageURL ,String password){
        super(name);
        this.name =name ;
        this.imageURL=imageURL;
        this.password=password;

    }
    
}
