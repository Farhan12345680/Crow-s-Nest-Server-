package com.comment;


import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;


public class commentStreamEnder extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 13494L;

    public String senderName ;
    public int PostID;


    public commentStreamEnder(String senderName ,
     int PostID){
        super(senderName);

        this.senderName=senderName;
        this.PostID=PostID;

    }   
}
