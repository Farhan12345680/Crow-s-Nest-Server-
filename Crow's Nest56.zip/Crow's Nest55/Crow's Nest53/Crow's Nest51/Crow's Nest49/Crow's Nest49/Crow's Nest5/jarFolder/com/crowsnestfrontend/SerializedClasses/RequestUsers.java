package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class RequestUsers implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private String name;
    private String profilePicture;

    public RequestUsers(String name, String profilePicture  ){
        this.name=name;
        this.profilePicture=profilePicture;
    }

    public String getUserName(){
        return this.name;
    }

    public void setUserName(String name){
        this.name=name;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(String image){
        this.profilePicture=image;
    }
}
