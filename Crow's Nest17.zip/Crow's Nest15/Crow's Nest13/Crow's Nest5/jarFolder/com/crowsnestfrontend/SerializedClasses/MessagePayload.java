package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class MessagePayload implements Serializable {

    @Serial
    private static final long serialVersionUID=909L;
    public  String sender;
    public  final int messageID;
    public  final String text;
    public final int reactionType;
    public final String dateTime;


    public MessagePayload(int messageID, String text, int reactionType, String dateTime) {
        this.messageID = messageID;
        this.text = text;
        this.reactionType = reactionType;
        this.dateTime = dateTime;
    }
}
