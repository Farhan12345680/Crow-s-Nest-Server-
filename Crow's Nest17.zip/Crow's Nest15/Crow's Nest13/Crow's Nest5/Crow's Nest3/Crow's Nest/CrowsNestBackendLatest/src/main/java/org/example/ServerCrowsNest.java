package org.example;

import com.crowsnestfrontend.SerializedClasses.*;
import org.example.DatabaseCreation.DatabaseCreation;
import org.example.ISOnline.is_online;
import org.example.UserAuthentication.AuthChecker;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class ServerCrowsNest {
    public static final int PORT = 12345;

    public static final int SIGN_IN  = 0;
    public static final int SIGN_UP  = 1;
    public static final int FETCH_ALL = 5;
    public static final int UPLOAD_IMAGE = 4;
    public static final int LOGOUT   = 10;
    public static final int CURRENT_USER=3;
    public static final int FETCH_FRIENDS=6;
    public static final int FETCH_REQUESTS=7;

    public static void main(String[] args) throws IOException {
        try ( ServerSocket serverSocket = new ServerSocket(PORT) ) {
            System.out.println("Server listening on port " + PORT);

            while (true) {
                Socket client = serverSocket.accept();
                System.out.println("Accepted connection from " + client.getRemoteSocketAddress());

                Thread.startVirtualThread(() -> handleClient(client));
            }
        }
    }

    private static void handleClient(Socket client) {
        try ( ObjectOutputStream out = new ObjectOutputStream(client.getOutputStream());
              ObjectInputStream  in  = new ObjectInputStream(client.getInputStream()) ) {

            boolean alive = true;
            while (alive) {
                try {
                    alive = dispatchRequest(client, in, out);
                }
                catch (EOFException eof) {

                    System.out.println("Client " + client.getRemoteSocketAddress() + " disconnected.");
                    break;
                }
            }

        } catch (Exception e) {
            System.err.println("Connection error with " + client.getRemoteSocketAddress() + ":");
            e.printStackTrace();
        }
    }

    private static boolean dispatchRequest(Socket client,ObjectInputStream in,ObjectOutputStream out)
            throws IOException, ClassNotFoundException
    {
        ClientRequest req = (ClientRequest) in.readObject();
        int code = req.getRequestNumber();
        switch (code) {
            case SIGN_UP: {
                SignUpProfile prof = (SignUpProfile) in.readObject();

                if (AuthChecker.whetherIsUser(prof.getName())) {
                    out.writeObject(new returnQuery(-1, "Username already exists", new byte[0]));
                    return false;
                }

                AuthChecker.insertUser(prof.getName(), prof.getPassword());
                is_online.active_users
                        .computeIfAbsent(prof.getName(), k -> new ArrayList<>())
                        .add(client.getRemoteSocketAddress().toString());

                out.writeObject(new returnQuery(1, "User created successfully", new byte[0]));

                ImageChanger img = (ImageChanger) in.readObject();
                DatabaseCreation.addImagetoTheTable(img.getImageByte(), img.getName());


                return true;
            }

            case SIGN_IN: {
                SignInProfile user = (SignInProfile) in.readObject();
                System.out.println("SIGN_IN request for " + user.getName());

                if (!AuthChecker.whetherIsUser(user.getName())) {
                    out.writeObject(new returnQuery(-1, "User does not exist", new byte[0]));
                    return false;
                }
                if (!AuthChecker.doesPasswordMatch(user.getName(), user.getPassword())) {
                    out.writeObject(new returnQuery(-1, "Password doesn't match", new byte[0]));
                    return false;
                }

                is_online.active_users
                        .computeIfAbsent(user.getName(), k -> new ArrayList<>())
                        .add(client.getRemoteSocketAddress().toString());

                byte[] imageBytes = DatabaseCreation.getUserImageData(user.getName());
                out.writeObject(new returnQuery(1, "Login successful", imageBytes));
                return true;
            }

            case CURRENT_USER:{
                SignInProfile signIn=(SignInProfile) in.readObject();
                var list = is_online.active_users.get(signIn.getName());
                if (list != null) {
                    list.remove(client.getRemoteSocketAddress().toString());
                    if (list.isEmpty()) {
                        is_online.active_users.remove(signIn.getName());
                    }
                }
                return false;
            }
            case UPLOAD_IMAGE: {
                System.out.println("UPLOAD_IMAGE request from " + client.getRemoteSocketAddress());
                ImageChanger img = (ImageChanger) in.readObject();
                DatabaseCreation.addImagetoTheTable(img.getImageByte(), img.getName());
                out.writeObject(new returnQuery(1, "Image uploaded", new byte[0]));
                return true;
            }

            case LOGOUT: {
                SignInProfile who = (SignInProfile) in.readObject();
                if(who.getName()==null){
                    return false;
                }
                System.out.println("LOGOUT request for " + who.getName());
                var list = is_online.active_users.get(who.getName());
                var list2=server2.payloadBlockingQueue.get(who.getName());

                if (list != null) {
                    list.remove(client.getRemoteSocketAddress().toString());
                    if (list.isEmpty()) {
                        is_online.active_users.remove(who.getName());
                    }
                }

                if(list2!=null){
                    list2.remove(who.getName());
                    if (list2.isEmpty()) {
                        is_online.active_users.remove(who.getName());
                    }
                }
                return false;
            }

            default:
                System.err.println("Unknown request code: " + code);
                return true;
        }
    }
}
