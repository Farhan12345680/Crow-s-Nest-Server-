package org.example;

import com.crowsnestfrontend.SerializedClasses.*;
import org.example.DatabaseCreation.DatabaseCreation;
import org.example.DatabaseCreation.getAllUserDataFrom;
import org.example.Messages.MessageData;
import org.example.UserAuthentication.AuthChecker;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

import static org.example.DatabaseCreation.getAllUserDataFrom.updateFriendStatus;

public class server2 {
    public static int PORT=12346;
    public static ConcurrentHashMap<String ,BlockingQueue<payload> >payloadBlockingQueue=new ConcurrentHashMap<>() ;

    public static void main(String[] args){
        try{
            ServerSocket sc=new ServerSocket(  PORT);
            System.out.println("Server listening on port " + PORT);

            while (true) {

                Socket client=sc.accept();
                Thread.startVirtualThread(() -> {
                    server2.handlePayloadClient(client);
                });
            }
        }catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    public static void handlePayloadClient(Socket client) {
        ObjectOutputStream writer = null;
        ObjectInputStream reader = null;

        try {
            writer = new ObjectOutputStream(client.getOutputStream());
            reader = new ObjectInputStream(client.getInputStream());

            SignInProfile nameObject = (SignInProfile) reader.readObject();
            String name = nameObject.getName();
            String pass=nameObject.getPassword();
            System.out.println("UserName ->" +name
            );
            System.out.println(pass);
            if (!AuthChecker.whetherIsUser(name)) {
                client.close();
            }
            if (!AuthChecker.doesPasswordMatch(name, pass)) {
                client.close();
            }

            byte[] dataImage= DatabaseCreation.getUserImageData(name);
            payloadBlockingQueue.putIfAbsent(name, new LinkedBlockingQueue<>());

            for(var key :payloadBlockingQueue.keySet()){
                if(key.equals(name)){
                    continue;
                }
                server2.payloadBlockingQueue.get(key)
                        .add(new payLoadUsers(key, new RequestUsers(name, dataImage)));

            }

            getAllUserDataFrom.getUsers(name);
            getAllUserDataFrom.getRequestingSituation(name);
            getAllUserDataFrom.getRequestingSituationOwner(name);
            getAllUserDataFrom.showAllFriends(name);

            ObjectOutputStream finalWriter = writer;

            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        payload obj = payloadBlockingQueue.get(name).take();

                        if(obj instanceof  MessageGetterRequest){
                            
                        }
                        else if(obj instanceof MakeFriendRequest){
                            System.out.println("a friend request came");
                            String clientName=((payload)obj).clientName;
                            String targetName=((MakeFriendRequest)obj).getName();
                            DatabaseCreation.makeRequests(clientName , targetName);

                            if(payloadBlockingQueue.containsKey(targetName)){
                                payloadBlockingQueue.get(targetName).add(new updateStatus( targetName,clientName , 1));
                            }
                        }
                        else if(obj instanceof MakeBlock  ){
                            System.out.println("block user called");
                            DatabaseCreation.makeBlock(obj.clientName ,((MakeBlock)obj).nameGetter());
                        }
                        else if(obj instanceof MakeFriendRequestAccept){
                            System.out.println("a friend request Accept came");
                            String targetName=((MakeFriendRequestAccept )obj).getName();
                            String clientName=((payload)obj).clientName;
                            updateFriendStatus(clientName ,targetName);

                        }

                        else if(obj instanceof deleteFriendRequest){
                            System.out.println("Some one requested delete friend request operation");
                            String clientName=((payload)obj).clientName;
                            String targetName=((deleteFriendRequest)obj).getName();
                            DatabaseCreation.deleteRequests(clientName , targetName);
                            if(payloadBlockingQueue.containsKey(targetName)){
                                payloadBlockingQueue.get(targetName).add(new updateStatus( targetName,clientName , -1));
                            }
                        }

                        else if(obj instanceof removeIncomingFriendRequest){
                            String targetName=((payload)obj).clientName;
                            String clientName=((removeIncomingFriendRequest)obj).getString();
                            DatabaseCreation.deleteRequests(clientName , targetName);
                            if(payloadBlockingQueue.containsKey(clientName)){
                                payloadBlockingQueue.get(clientName).add(new updateStatus( clientName, targetName , 0));
                            }
                        }

                        else if(obj instanceof Message ){
                            String nameOfReceiver=((Message)obj).name();
                            String text1=((Message)obj).getText();
                            if(payloadBlockingQueue.containsKey(nameOfReceiver)){
                                int id=MessageData.makeMessage(obj.clientName, (Message) obj , 1);
                                String dateTime=MessageData.getDateTime(id);
                                payloadBlockingQueue.get(nameOfReceiver).add(new MessageForwarding(obj.clientName ,nameOfReceiver ,text1 ,id  ,dateTime,false,0));
                            }else{
                                MessageData.makeMessage(obj.clientName, (Message) obj ,0);
                            }
                        }

                        else{
                            finalWriter.writeObject(obj);
                            finalWriter.flush();
                        }


                    }
                } catch (IOException | InterruptedException e) {
                    System.err.println("Connection to " + name + " lost: " + e.getMessage());
                    try {
                        client.close();
                    } catch (IOException ignored) {}
                }
            });

            //info receiver
            ObjectInputStream finalReader = reader;
            Thread.startVirtualThread(()->{
                try {
                    while(true){
                        Object obj= finalReader.readObject();

                        if(obj instanceof  payload){
                            payloadBlockingQueue.get(((payload)obj).clientName).add((payload) obj);
                        }else{
                            System.out.println("this Object is unrecognizable");
                        }
                    }

                }catch (Exception e){
                    System.out.println(e.getMessage());
                }
            });

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Client handler error: " + e.getMessage());
            e.printStackTrace();
            try {
                client.close();
            } catch (IOException ignored) {}
        }
    }


}
