package org.example.ISOnline;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

public class is_online {
    public static ConcurrentHashMap<String , ArrayList<String>>active_users=new ConcurrentHashMap<String , ArrayList<String>>();

}
