package org.example.Messages;

import com.crowsnestfrontend.SerializedClasses.Message;
import org.example.DatabaseCreation.DatabaseCreation;

import java.sql.*;

public class MessageData {

    public static int makeMessage(String clientName, Message msg , int index){
        int result=0;
        String makeMessage= """
                INSERT INTO Messages(sender ,receiver ,content ,isSent) VALUES (?,?,?,?);
                """;

        try(Connection conn= DriverManager.getConnection(DatabaseCreation.URL);
            PreparedStatement ps =conn.prepareStatement(makeMessage ,PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1,clientName );
            ps.setString(2,msg.name());
            ps.setString(3,msg.getText());
            ps.setInt(4 ,index);

            result=ps.executeUpdate();

            if(result==0){
                System.out.println("this is Caused a problem");
                return 0;
            }else{
                return result;
            }
        }catch (Exception e){

        }
        return result;
    }
    public static String getDateTime(int id){
        String dateTime="";
        String select="SELECT time_sent from Messages WHERE id=?";

        try(Connection conn=DriverManager.getConnection(DatabaseCreation.URL);
            PreparedStatement ps=conn.prepareStatement(select)){

            ps.setInt(1,id);
            ResultSet rs=ps.executeQuery();
            while (rs.next()){
                return rs.getString(1);
            }
        }catch (SQLException e){

        }


        return dateTime;
    }
    public static void getAllMessage(String name){

    }
}
