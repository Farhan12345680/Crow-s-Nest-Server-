package com.crowsnestfrontend.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

public class ChatBubbleController {


    @FXML private Label messageLabel;
    @FXML private Label timestampLabel;
    @FXML private ImageView reactionImage;
    public void setText(String msg) {
        messageLabel.setText(msg);
    }
    public void setTime(String time) {
        timestampLabel.setText(time);
    }




//    public void setTimestamp(String time) {
//        timestampLabel.setText(time);
//    }
}
