package com.crowsnestfrontend.User;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class User {
    public String name;
    public byte[] imageURL;
    private final IntegerProperty isFriend = new SimpleIntegerProperty(0);

    public IntegerProperty isFriendProperty() {
        return isFriend;
    }

    public int getStatus() {
        return isFriend.get();
    }

    public void setIsFriend(int value) {
        isFriend.set(value);
    }

}
