package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.SerializedClasses.*;
import com.crowsnestfrontend.User.Owner;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import com.crowsnestfrontend.controllers.mainSceneController;
import javafx.application.Platform;

public class constantStream {

    public static BlockingQueue<payload> payloadBlockingQueue = new LinkedBlockingQueue<>();

    public static void streamGetter() {
        try {
            Socket socket = new Socket("localhost", 12346);
            ObjectOutputStream writer = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream reader = new ObjectInputStream(socket.getInputStream());

            writer.writeObject(new SignInProfile(Owner.nameId, Owner.password));

            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        Object obj = reader.readObject();

                        if (obj instanceof payload) {
                            payloadBlockingQueue.add((payload) obj);
                        } else {
                            System.err.println("Received unknown object: " + obj.getClass());
                        }
                    }
                } catch (EOFException e) {
                    System.err.println("Server closed connection.");
                } catch (IOException | ClassNotFoundException e) {
                    System.err.println("Error reading from server: " + e.getMessage());
                    e.printStackTrace();
                }
            });

            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        payload obj = payloadBlockingQueue.take();

                        if(obj instanceof  MessageGetterRequest){
                            writer.writeObject(obj);

                        }
                        else if(obj instanceof  MessageForwarding){
                            Platform.runLater(()->{
                                SceneManager.mainSceneContrller.messageListView.getItems().add(
                                        new com.crowsnestfrontend.Messages.Message(((MessageForwarding)obj).getText(), false)
                                );
                            });

                        }
                        else if(obj instanceof  updateStatus us){
                            UpdateStream.updater(us);
                        }else if (obj instanceof payLoadUsers users) {
                            constantUserStreamGetter.streamCaller(users);
                        }else if (obj instanceof payloadFriendRequest request) {
                            constantFriendRequestStream.streamCaller(request);
                        }else if(obj instanceof MakeFriendRequest mk){
                            System.out.println("Friend request made to"+mk.getName());
                            writer.writeObject(mk);
                        }else if(obj instanceof deleteFriendRequest del){
                            writer.writeObject(del);
                        }else if(obj instanceof MakeFriendRequestAccept mk){
                            System.out.println("Friend request accepted "+ mk.getName());
                            writer.writeObject(mk);
                        }else if (obj instanceof removeIncomingFriendRequest IFR){
                            System.out.println("Friend request rejected");
                            writer.writeObject(IFR);
                        }else if(obj instanceof MakeBlock){
                            writer.writeObject(obj);
                        }else if (obj instanceof Message){
                            writer.writeObject(obj);
                        }
                        else {
                            System.err.println("Unhandled payload type: " + obj.getClass());
                        }

                    }
                } catch (InterruptedException e) {
                    System.err.println("Processor thread interrupted.");
                    Thread.currentThread().interrupt();
                } catch (IOException e) {
                    System.out.println(e.getMessage());

                }
            });

        } catch (IOException e) {
            System.err.println("Failed to connect to server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
