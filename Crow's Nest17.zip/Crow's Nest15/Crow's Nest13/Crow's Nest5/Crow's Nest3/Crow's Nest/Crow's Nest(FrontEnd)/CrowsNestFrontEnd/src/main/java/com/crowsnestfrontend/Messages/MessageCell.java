package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.MainApplication;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.layout.HBox;

import java.io.IOException;

public class MessageCell extends ListCell<Message> {

    @FXML
    private Label messageLabel;

    @FXML
    private HBox OwnerMessage;

    private FXMLLoader loader;

    @Override
    protected void updateItem(Message message, boolean empty) {
        super.updateItem(message, empty);

        if (empty || message == null) {
            setText(null);
            setGraphic(null);
            return;
        }

        if (loader == null) {
            loader = new FXMLLoader(MainApplication.class.getResource("chatBubble.fxml"));
            loader.setController(this);
;
            try {
                loader.load();
                System.out.println("loader loaded");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        messageLabel.setText(message.getText());

        if (message.isOwnMessage()) {
            OwnerMessage.setStyle("-fx-alignment: center-right;");
            messageLabel.setStyle("-fx-background-color: #DCF8C6; -fx-padding: 8px; -fx-background-radius: 12px;");
        } else {
            OwnerMessage.setStyle("-fx-alignment: center-left;");
            messageLabel.setStyle("-fx-background-color: #FFFFFF; -fx-padding: 8px; -fx-background-radius: 12px;");
        }

        setText(null);
        setGraphic(OwnerMessage);
    }
}
