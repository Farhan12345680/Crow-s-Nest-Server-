package org.example;

import org.example.DatabaseCreation.DatabaseCreation;

import java.io.IOException;
import java.sql.SQLException;

public class whole {

    public static void main(String[] args) throws IOException, SQLException, InterruptedException {
        DatabaseCreation.main(null);
        Thread.startVirtualThread(()->{
            try {
                ServerCrowsNest.main(null);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        Thread.startVirtualThread(()->{
            server2.main(null);

        });
        Thread.currentThread().join();

    }
}
