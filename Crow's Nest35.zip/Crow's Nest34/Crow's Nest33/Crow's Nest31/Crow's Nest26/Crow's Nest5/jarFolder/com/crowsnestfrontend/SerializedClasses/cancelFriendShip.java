package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class cancelFriendShip extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=89L;
    private String name ;

    public cancelFriendShip(String clientName , String name){
        super(clientName);
        this.name=name;
    }

    public String getName(){
        return this.name;
    }

}
