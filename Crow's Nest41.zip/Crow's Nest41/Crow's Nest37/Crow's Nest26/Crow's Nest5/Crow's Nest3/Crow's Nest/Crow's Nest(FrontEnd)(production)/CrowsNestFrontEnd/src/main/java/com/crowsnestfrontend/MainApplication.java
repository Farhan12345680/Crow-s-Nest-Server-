package com.crowsnestfrontend;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.User.Owner;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Objects;

public class MainApplication extends Application {


    @Override
    public void start(Stage stage) throws IOException, ClassNotFoundException {
        SceneManager.globalStage=stage;
        try {
            stage.getIcons().add(new Image(
                    Objects.requireNonNull(MainApplication.class.getResourceAsStream("images/raven.png"))
            ));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        Class.forName("com.crowsnestfrontend.Utility.SyncManager");

        stage.setTitle("Crow's Nest");
        SignBranchingHandler.signBranchLogicHandler();

        stage.show();

        stage.setResizable(false);
        stage.setOnCloseRequest((event)->{
                    closingFunction();
                }
        );
        Runtime.getRuntime().addShutdownHook(new Thread(MainApplication::closingFunction));
    };

    public static void main(String[] args) {
        launch();
    }

    public static void closingFunction(){
        try(Socket socket=new Socket("13.76.73.158",12345);
            ObjectOutputStream writer=new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream reader=new ObjectInputStream(socket.getInputStream())
        ){
            writer.writeObject(new ClientRequest(10));
            writer.writeObject(new SignInProfile(Owner.nameId ,""));
            writer.flush();
            Object readString=reader.readObject();
            if(readString!=null){
                System.out.println("closing request came");
            }

        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

}