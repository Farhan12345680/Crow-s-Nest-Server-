package com.crowsnestfrontend.webrtcCaller;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import dev.onvoid.webrtc.*;
import dev.onvoid.webrtc.media.MediaStreamTrack;
import dev.onvoid.webrtc.media.audio.*;
import dev.onvoid.webrtc.media.video.*;
import javafx.application.Platform;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.stage.Modality;
import javafx.stage.StageStyle;

import java.util.ArrayList;
import java.util.List;

public class makeCall {

    private PeerConnectionFactory factory;
    private RTCPeerConnection peerConnection;
    private AudioTrack localAudio;
    private VideoTrack localVideo;

    public makeCall() {
        factory = new PeerConnectionFactory();

        try {
            Dialog<Void> dialog = new Dialog<>();
            dialog.initStyle(StageStyle.TRANSPARENT);
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.setDialogPane(new DialogPane());

            ButtonType dummyButton = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
            dialog.getDialogPane().getButtonTypes().add(dummyButton);
            dialog.getDialogPane().lookupButton(dummyButton).setVisible(false);
            dialog.getDialogPane().lookupButton(dummyButton).setManaged(false);

            // Add your custom callerWaitingScene content
            callerWaitingScene callWaiting = new callerWaitingScene(dialog::close);
            dialog.getDialogPane().setContent(callWaiting);

            Platform.runLater(() -> {
                dialog.show();

                RTCConfiguration config = new RTCConfiguration();
                RTCIceServer iceServer = new RTCIceServer();
                iceServer.urls.add("stun:stun.l.google.com:19302");
                config.iceServers.add(iceServer);

                // 4️⃣ Create PeerConnection with observer
                peerConnection = factory.createPeerConnection(config, new PeerConnectionObserver() {
                    @Override
                    public void onIceCandidate(RTCIceCandidate candidate) {
                        System.out.println("New ICE candidate: " + candidate.sdp);
                        // Send candidate to remote peer via signaling server
                    }

                    @Override
                    public void onConnectionChange(RTCPeerConnectionState state) {
                        System.out.println("PeerConnection state: " + state);
                    }

                    @Override
                    public void onIceConnectionChange(RTCIceConnectionState state) {
                        System.out.println("ICE connection state: " + state);
                    }

                    @Override
                    public void onTrack(RTCRtpTransceiver transceiver) {
                        MediaStreamTrack track = transceiver.getReceiver().getTrack();
                        System.out.println("Received remote track: " + track.getKind());
                    }

                    @Override
                    public void onDataChannel(RTCDataChannel dataChannel) {
                        System.out.println("DataChannel created: " + dataChannel.getLabel());
                    }
                });

                // 5️⃣ Create local audio and video tracks
                AudioOptions audioOptions = new AudioOptions();
                audioOptions.echoCancellation = true;
                localAudio = factory.createAudioTrack("audio0", factory.createAudioSource(audioOptions));

                VideoDeviceSource videoSource = new VideoDeviceSource();
                localVideo = factory.createVideoTrack("video0", videoSource);

                // 6️⃣ Add tracks to PeerConnection
                List<String> streamIds = new ArrayList<>();
                streamIds.add("stream1");
                peerConnection.addTrack(localAudio, streamIds);
                peerConnection.addTrack(localVideo, streamIds);

                // 7️⃣ Create an offer
                RTCOfferOptions offerOptions = new RTCOfferOptions();
                peerConnection.createOffer(offerOptions, new CreateSessionDescriptionObserver() {
                    @Override
                    public void onSuccess(RTCSessionDescription desc) {
                        // Set local description using SetSessionDescriptionObserver
                        peerConnection.setLocalDescription(desc, new SetSessionDescriptionObserver() {
                            @Override
                            public void onSuccess() {
                                System.out.println("Local description set successfully!");
                            }

                            @Override
                            public void onFailure(String error) {
                                System.out.println("Failed to set local description: " + error);
                            }
                        });

                        // Send the offer to remote peer via your signaling server
                        System.out.println("Offer created! SDP: " + desc.sdp);
                    }

                    @Override
                    public void onFailure(String error) {
                        System.out.println("Failed to create offer: " + error);
                    }
                });

            });

        } catch (Exception e) {
         }
    }
}
