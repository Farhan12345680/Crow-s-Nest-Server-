package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class OwnerUser implements Serializable {
    @Serial
    public static final long serialVersionUID=6L;

    private final String name;

    private final String password;

    public OwnerUser(String name,  String password) {
        this.name = name;

        this.password = password;
    }

    public String getName() {
        return name;
    }



    public String getPassword() {
        return password;
    }
}
