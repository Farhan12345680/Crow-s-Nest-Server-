package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;



public class deleteMessage extends payload implements Serializable{

    @Serial
    private static final long serialVersionUID=90890L;

    public int messageID;
    public String initiator;
    public String owner;
    public String receiver;
    
    public deleteMessage(int messageID ,String initiator ,String owner,String revceiver){
        super(initiator);
        this.messageID=messageID;
        this.initiator=initiator;
        this.owner=owner;
        this.receiver=revceiver;
        
    }
}