package com.crowsnestfrontend.SerializedClasses;
import java.io.Serial;
import java.io.Serializable;


public class Message extends payload implements Serializable {

    @Serial
    private static final long serialVersionUID=90L;
    private final String name ;
    private final String text;
    private final int direction;
    private final int isReply;
    private final int isReplyMessageID=0;

    public Message(String clientName , String name , String text , int direction, int isReply){
        super(clientName);
        this.text=text;
        this.name=name;
        this.direction=direction;
        this.isReply = isReply;
    }

    public String name(){
        return this.name;
    }

    public String getText(){
        return this.text;
    }
    public int getDirection(){
        return this.direction;
    }

    public int getIsReply() {
        return isReply;
    }
    public int getIsReplyMessageID(){
        return isReplyMessageID;
    }
}