package com.crowsnestfrontend.webrtcCaller;

import com.ClientSerializedClasses.accept;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.SelectedUserData;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.util.Duration;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;

public class CallerIncoming extends Pane {
    public static CallerIncoming incoming;
    @FXML
    public ImageView CallerImage;
    @FXML
    public ImageView rejectCall;
    @FXML
    public ImageView acceptCall;
    Runnable run;
    @FXML
    public Text CallerName;

    public Thread runnable ;

    public MediaPlayer  mediaPlayer;

    public CallerIncoming(String name , byte[] image ,Runnable run){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("incomingCall.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        CallerName.setText(name);
        CallerImage.setImage(new Image(new ByteArrayInputStream(image)));
        incoming=this;
        this.run=run;

        acceptCall.setOnMouseClicked((a)->{
            SelectedUserData.name.set(name);
            SelectedUserData.image=image;
            Callee.callee.sendObject(new accept());
            this.stopCall();
            run.run();
            CallerIncoming.incoming=null;
            Platform.runLater(()->{
                try {
                    SceneManager.globalStage.setScene(new VideoScene());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        });

        this.runnable=Thread.ofVirtual().start(()->{

            String ssound = "ringtone.mp3";

            Media sound = new Media(new File(ssound).toURI().toString());

            mediaPlayer = new MediaPlayer(sound);
            mediaPlayer.setOnEndOfMedia(() -> {
                mediaPlayer.seek(Duration.ZERO);
                mediaPlayer.play();
            });
            mediaPlayer.play();
        });
        rejectCall.setOnMouseClicked((a)->{

            Callee.callee.stopCallee();
            this.stopCall();
        });
    }

    public void stopCall() {
        try {
            mediaPlayer.stop();
            mediaPlayer.dispose();
        }catch (Exception e){

        }

        Platform.runLater(()->{
            this.run.run();
        });

    }

}
