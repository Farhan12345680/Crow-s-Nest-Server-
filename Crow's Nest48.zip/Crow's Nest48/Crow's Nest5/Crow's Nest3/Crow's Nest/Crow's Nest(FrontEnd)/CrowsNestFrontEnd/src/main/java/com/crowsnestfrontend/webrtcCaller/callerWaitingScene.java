package com.crowsnestfrontend.webrtcCaller;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.SelectedUserData;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

import java.io.ByteArrayInputStream;
import java.io.IOException;

public class callerWaitingScene extends Pane {
    public static callerWaitingScene callerWaitingInstance;

    @FXML
    public ImageView CallingUserImage;

    @FXML
    public Text CallingUserName;

    @FXML
    public ImageView StopCalling;
    public Runnable run;

    public callerWaitingScene(Runnable run){

        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("currentlyCallingWaiting.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        CallingUserImage.setImage(new Image(new ByteArrayInputStream(SelectedUserData.image)));
        CallingUserName.setText(SelectedUserData.name.get());
        StopCalling.setOnMouseClicked((a)->{
            Thread.startVirtualThread(()->{
                Platform.runLater(()->{
                    run.run();
                });
                Caller.callerObject.stopCaller();
            });
        });

        callerWaitingScene.callerWaitingInstance=this;

        this.run=run;



    }
}
