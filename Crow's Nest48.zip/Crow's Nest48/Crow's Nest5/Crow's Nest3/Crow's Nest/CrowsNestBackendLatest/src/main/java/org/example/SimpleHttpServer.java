package org.example;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import org.example.DatabaseCreation.InmemoryDataBaseCreation;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class SimpleHttpServer {


    public static void main(String[] args) throws IOException {
        int port = 8080;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);


        server.createContext("/", new MyHandler());
        server.createContext("/show" , new ActiveUserHandler());
        server.createContext("/busy" ,new BusyUserHandler());
        server.setExecutor(null);
        server.start();
        System.out.println("Server started on port " + port);

    }


    static class MyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Thread.startVirtualThread(()->{
                String response = "Hello from HttpServer!";
                try {
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

            });

        }
    }

    static class ActiveUserHandler implements  HttpHandler{

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Thread.startVirtualThread(()->{

                String response = InmemoryDataBaseCreation.showAllActiveUsers();
                try {
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

            });

        }
    }

    static class BusyUserHandler implements  HttpHandler{

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Thread.startVirtualThread(()->{

                String response = InmemoryDataBaseCreation.showAllBusyUsers();
                try {
                    exchange.sendResponseHeaders(200, response.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

            });

        }
    }
    static class signOutHandler implements HttpHandler{
           @Override
            public void handle(HttpExchange exchange)throws IOException{
               Thread.startVirtualThread(()->{

                   String response = InmemoryDataBaseCreation.showAllBusyUsers();
                   try {
                       exchange.sendResponseHeaders(200, response.getBytes().length);
                       OutputStream os = exchange.getResponseBody();
                       os.write(response.getBytes());
                       os.close();

                   } catch (IOException e) {
                       throw new RuntimeException(e);
                   }

               });
            }
    }
}
