package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.ClientSideDataBase.changeOwnerClientDatabase;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.ImageChanger;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.User.Owner;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.event.ActionEvent;
import javafx.stage.Window;
import org.controlsfx.control.spreadsheet.SpreadsheetCellType;

import java.io.File;


import java.io.*;
import java.net.Socket;
import java.net.URL;


import java.util.ResourceBundle;
import java.util.concurrent.CountDownLatch;

public class ProfileController implements Initializable {

    @FXML
    public Label usernameLabel;
    @FXML
    public Button uploadButton;
    @FXML
    public Button signOutButton;
    @FXML
    public ImageView profileImageView;

    @FXML
    public Button backButton;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        uploadButton.setOnAction(this::onUploadButton);
        signOutButton.setOnAction(this::onSignOutButton);
        backButton.setOnAction(this::setBackButton);
    }


    @FXML
    private void setBackButton(ActionEvent event) {
        SceneManager.globalStage.setScene(SceneManager.mainScene);
    }


    @FXML
    private void onUploadButton(ActionEvent event) {
        Window ownerWindow = profileImageView.getScene().getWindow();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Profile Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp")
        );

        File selectedFile = fileChooser.showOpenDialog(ownerWindow);
        if (selectedFile != null) {
            CountDownLatch UPLOADER_LATCH=new CountDownLatch(1);
            Platform.runLater(()->{
                SceneManager.globalStage.setScene(SceneManager.loadingScene);
                SceneManager.globalStage.centerOnScreen();
            });
            Thread.startVirtualThread(()->{
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                try {
                    net.coobird.thumbnailator.Thumbnails.of(selectedFile)
                            .size(150, 150)
                            .outputFormat("png")
                            .toOutputStream(baos);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                byte[] imageBytes = baos.toByteArray();

                Image image = new Image(new ByteArrayInputStream(imageBytes));
                profileImageView.setImage(image);
                Owner.image = imageBytes;

                try (Socket socket = new Socket("13.76.73.158", 12345);
                     ObjectOutputStream out =new ObjectOutputStream( socket.getOutputStream());
                     ObjectInputStream in = new ObjectInputStream(socket.getInputStream())
                     ) {
                    out.writeObject(new ClientRequest(4));

                    out.writeObject(new ImageChanger(Owner.nameId ,Owner.image));

                    out.flush();

                    Object obj=in.readObject();
                    if(obj != null){
                        System.out.println("image upload request success");
                    }
                    changeOwnerClientDatabase.addImagetoTheTable(imageBytes, Owner.nameId);
                    SceneManager.mainSceneContrller.Personal_image_id.setImage(image);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                } finally {
                    UPLOADER_LATCH.countDown();
                }


            });

            Thread.startVirtualThread(()->{
               try{
                   UPLOADER_LATCH.await();
                   Platform.runLater(()->{
                       SceneManager.globalStage.setScene(SceneManager.profileScene);
                       SceneManager.globalStage.centerOnScreen();

                   });
               }catch (Exception e){
                   System.out.println(e.getMessage());
               }

            });

        }
    }


    @FXML
    private void onSignOutButton(ActionEvent event) {
        File fileToDelete = new File("clientData.db");

        if (fileToDelete.delete()) {
            System.out.println("File deleted successfully.");

        } else {

            SceneManager.globalStage.setOnCloseRequest(d -> {
                System.out.println(Owner.nameId);
                try(Socket socket=new Socket("13.76.73.158",12345);
                    ObjectOutputStream writer=new ObjectOutputStream(socket.getOutputStream());
                    ObjectInputStream reader = new ObjectInputStream(socket.getInputStream());
                    ){
                    writer.writeObject(new ClientRequest(10));
                    writer.writeObject(new SignInProfile(Owner.nameId ,""));
                    writer.flush();
                    Object  data=reader.readObject();
                    if(data!=null){
                        System.out.println("closing request came back in ");
                    }
                } catch (IOException | ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }finally {

                }
            });
        }
        SceneManager.globalStage.close();

    }
}
