package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class RequestUsers implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    private String name;
    private byte[] profilePicture;

    public RequestUsers(String name, byte[] profilePicture  ){
        this.name=name;
        this.profilePicture=profilePicture;
    }

    public String getUserName(){
        return this.name;
    }

    public void setUserName(String name){
        this.name=name;
    }

    public byte[] getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(byte[] image){
        this.profilePicture=image;
    }
}
