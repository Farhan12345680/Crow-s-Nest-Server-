package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class payloadFriendRequest extends payload implements Serializable {

    @Serial
    private static final long serialVersionUID=18L;
    private final pendingFriendRequest pfr;

    public payloadFriendRequest(String clientName, pendingFriendRequest pfr) {
        super(clientName);
        this.pfr = pfr;
    }


    public pendingFriendRequest getPfr() {
        return pfr;
    }
}
