package org.example;

import com.crowsnestfrontend.SerializedClasses.*;
import org.example.DatabaseCreation.DatabaseCreation;
import org.example.DatabaseCreation.getAllUserDataFrom;
import org.example.Messages.MessageData;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

import static org.example.DatabaseCreation.getAllUserDataFrom.updateFriendStatus;

public class server2 {
    public static int PORT = 12346;
    public static ConcurrentHashMap<String, BlockingQueue<payload>> payloadBlockingQueue = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        try {
            ServerSocket sc = new ServerSocket(PORT);
            System.out.println("Server listening on port " + PORT);

            while (true) {
                Socket client = sc.accept();
                Thread.startVirtualThread(() -> handlePayloadClient(client));
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void handlePayloadClient(Socket client) {
        ObjectOutputStream writer = null;
        ObjectInputStream reader = null;

        try {
            writer = new ObjectOutputStream(client.getOutputStream());
            reader = new ObjectInputStream(client.getInputStream());

            SignInProfile nameObject = (SignInProfile) reader.readObject();
            String name = nameObject.getName();

            ObjectOutputStream finalWriter1 = writer;
            if(nameObject instanceof signInProfileWithTimeStamp ){
                System.out.println("caller called caller called");
                Thread.startVirtualThread(() -> {

                    getAllUserDataFrom.getUsers(name,(((signInProfileWithTimeStamp) nameObject).UTCtimeZone));
                    getAllUserDataFrom.getRequestingSituation(name,(((signInProfileWithTimeStamp) nameObject).UTCtimeZone));
                    getAllUserDataFrom.getRequestingSituationOwner(name,(((signInProfileWithTimeStamp) nameObject).UTCtimeZone));
                    getAllUserDataFrom.showAllFriends(name,(((signInProfileWithTimeStamp) nameObject).UTCtimeZone));
                    //MessageData.getAllMessage(name ,(((signInProfileWithTimeStamp) nameObject).UTCtimeZone),finalWriter1);
                    getAllUserDataFrom.allMessageReaction(name  ,(((signInProfileWithTimeStamp) nameObject).UTCtimeZone) , finalWriter1);
                    getAllUserDataFrom.makeBlockUser(name  ,(((signInProfileWithTimeStamp) nameObject).UTCtimeZone) , finalWriter1);

                });
            }
            else{

                byte[] dataImage = DatabaseCreation.getUserImageData(name);
                payloadBlockingQueue.putIfAbsent(name, new LinkedBlockingQueue<>());

                for (var key : payloadBlockingQueue.keySet()) {
                    if (key.equals(name)) continue;
                    payloadBlockingQueue.get(key)
                            .add(new payLoadUsers(key, new RequestUsers(name, dataImage)));
                }

                Thread.startVirtualThread(() -> {
                    getAllUserDataFrom.getUsers(name,"-4713-11-24 00:00:00");
                    getAllUserDataFrom.getRequestingSituation(name ,"-4713-11-24 00:00:00");
                    getAllUserDataFrom.getRequestingSituationOwner(name ,"-4713-11-24 00:00:00");
                    getAllUserDataFrom.showAllFriends(name ,"-4713-11-24 00:00:00");
                    //MessageData.getAllMessage(name ,"-4713-11-24 00:00:00",finalWriter1);
                    getAllUserDataFrom.allMessageReaction(name  ,"-4713-11-24 00:00:00",finalWriter1 );
                });
            }


            ObjectOutputStream finalWriter = writer;

            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        payload obj = payloadBlockingQueue.get(name).take();

                        switch (obj) {
                            case Unfriend unfriend -> {
                                DatabaseCreation.makeUNFriend(unfriend);
                                String tempString = unfriend.unfriendReceiver;

                                UtilityUpdateStatusSender(tempString, unfriend.clientName, 13);
                            }

                            case MessageGetterRequest msg -> Thread.startVirtualThread(() ->
                                    MessageData.getAllMessage(obj.clientName , msg.time ,finalWriter));

                            case MakeFriendRequest makeFriendRequest -> {
                                String clientName = obj.clientName;
                                String targetName = makeFriendRequest.getName();
                                DatabaseCreation.makeRequests(clientName, targetName);
                                UtilityUpdateStatusSender(targetName ,clientName ,1);
                            }
                            case MakeBlock makeBlock ->{
                                String receiver = makeBlock.nameGetter();
                                DatabaseCreation.makeBlock(obj.clientName,receiver );
                                System.out.println(receiver+"<---- name came here");
                                try {
                                    if (payloadBlockingQueue.containsKey(receiver)) {
                                        System.out.println("name came here 2");
                                        payloadBlockingQueue.get(receiver).add(
                                                new updateStatus(receiver, obj.clientName, -144)
                                        );
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                            case MakeFriendRequestAccept makeFriendRequestAccept -> {
                                String targetName = makeFriendRequestAccept.getName();
                                String clientName = obj.clientName;
                                updateFriendStatus(clientName, targetName);
                                UtilityUpdateStatusSender(clientName ,targetName ,3);
                                UtilityUpdateStatusSender(targetName ,clientName ,3);
                            }

                            case deleteFriendRequest deleteFriendRequest -> {
                                String clientName = obj.clientName;
                                String targetName = deleteFriendRequest.getName();
                                DatabaseCreation.deleteRequests(clientName, targetName);

                                UtilityUpdateStatusSender(targetName ,clientName ,-1);
                            }
                            case removeIncomingFriendRequest removeIncomingFriendRequest -> {
                                String targetName = obj.clientName;
                                String clientName = removeIncomingFriendRequest.getString();
                                DatabaseCreation.deleteRequests(clientName, targetName);

                                UtilityUpdateStatusSender(clientName ,targetName ,0);
                            }
                            case Message message -> {
                                String nameOfReceiver = message.name();
                                String text1 = message.getText();
                                ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC);
                                String formattedTime = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

                                int id=0;
                                if (payloadBlockingQueue.containsKey(nameOfReceiver)) {
                                    id=MessageData.makeMessage(obj.clientName, (Message) obj, 1);
                                } else {
                                    id=MessageData.makeMessage(obj.clientName, (Message) obj, 0);
                                }
                                System.out.println("this is the id of the message sent --->"+id);
                                MessagePayload payload=new MessagePayload(
                                        message.clientName,
                                        id,
                                        text1,
                                        0,
                                        formattedTime
                                );
                                payload.sender=message.name();

                                synchronized (finalWriter) {
                                    finalWriter.writeObject(payload);
                                    finalWriter.flush();
                                }
                                if (payloadBlockingQueue.containsKey(nameOfReceiver)) {
                                      payloadBlockingQueue.get(nameOfReceiver).add(payload);
                                }

                            }

                            case payloadMessageReaction msgReaction -> {
                                String MESSAGE_OWNER=MessageData.returnMessageSender(msgReaction.messageID ,msgReaction);
                                if(MESSAGE_OWNER.equals(name)){
                                    synchronized (finalWriter){
                                        finalWriter.writeObject(msgReaction);
                                        finalWriter.flush();
                                    }
                                    break;
                                }
                                if (payloadBlockingQueue.containsKey(MESSAGE_OWNER)) {
                                         payloadBlockingQueue.get(MESSAGE_OWNER).add(msgReaction);
                                }
                                //MessageData.setReaction(msgReaction.messageID , msgReaction.reactionType);

                            }
                            default -> {
                                synchronized (finalWriter) {
                                    finalWriter.writeObject(obj);
                                    finalWriter.flush();
                                }
                            }
                        }
                    }
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                    try {
                        client.close();
                    }
                    catch (IOException ignored) {}
                }
            });

            ObjectInputStream finalReader = reader;
            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        Object obj = finalReader.readObject();
                        if (obj instanceof payload) {
                            payloadBlockingQueue.get(((payload) obj).clientName).add((payload) obj);
                        } else {
                            System.out.println("This object is unrecognizable");
                        }
                    }
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            });

        }
        catch (IOException | ClassNotFoundException e) {
            System.err.println("Client handler error: " + e.getMessage());
            e.printStackTrace();
            try {
                client.close();
            } catch (IOException ignored) {}
        }
    }

    private static void UtilityUpdateStatusSender(String  client, String reciever, int index) {
        try {
            if (payloadBlockingQueue.containsKey(client)) {
                payloadBlockingQueue.get(client).add(
                        new updateStatus(client, reciever, index)
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
