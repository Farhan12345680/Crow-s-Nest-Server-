package com.crowsnestfrontend.webrtcCaller;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.*;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import nu.pattern.OpenCV;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.CvType;
import org.opencv.videoio.VideoCapture;

public class VideoScene extends Application {

    private VideoCapture capture;
    private ImageView imageView;
    private Mat frame;
    private byte[] buffer;
    private WritableImage writableImage;
    private PixelWriter pixelWriter;

    public static void main(String[] args) {
        OpenCV.loadShared();
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        imageView = new ImageView();
        StackPane root = new StackPane(imageView);
        Scene scene = new Scene(root, 640, 480);

        stage.setTitle("Video Playback");
        stage.setScene(scene);
        stage.show();

        capture = new VideoCapture(0);
        if (!capture.isOpened()) {
            System.err.println("Failed to open video file.");
            return;
        }

        frame = new Mat();

        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (capture.read(frame)) {
                    Mat rotatedFrame = new Mat();
                    Core.rotate(frame, rotatedFrame, Core.ROTATE_90_CLOCKWISE); // or ROTATE_90_CLOCKWISE

                    int width = rotatedFrame.width();
                    int height = rotatedFrame.height();

                    if (buffer == null || buffer.length != width * height * 4) {
                        buffer = new byte[width * height * 4];
                        writableImage = new WritableImage(width, height);
                        pixelWriter = writableImage.getPixelWriter();
                        imageView.setImage(writableImage);
                    }

                    byte[] bgrData = new byte[width * height * 3];
                    rotatedFrame.get(0, 0, bgrData);

                    for (int i = 0, j = 0; i < bgrData.length; i += 3, j += 4) {
                        buffer[j] = bgrData[i];       // Blue
                        buffer[j + 1] = bgrData[i+1]; // Green
                        buffer[j + 2] = bgrData[i+2]; // Red
                        buffer[j + 3] = (byte) 255;   // Alpha
                    }

                    pixelWriter.setPixels(0, 0, width, height,
                            PixelFormat.getByteBgraInstance(), buffer, 0, width * 4);

                    rotatedFrame.release(); // cleanup memory
                } else {
                    stop();
                    capture.release();
                }
            }

        };

        timer.start();
    }

    @Override
    public void stop() throws Exception {
        super.stop();
        if (capture != null && capture.isOpened()) {
            capture.release();
        }
    }
}
