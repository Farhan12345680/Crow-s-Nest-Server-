package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.webrtcCaller.VideoScene;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaView;

public class VideoSceneController {
    @FXML
    public ImageView otherView;
    @FXML
    public ImageView endCall;
    @FXML
    public ImageView code;
    @FXML
    public ImageView camera;
    @FXML
    public ImageView mic;

    @FXML
    public ImageView selfView;

    // Container for video playback
    @FXML
    public Pane videoContainer;

    @FXML
    public void initialize(){
        endCall.setOnMouseClicked((_)->{
            SceneManager.globalStage.setScene(SceneManager.mainScene);
            SceneManager.globalStage.show();
        });

        selfView.setOnMouseClicked((_)->{
            System.out.println("Self view clicked");
        });
    }

    public void setImage(WritableImage image){
        selfView.setImage(image);
    }

    // Attach MediaView for video playback
    public void setMediaView(MediaView mediaView){
        if (videoContainer != null){
            videoContainer.getChildren().clear();
            videoContainer.getChildren().add(mediaView);
            mediaView.fitWidthProperty().bind(videoContainer.widthProperty());
            mediaView.fitHeightProperty().bind(videoContainer.heightProperty());
        }
    }
}
