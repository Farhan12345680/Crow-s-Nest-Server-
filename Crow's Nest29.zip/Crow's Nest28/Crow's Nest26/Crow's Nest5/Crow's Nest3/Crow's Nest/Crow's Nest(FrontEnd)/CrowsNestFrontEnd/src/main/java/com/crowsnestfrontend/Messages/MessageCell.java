package com.crowsnestfrontend.Messages;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.payloadMessageReaction;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.controllers.mainSceneController;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

import java.io.IOException;

import static com.crowsnestfrontend.UserStream.constantStream.payloadBlockingQueue;

public class MessageCell extends ListCell<Message> {

    @FXML
    private Label messageLabel;

    @FXML
    private HBox OwnerMessage;

    @FXML
    private Label BubbleTime;

    @FXML
    private Pane reactionPanel;

    @FXML
    private ImageView reactionImage;

    @FXML
    private ImageView neutral;

    @FXML
    private ImageView haha;

    @FXML
    private ImageView love;

    @FXML
    private ImageView angry;

    private FXMLLoader loader;

    private Message currentMessage;

    private static final Image IMG_NEUTRAL = new Image(MainApplication.class.getResourceAsStream("images/neutral.png"));
    private static final Image IMG_HAHA = new Image(MainApplication.class.getResourceAsStream("images/face(haha).png"));
    private static final Image IMG_LOVE = new Image(MainApplication.class.getResourceAsStream("images/heart-eyes.png"));
    private static final Image IMG_ANGRY = new Image(MainApplication.class.getResourceAsStream("images/angry.png"));

    private final ChangeListener<Number> reactionListener = (obs, oldVal, newVal) -> {
        int rt = newVal == null ? 0 : newVal.intValue();
        switch (rt) {
            case 1 -> reactionImage.setImage(IMG_HAHA);
            case 2 -> reactionImage.setImage(IMG_LOVE);
            case 3 -> reactionImage.setImage(IMG_ANGRY);
            default -> reactionImage.setImage(IMG_NEUTRAL);
        }
    };

    @Override
    protected void updateItem(Message message, boolean empty) {
        super.updateItem(message, empty);

        if (empty || message == null) {
            if (currentMessage != null) {
                try {
                    currentMessage.reaction_type.removeListener(reactionListener);
                } catch (Exception ignored) {}
            }
            currentMessage = null;
            // drop loaded FXML/controller so the old controller can be GC'd
            loader = null;
            setText(null);
            setGraphic(null);
            return;
        }

        if (currentMessage != null && currentMessage != message) {
            try {
                currentMessage.reaction_type.removeListener(reactionListener);
            } catch (Exception ignored) {}
        }

        this.currentMessage = message;

        if (loader == null) {
            loader = new FXMLLoader(MainApplication.class.getResource("chatBubble.fxml"));
            loader.setController(this);
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        messageLabel.setText(message.getText());
        BubbleTime.setText(message.formattedTime);

        if (message.isOwnMessage()) {
            reactionImage.setMouseTransparent(true);
            OwnerMessage.setStyle("-fx-alignment: center-right;");
            messageLabel.setStyle("-fx-background-color: #DCF8C6; -fx-padding: 8px; -fx-background-radius: 12px;");
        } else {
            OwnerMessage.setStyle("-fx-alignment: center-left;");
            messageLabel.setStyle("-fx-background-color: #FFFFFF; -fx-padding: 8px; -fx-background-radius: 12px;");
        }

        reactionPanel.setVisible(false);
        reactionPanel.setManaged(false);
        reactionImage.setOnMouseClicked(e -> {
            reactionPanel.setVisible(!reactionPanel.isVisible());
            reactionPanel.setManaged(reactionPanel.isVisible());
        });

        try {
            currentMessage.reaction_type.addListener(reactionListener);
        } catch (Exception ignored) {}

        try {
            Number currentVal = currentMessage.reaction_type.getValue();
            reactionListener.changed(null, null, currentVal == null ? 0 : currentVal);
        } catch (Exception ignored) {
            try {
                reactionListener.changed(null, null, currentMessage.reaction_type.get());
            } catch (Exception ignored2) {}
        }

        neutral.setOnMouseClicked(e -> setReaction(currentMessage.messageID, 0, IMG_NEUTRAL));
        haha.setOnMouseClicked(e -> setReaction(currentMessage.messageID, 1, IMG_HAHA));
        love.setOnMouseClicked(e -> setReaction(currentMessage.messageID, 2, IMG_LOVE));
        angry.setOnMouseClicked(e -> setReaction(currentMessage.messageID, 3, IMG_ANGRY));

        setText(null);
        setGraphic(OwnerMessage);
    }

    private void updateReactionImage(int reactionType) {
        switch (reactionType) {
            case 1 -> reactionImage.setImage(IMG_HAHA);
            case 2 -> reactionImage.setImage(IMG_LOVE);
            case 3 -> reactionImage.setImage(IMG_ANGRY);
            default -> reactionImage.setImage(IMG_NEUTRAL);
        }
    }

    private void setReaction(int messageID, int reaction, Image tempImage) {
        if (currentMessage == null) return;

        if (currentMessage.reaction_type.get() == reaction) {
            reactionPanel.setVisible(false);
            reactionPanel.setManaged(false);
            return;
        }

        try {
            MessagePayloadProcessing.setMessageIDreaction(messageID, reaction);
        } catch (Exception e) {
            e.printStackTrace();
        }

        payloadBlockingQueue.add(new payloadMessageReaction(Owner.nameId, mainSceneController.name, messageID, reaction));

        Runnable uiUpdate = () -> {
            reactionImage.setImage(tempImage);
            currentMessage.reaction_type.set(reaction);
            reactionPanel.setVisible(false);
            reactionPanel.setManaged(false);
        };

        if (Platform.isFxApplicationThread()) {
            uiUpdate.run();
        } else {
            Platform.runLater(uiUpdate);
        }
    }
}
