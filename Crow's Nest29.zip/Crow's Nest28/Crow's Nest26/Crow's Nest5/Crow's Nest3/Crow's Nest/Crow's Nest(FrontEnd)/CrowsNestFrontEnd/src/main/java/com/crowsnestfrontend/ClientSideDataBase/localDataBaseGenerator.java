package com.crowsnestfrontend.ClientSideDataBase;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.User;

import java.io.InputStream;
import java.sql.*;

public class localDataBaseGenerator{
    public static final String dbmsConnectionString = "jdbc:sqlite:clientData.db";

    public static void initialize_database() {
        try (Connection conn = DriverManager.getConnection(dbmsConnectionString)) {
            if (conn != null) {
                System.out.println("Database connection successful");

                try (Statement stmt = conn.createStatement()) {
                    stmt.execute("""
                        CREATE TABLE IF NOT EXISTS owner_personal_data(
                            name_id TEXT NOT NULL PRIMARY KEY,
                            password TEXT NOT NULL,
                            image_bytes BLOB
                        );
                        """);

                    stmt.execute("""
                        CREATE TABLE IF NOT EXISTS Contacts(
                            name_id TEXT NOT NULL PRIMARY KEY,
                            is_friend INTEGER NOT NULL DEFAULT 0,
                            image BLOB,
                            timeSent DATETIME DEFAULT CURRENT_TIMESTAMP
                        );
                        """);

                    stmt.execute("""
                        CREATE TABLE IF NOT EXISTS Messages(
                            owner INTEGER DEFAULT 0,
                            sender TEXT NOT NULL,
                            receiver TEXT NOT NULL,
                            isSeen INTEGER NOT NULL DEFAULT 0,
                            text TEXT NOT NULL,
                            TextMessageID INTEGER NOT NULL Unique,
                            reaction INT DEFAULT 0,
                            isReplying INTEGER DEFAULT 0,
                            isReplyingToID INTEGER,
                            getTime DATETIME DEFAULT CURRENT_TIMESTAMP,
                            FOREIGN KEY (sender) REFERENCES Contacts(name_id),
                            FOREIGN KEY (receiver) REFERENCES Contacts(name_id)
                        );
                        """);

                    stmt.execute("""
                        CREATE INDEX IF NOT EXISTS Messages_finder ON Messages(sender);
                        CREATE INDEX IF NOT EXISTS MessageFinder  ON  Messages(receiver);
                        """);

                    System.out.println("All tables initialized");
                }

                if (Owner.image == null || Owner.image.length == 0) {
                    try (InputStream stream = MainApplication.class.getResourceAsStream("images/user.png")) {
                        if (stream != null) {
                            Owner.image = stream.readAllBytes();
                        } else {
                            throw new IllegalStateException("Resource not found: images/user.png");
                        }
                    }
                }

                String insertQuery = """
                    INSERT OR REPLACE INTO owner_personal_data(name_id, password,image_bytes) VALUES(?,?, ?) ;
                    """;

                try (PreparedStatement ps = conn.prepareStatement(insertQuery)) {
                    ps.setString(1, Owner.nameId);
                    ps.setString(2, Owner.password);
                    ps.setBytes(3 ,Owner.image);
                    ps.executeUpdate();
                    System.out.println("Inserted into owner_personal_data successfully");
                } catch (SQLException e) {
                    System.out.println("Failed to insert into owner_personal_data");
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLite exception: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Initialization error");
            e.printStackTrace();
        }
    }

    public static String lastUserInsertionDate(){
        String selectionStatement= """
                SELECT MAX(timeSent) FROM Contacts;
                """;
        String s="";
        try(Connection conn=DriverManager.getConnection(dbmsConnectionString);
            PreparedStatement ps = conn.prepareStatement(selectionStatement)){

            ResultSet rs=ps.executeQuery();
            rs.next();

            s=rs.getString(1);
            if(s==null){
                s="";
            }

            System.out.println("this is the last time stamp ---->"+s);
        }catch(SQLException e){
            e.printStackTrace();
        }

        return s;
    }

    public static String lastInsertedMessageDate(){
        String selectionStatement= """
                SELECT MAX(getTime) FROM Messages;
                """;
        String s="";
        try(Connection conn=DriverManager.getConnection(dbmsConnectionString);
            PreparedStatement ps = conn.prepareStatement(selectionStatement)){

            ResultSet rs=ps.executeQuery();
            rs.next();

            s=rs.getString(1);
            if(s==null){
                s="";
            }
        }catch(SQLException e){
            e.printStackTrace();
        }

        return s;
    }

    public static void loadUserDataFromLocalDatabase(){
        String ss= """
               SELECT * FROM Contacts;
                """;
        try(Connection conn = DriverManager.getConnection(dbmsConnectionString) ;
            PreparedStatement ps = conn.prepareStatement(ss)){

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                User newUser = new User();

                newUser.name=(rs.getString("name_id"));
                newUser.imageURL=rs.getBytes("image");

                SceneManager.mainSceneContrller.addUser(newUser);
                Owner.current.put(newUser.name, newUser);

                newUser.setIsFriend(rs.getInt("is_friend"));
            }

        }catch (Exception e){

        }
    }

    public static void makeBlock(String name ){
        String ss= """
                DELETE FROM Contacts WHERE name_id=?;
                """;
        try(Connection conn= DriverManager.getConnection(dbmsConnectionString) ;
            PreparedStatement ps =conn.prepareStatement(ss)){

            ps.setString(1 , name);
            ps.executeUpdate();

        }catch (SQLException e){
        }
    }
    public static void initializeUserDataFromTheClientDatabase(){
        String getUserInformationQuery= """
                SELECT * FROM owner_personal_data;
                """;

        try(Connection conn = DriverManager.getConnection(localDataBaseGenerator.dbmsConnectionString);
            PreparedStatement ps = conn.prepareStatement(getUserInformationQuery)
        ){
            ResultSet rs = ps.executeQuery();
            rs.next();
            Owner.nameId=rs.getString("name_id");
            Owner.password=rs.getString("password");
            Owner.image=rs.getBytes("image_bytes");


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
