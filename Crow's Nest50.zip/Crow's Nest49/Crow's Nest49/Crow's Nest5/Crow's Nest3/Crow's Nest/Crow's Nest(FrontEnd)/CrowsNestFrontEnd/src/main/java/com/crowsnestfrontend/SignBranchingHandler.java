package com.crowsnestfrontend;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.concurrent.CountDownLatch;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.MessageGetterRequest;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.SerializedClasses.signInProfileWithTimeStamp;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.Utility.SyncManager;
import javafx.application.Platform;
import javafx.scene.image.Image;

import static com.crowsnestfrontend.UserStream.constantStream.streamGetter;

public class SignBranchingHandler {


    public static void signBranchLogicHandler() throws IOException {

        String clientSideDatabaseFilePath="clientData.db";
        File file = new File(clientSideDatabaseFilePath);

        if (file.isFile() && file.canRead()) {
            localDataBaseGenerator.initializeUserDataFromTheClientDatabase();
            Thread.startVirtualThread(()->{
                String urlString = "http://localhost:8080/signIn/?"+Owner.nameId;
                URL url = null;
                try {
                    url = new URL(urlString);
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
                HttpURLConnection conn = null;
                try {
                    conn = (HttpURLConnection) url.openConnection();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                try {
                    conn.setRequestMethod("GET");
                } catch (ProtocolException e) {
                    throw new RuntimeException(e);
                }
                int responseCode = 0;
                try {
                    responseCode = conn.getResponseCode();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("Response Code: " + responseCode);

                BufferedReader in = null;
                try {
                    in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                String inputLine;
                StringBuilder response = new StringBuilder();

                while (true) {
                    try {
                        if (!((inputLine = in.readLine()) != null)) break;
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    response.append(inputLine);
                }
                try {
                    in.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                System.out.println("Response: " + response.toString());
            });

            Platform.runLater(()->{
                SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.profileImageView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.usernameLabel.setText(Owner.nameId);
            });

            SceneManager.globalStage.setScene(SceneManager.mainScene);
            SyncManager.allLoadingLatch.countDown();
            SceneManager.signUpScene=null;

            Thread.startVirtualThread(()->{
                try{
                    SyncManager.allLoadingLatch.await();

                    String userMessageInsertTime= localDataBaseGenerator.lastInsertedMessageDate();
                    streamGetter(new SignInProfile(Owner.nameId, Owner.password)) ;

                    constantStream.payloadBlockingQueue.add(new MessageGetterRequest(Owner.nameId,Owner.nameId , userMessageInsertTime));

                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }

            });
        }
        else {
            SceneManager.globalStage.setScene(SceneManager.signUpScene);
            SceneManager.globalStage.centerOnScreen();

            Thread.startVirtualThread(()->{
                SyncManager.signUploading=new CountDownLatch(1);

                try{
                    SyncManager.signUploading.await();
                    Platform.runLater((()->{
                        SceneManager.globalStage.setScene(SceneManager.mainScene);
                        SceneManager.signUpScene=null;

                    }));
                }catch (Exception e){
                    System.out.println(e.getMessage());
                }

                SyncManager.allLoadingLatch.countDown();
                Thread.startVirtualThread(()->{

                    try {
                        SyncManager.allLoadingLatch.await();

                        streamGetter(new SignInProfile(Owner.nameId, Owner.password)) ;
                        constantStream.payloadBlockingQueue.add(new MessageGetterRequest(Owner.nameId,Owner.nameId ,"-4713-11-24 00:00:00"));

                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                });
            });

        }

    }
}