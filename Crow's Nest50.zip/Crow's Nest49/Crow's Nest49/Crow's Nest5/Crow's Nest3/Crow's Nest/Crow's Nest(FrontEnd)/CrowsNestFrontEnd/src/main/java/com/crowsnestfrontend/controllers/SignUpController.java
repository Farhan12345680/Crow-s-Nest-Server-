package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.*;
import com.crowsnestfrontend.User.Owner;

import com.crowsnestfrontend.Utility.SyncManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.event.ActionEvent;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;




public class SignUpController implements Initializable {

    @FXML
    public VBox containerVBox;
    @FXML
    private TextField signup1;

    @FXML
    private PasswordField signup2;

    @FXML
    private Button sign_in;

    @FXML
    private Button Signup;

    @FXML
    private Text text;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        text.setText("");


        signup1.textProperty().addListener((e) -> {
            Platform.runLater(()->{
                text.setText("");
            });
        });
        signup2.textProperty().addListener((c)-> {
            {
                Platform.runLater(()->{
                    text.setText("");
                });
            }
        });
        sign_in.setOnAction(this::onSignIn);
        Signup.setOnAction(this::onSignUp);

    }


    @FXML
    private void onSignIn(ActionEvent event) {
        System.out.println("sign in");
        String name = signup1.getText().trim();
        String pass = signup2.getText().trim();

        if (name.isEmpty() || pass.isEmpty()) {
            Platform.runLater(()->{
                text.setText("Please enter both name and password.");

            });
            return;
        }

        if(name.length() >10 ||pass.length()>10){
            Platform.runLater(()->{
                text.setText("The input length has to be less than or equal to 10");

            });
            return;
        }


        Thread.startVirtualThread(() -> {
            try (Socket clientSocket=new Socket("localhost", 12345);
                 ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                 ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
) {

                out.writeObject(new ClientRequest(0));
                out.writeObject(new SignInProfile(name ,pass));

                returnQuery statusObject=(returnQuery) in.readObject();


                int status = (statusObject.getStatus());
                String message = statusObject.getMessage();


                byte[] imageBytes = statusObject.getImageBytes();

                if (status == -1) {
                    Platform.runLater(() -> text.setText(message));
                    return;
                }
                Owner.nameId = name;
                Owner.image = imageBytes;
                Owner.password=pass;

                localDataBaseGenerator.initialize_database();

            } catch (Exception e) {
                Platform.runLater(() -> text.setText("Login failed: " + e.getMessage()));
            }
            SyncManager.signUploading.countDown();

            Platform.runLater(()->{
                SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.profileImageView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.usernameLabel.setText(Owner.nameId);
                SceneManager.globalStage.centerOnScreen();

            });

        });

    }

    @FXML
    private void onSignUp(ActionEvent event) {
        System.out.println("sign up");

        String name = signup1.getText().trim();
        String pass = signup2.getText().trim();
        if (name.isEmpty() || pass.isEmpty()) {
            Platform.runLater(()->{
                text.setText("Please enter both name and password.\nDon't Use WhiteSpace");

            });
            return;
        }
        if(name.length() >10 ||pass.length()>10){
            Platform.runLater(()->{
                signup1.setText("");
                signup2.setText("");
                System.out.println("The input length has to be less than or equal to 10");

            });
            return;
        }

        Thread.startVirtualThread(() -> {

            int status = 0;
            String message = null;
            int length=0;

            Owner.image=new byte[length];

            try(    Socket clientSocket=new Socket("localhost",12345);
                    ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                    ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
){

                out.writeObject(new ClientRequest(1));
                out.writeObject(new SignUpProfile(name,pass,new byte[0] ));

                returnQuery statusObject=(returnQuery) in.readObject();

                status = (statusObject.getStatus());
                message = statusObject.getMessage();


                if(status==-1){
                    String finalMessage = message;
                    Platform.runLater(()->{
//                        signup1.setText("");
//                        signup2.setText("");
                        text.setText(finalMessage);

                    });

                    return;
                }
                Owner.nameId= name;
                Owner.password=pass;
                localDataBaseGenerator.initialize_database();
                out.writeObject(new ImageChanger(Owner.nameId, Owner.image));
                Platform.runLater(()->{
                    SceneManager.globalStage.setScene(SceneManager.loadingScene);
                });

                SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(new ByteArrayInputStream(Owner.image)));

            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            SyncManager.signUploading.countDown();

            Platform.runLater(()->{

                SceneManager.mainSceneContrller.Personal_image_id.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.profileImageView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
                SceneManager.profileController.usernameLabel.setText(Owner.nameId);
                SceneManager.globalStage.centerOnScreen();

            });
        });

    }




}



