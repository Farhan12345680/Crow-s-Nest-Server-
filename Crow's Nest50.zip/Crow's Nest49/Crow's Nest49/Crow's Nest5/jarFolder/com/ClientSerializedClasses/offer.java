package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class offer implements Serializable {

    @Serial
    private static final long serialVersionUID=1703L;
    public String name;
    public byte[] image;

    public offer(String name , byte[] image){
        this.name=name;
        this.image=image;
    }
}
