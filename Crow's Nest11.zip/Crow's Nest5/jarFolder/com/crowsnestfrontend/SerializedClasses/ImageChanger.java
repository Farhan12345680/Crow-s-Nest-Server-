package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class ImageChanger implements Serializable {
    @Serial
    public static final long serialVersionUID=10L;

    private final String name;
    private final byte[] imageByte;

    public ImageChanger(String name, byte[] imageByte) {
        this.name = name;
        this.imageByte = imageByte;
    }

    public String getName() {
        return name;
    }

    public byte[] getImageByte() {
        return imageByte;
    }
}
