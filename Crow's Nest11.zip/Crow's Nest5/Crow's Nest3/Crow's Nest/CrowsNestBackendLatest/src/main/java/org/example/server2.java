package org.example;

import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.SerializedClasses.payloadPackage.payload;
import org.example.DatabaseCreation.getAllUserDataFrom;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

public class server2 {
    public static int PORT=12346;
    public static ConcurrentHashMap<String ,BlockingQueue<payload> >payloadBlockingQueue=new ConcurrentHashMap<>() ;
    //public static BlockingQueue<payload> payloadBlockingQueue =new LinkedBlockingQueue<>();

    public static void main(String[] args){

        try{
            ServerSocket sc=new ServerSocket(  PORT);
            System.out.println("Server listening on port " + PORT);

            while (true) {
                System.out.println("this call");
                Socket client=sc.accept();
                Thread.startVirtualThread(() -> {
                    server2.handlePayloadClient(client);
                });
            }
        }catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
    public static void handlePayloadClient(Socket client) {
        ObjectOutputStream writer = null;
        ObjectInputStream reader = null;

        try {
            writer = new ObjectOutputStream(client.getOutputStream());
            reader = new ObjectInputStream(client.getInputStream());

            SignInProfile nameObject = (SignInProfile) reader.readObject();
            String name = nameObject.getName();

            payloadBlockingQueue.putIfAbsent(name, new LinkedBlockingQueue<>());

            getAllUserDataFrom.getUsers(name);

            ObjectOutputStream finalWriter = writer;
            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        payload obj = payloadBlockingQueue.get(name).take();
                        finalWriter.writeObject(obj);
                        finalWriter.flush();
                        System.out.println("Sent payload to " + name);
                    }
                } catch (IOException | InterruptedException e) {
                    System.err.println("Connection to " + name + " lost: " + e.getMessage());
                    try {
                        client.close(); // Cleanup
                    } catch (IOException ignored) {}
                }
            });

            while (!client.isClosed()) {
                Thread.sleep(1000);
            }

        } catch (IOException | ClassNotFoundException | InterruptedException e) {
            System.err.println("Client handler error: " + e.getMessage());
            e.printStackTrace();
            try {
                client.close();
            } catch (IOException ignored) {}
        }
    }


}
