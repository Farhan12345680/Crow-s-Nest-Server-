package org.example.DatabaseCreation;

import java.io.*;
import java.sql.*;
import java.util.concurrent.BlockingQueue;

import com.crowsnestfrontend.SerializedClasses.payloadPackage.payLoadUsers;
import com.crowsnestfrontend.SerializedClasses.RequestUsers;
import com.crowsnestfrontend.SerializedClasses.payloadPackage.payload;
import org.example.server2;

public class getAllUserDataFrom {

    public static void getUsers(String userName) {
        String getUserString = """
            SELECT name_id, image 
            FROM Profiles 
            WHERE name_id NOT IN (
                SELECT name_id_receiver FROM blockedUsers WHERE name_id_sender = ?
            );
        """;

        try (Connection conn = DriverManager.getConnection(DatabaseCreation.URL);
             PreparedStatement ps = conn.prepareStatement(getUserString)) {

            ps.setString(1, userName);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String targetUser = rs.getString(1);
                byte[] image = rs.getBytes(2);

                if (targetUser == null || targetUser.equals(userName)) continue;

                server2.payloadBlockingQueue.get(userName)
                        .add(new payLoadUsers(userName, new RequestUsers(targetUser, image)));
                System.out.println(server2.payloadBlockingQueue.get(userName).size());


            }


        } catch (SQLException e) {
            System.err.println("DB error while getting users for: " + userName);
            e.printStackTrace();
        }
    }
}
