package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.ByteArrayInputStream;
import java.util.Objects;

public class UserBubbleController {
    public String[] imageURL=new String[3];
    public int curr=0;
    public VBox parentBox=null;
    @FXML public ImageView userProfileImage;
    @FXML public Text userName;
    @FXML public ImageView addFriend;
    @FXML public ImageView blockuser;
    public Pane userBubblePane;

    @FXML
    public void initialize(){
        imageURL[0]="images/add-friend.png";
        imageURL[1]="images/pending.png";
        imageURL[2]="images/add-group.png";

        if(addFriend!=null){
            addFriend.setOnMouseClicked(this::addFriendClicker);

        }
        if(blockuser!=null){
            blockuser.setOnMouseClicked(this::blockUserCall);
        }

    }
    @FXML
    public void setText(String msg) {userName.setText(msg);}

    @FXML
    public void setUser(byte[] userImage) {
        userProfileImage.setImage(new Image(new ByteArrayInputStream(userImage)));
    };
    @FXML
    public void addFriendClicker(MouseEvent event){
        System.out.println("called");
        addFriend.setImage(new Image(
                Objects.requireNonNull(MainApplication.class.getResourceAsStream(imageURL[curr^1] ))));
        this.curr^=1;
    }

    public void blockUserCall(MouseEvent event) {
        System.out.println("Remove request");

        Node source = (Node) event.getSource();
        Node bubble = source.getParent();
        VBox parent = (VBox) bubble.getParent();

        parent.getChildren().remove(bubble);
    }

    public void set(VBox node1){
        this.parentBox=node1;

    }

    @FXML
    public void setImage(byte[] imageBytes){
        Platform.runLater(()->{
            userProfileImage.setImage(new Image(new ByteArrayInputStream(imageBytes)));

        });
    }

    public void setFriendState(int index){
        addFriend.setImage(new Image(
                Objects.requireNonNull(MainApplication.class.getResourceAsStream(imageURL[index] ))));
    }

    @FXML
    public void onBubbleClicked(MouseEvent event){
        System.out.println("called");
        Platform.runLater(()->{
            SceneManager.mainSceneContrller.user_icon.setImage(userProfileImage.getImage());
            SceneManager.mainSceneContrller.FriendUserName.setText(userName.getText());
        });
    }

}
