package com.crowsnestfrontend.User;

import com.crowsnestfrontend.SerializedClasses.RequestUsers;
import com.crowsnestfrontend.UserFloatingButton.NewUserBubble;

import java.util.concurrent.ConcurrentHashMap;

public class Owner {
    public static ConcurrentHashMap<String , NewUserBubble> friends=new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String ,NewUserBubble> current=new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String , NewUserBubble>friendRequest =new ConcurrentHashMap<>();


    public static String  nameId;
    public static byte[] image=null;

}
