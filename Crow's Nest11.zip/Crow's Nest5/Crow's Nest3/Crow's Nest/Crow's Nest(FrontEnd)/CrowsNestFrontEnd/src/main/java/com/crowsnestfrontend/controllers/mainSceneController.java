package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class mainSceneController {


    @FXML public ScrollPane scrollPane;
    @FXML public VBox allPeople;
    @FXML public VBox friends;
    @FXML public ScrollPane RequestsScroller;
    @FXML public VBox friendRequest;
    @FXML public ScrollPane requestScrollPanel;
    @FXML public ScrollPane peopleScrollPanel;
    @FXML public ScrollPane friendsScrollPanel;
    @FXML public VBox OwnerMessage;
    @FXML public VBox friendMessage;
    @FXML public Text FriendUserName;

    @FXML private Label Title_Shower;          // fx:id="Title_Shower"

    // Left panel image view
    @FXML public ImageView Personal_image_id;

    // Left panel buttons
    @FXML private Button people_button;        // fx:id="people_button"
    @FXML private Button friends_button;       // fx:id="friends_button"
    @FXML private Button requests_button;      // fx:id="requests_button"
    @FXML private Button cross_button;         // fx:id="cross_button"

    // Search icon
    @FXML private ImageView search_icon;       // fx:id="search_icon"

    // Header action image and buttons
    @FXML public ImageView user_icon;         // fx:id="user_icon"
    @FXML public Button Message;              // fx:id="Message"
    @FXML public Button Call;                 // fx:id="Call"
    @FXML public Button Video_Call;           // fx:id="Video_Call"

    // Writing icon and send button
    @FXML private ImageView writingImage;      // fx:id="writingImage"
    @FXML private Button send_button;          // fx:id="send_button"


    public TextField searchPeople;
    public ImageView clearSearchPeople;
    public TextField writeTextField;
    public Button sendTextMessage;

    @FXML
    public void profileImageSetter(Image newImage){
        this.Personal_image_id.setImage(newImage);
    }

    @FXML
    public void initialize() {
        System.out.println("initialized");

            if(Title_Shower!=null){
                Title_Shower.setText("Crow's Nest");
            }
            if(Personal_image_id!=null){
                Personal_image_id.setOnMouseClicked(this::gg);

            }

            if(scrollPane!=null){
                scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
            }


        //input field clearing
        if(clearSearchPeople!=null){
            clearSearchPeople.setOnMouseClicked(this::clearSearch);
        }
        if(sendTextMessage!=null){
            sendTextMessage.setOnMouseClicked(this::textSender);

        }

        //buttonClicksToShowVBOX

            System.out.println("Called");
            if(people_button!=null){
                people_button.setOnMouseClicked(this::peopleShower);
            }

            if(friends_button!=null){
                friends_button.setOnMouseClicked(this::friendShower);
            }
            if(requests_button!=null){
                requests_button.setOnMouseClicked(this::requestShower);

            }
            if(friendRequest!=null){
                friendRequest.setManaged(false);
                friendRequest.setVisible(false);
            }
            if(friends!=null){

                friends.setVisible(false);
                friends.setManaged(false);
            }
            if(allPeople!=null){


                allPeople.setVisible(true);
                allPeople.setManaged(true);
            }

             requestScrollPanel.setVisible(false);
            requestScrollPanel.setManaged(false);
            friendsScrollPanel.setManaged(false);
            friendsScrollPanel.setVisible(false);
        //public ScrollPane friendsScrollPanel;

        searchPeople.textProperty().addListener((observable, oldValue, newValue) -> {
            System.out.println("listener is firing");

            for (var pair : Owner.current.entrySet()) {
                boolean match = pair.getKey().toLowerCase().contains(newValue.toLowerCase());

                pair.getValue().bubbleUi.setVisible(match);
                pair.getValue().bubbleUi.setManaged(match);
//                if (match) {
//                    pair.getValue().setStyle("-fx-opacity: 1;");
//                } else {
//                    pair.getValue().setStyle("-fx-opacity: 0.3; -fx-background-color: red;");
//                }
            }
            VBox node1=(VBox) SceneManager.mainScene.getRoot().lookup("#allPeople");
            System.out.println("node1 children: " + node1.getChildren().size());

            node1.requestLayout();

        });


    }

    private void requestShower(MouseEvent event) {
        friendRequest.setManaged(true);
        friendRequest.setVisible(true);
        System.out.println("Request called");
        friends.setVisible(false);
        friends.setManaged(false);

        allPeople.setVisible(false);
        allPeople.setManaged(false);

        peopleScrollPanel.setVisible(false);
        peopleScrollPanel.setManaged(false);
        requestScrollPanel.setVisible(true);
        requestScrollPanel.setManaged(true);
        friendsScrollPanel.setManaged(false);
        friendsScrollPanel.setVisible(false);
    }

    private void friendShower(MouseEvent event) {
        friendRequest.setManaged(false);
        friendRequest.setVisible(false);

        friends.setVisible(true);
        friends.setManaged(true);

        allPeople.setVisible(false);
        allPeople.setManaged(false);

        peopleScrollPanel.setVisible(false);
        peopleScrollPanel.setManaged(false);
        requestScrollPanel.setVisible(false);
        requestScrollPanel.setManaged(false);
        friendsScrollPanel.setManaged(true);
        friendsScrollPanel.setVisible(true);
    }

    private void peopleShower(MouseEvent event) {
        friendRequest.setManaged(false);
        friendRequest.setVisible(false);

        friends.setVisible(false);
        friends.setManaged(false);

        allPeople.setVisible(true);
        allPeople.setManaged(true);

        peopleScrollPanel.setVisible(true);
        peopleScrollPanel.setManaged(true);
        requestScrollPanel.setVisible(false);
        requestScrollPanel.setManaged(false);
        friendsScrollPanel.setManaged(false);
        friendsScrollPanel.setVisible(false);
    }

    private void textSender(MouseEvent event) {
        writeTextField.setText("");
    }

    private void clearSearch(MouseEvent event) {
        searchPeople.setText("");
    }

    @FXML
    private void gg(MouseEvent event) {
//        System.out.println("Personal image clicked");
        SceneManager.globalStage.setScene(SceneManager.profileScene);
        SceneManager.globalStage.centerOnScreen();
    }

    @FXML
    private void onSendButtonClicked() {
    }

    @FXML
    private void onPeopleClicked() {
    }

    @FXML
    private void onFriendsClicked() {
    }

    @FXML
    private void onRequestsClicked() {
    }

    @FXML
    private void onCrossClicked() {
    }

    @FXML
    private void onMessageClicked() {
    }

    @FXML
    private void onCallClicked() {
    }

    @FXML
    private void onVideoCallClicked() {
    }
}
