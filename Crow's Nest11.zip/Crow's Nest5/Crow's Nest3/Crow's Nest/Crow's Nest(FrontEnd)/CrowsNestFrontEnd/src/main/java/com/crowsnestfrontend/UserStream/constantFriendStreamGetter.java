package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.*;
import com.crowsnestfrontend.SerializedClasses.payloadPackage.payloadFriends;
import com.crowsnestfrontend.User.Owner;
import javafx.application.Platform;
import javafx.scene.layout.VBox;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class constantFriendStreamGetter {

    public static void streamCaller(payloadFriends obj)  {
        VBox node1=(VBox) SceneManager.mainScene.getRoot().lookup("#friends");

        Thread.startVirtualThread(()->{

            while (node1 == null) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }

                        RequestFriend req= obj.getFriends();

                        if(Owner.current.containsKey(req.getFriName())){
                            if(Owner.friends.containsKey(req.getFriName())){

                            }else{
                                Platform.runLater(() -> {
                                    var stateImage=Owner.current.get(req.getFriName());
                                    stateImage.setImage(2);
                                  node1.getChildren().add(
                                       stateImage
                                  );
                                Owner.friends.put(req.getFriName(),stateImage);
                                });
                            }
                        }

                    });

            }



    }

