package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.RequestUsers;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.SerializedClasses.payloadPackage.payLoadUsers;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserFloatingButton.NewUserBubble;
import com.crowsnestfrontend.SerializedClasses.returnQuery;

import javafx.application.Platform;
import javafx.scene.layout.VBox;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.*;

public class constantUserStreamGetter {


    public static void streamCaller(payLoadUsers users) {
        VBox  node1 = (VBox) SceneManager.mainScene.getRoot().lookup("#allPeople");


            Thread.startVirtualThread(()->{
//                while (node1 == null) {
//                    try {
//                        Thread.sleep(1000);
//                    } catch (InterruptedException e) {
//                        Thread.currentThread().interrupt();
//                        return;
//                    }
//                }

                RequestUsers req = users.getRequestUser();
                System.out.println("userName");

                if (!Owner.current.containsKey(req.getUserName())) {
                    String userName = req.getUserName();
                    byte[] profilePic = req.getProfilePicture();
                    System.out.println("userName");

                        NewUserBubble newUserBubble = new NewUserBubble(userName, profilePic);
//                        node1.getChildren().add(newUserBubble);
                        newUserBubble.attachTo(node1);
                        Owner.current.put(userName, newUserBubble);
                }});

                    }


        }

