package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.SerializedClasses.payloadPackage.*;
import com.crowsnestfrontend.User.Owner;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class constantStream {

    public static BlockingQueue<payload> payloadBlockingQueue = new LinkedBlockingQueue<>();

    public static void streamGetter() {
        try {
            Socket socket = new Socket("localhost", 12346);
            ObjectOutputStream writer = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream reader = new ObjectInputStream(socket.getInputStream());

            writer.writeObject(new SignInProfile(Owner.nameId, " "));

            System.out.println("Came here");
            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        Object obj = reader.readObject();
                        if (obj instanceof payload) {
                            payloadBlockingQueue.add((payload) obj);
                        } else {
                            System.err.println("Received unknown object: " + obj.getClass());
                        }
                    }
                } catch (EOFException e) {
                    System.err.println("Server closed connection.");
                } catch (IOException | ClassNotFoundException e) {
                    System.err.println("Error reading from server: " + e.getMessage());
                    e.printStackTrace();
                }
            });

            // Processor thread
            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        payload obj = payloadBlockingQueue.take();

                        if (obj instanceof payLoadUsers users) {
                            constantUserStreamGetter.streamCaller(users);
                        } else if (obj instanceof payloadFriends friends) {
                            constantFriendStreamGetter.streamCaller(friends);
                        } else if (obj instanceof payloadFriendRequest request) {
                            constantFriendRequestStream.streamCaller(request);
                        } else {
                            System.err.println("Unhandled payload type: " + obj.getClass());
                        }
                        System.out.println("took");
                    }
                } catch (InterruptedException e) {
                    System.err.println("Processor thread interrupted.");
                    Thread.currentThread().interrupt();
                }
            });

        } catch (IOException e) {
            System.err.println("Failed to connect to server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
