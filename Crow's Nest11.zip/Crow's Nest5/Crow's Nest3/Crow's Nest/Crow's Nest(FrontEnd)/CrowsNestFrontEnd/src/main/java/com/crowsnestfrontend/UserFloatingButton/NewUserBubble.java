package com.crowsnestfrontend.UserFloatingButton;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.controllers.UserBubbleController;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class NewUserBubble {
    public UserBubbleController ctrl;
    public Parent bubbleUi;

    public NewUserBubble(String text, byte[] array) {
        FXMLLoader loader = new FXMLLoader(
                MainApplication.class.getResource("UserBubble.fxml")
        );

        try {
            this.bubbleUi = loader.load();
            VBox.setMargin(bubbleUi, new Insets(0, 0, 2, 8));
            this.ctrl = loader.getController();
            this.ctrl.setText(text);
            this.ctrl.setImage(array);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void attachTo(VBox box) {
        if (box == null) throw new IllegalArgumentException("Target VBox is null");
        ctrl.set(box);
        box.getChildren().add(bubbleUi);
    }

    public void setImage(int index){
        ctrl.setFriendState(index);
    }
}
