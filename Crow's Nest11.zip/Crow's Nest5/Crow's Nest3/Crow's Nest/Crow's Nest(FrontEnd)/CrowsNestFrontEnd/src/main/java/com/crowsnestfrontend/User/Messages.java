package com.crowsnestfrontend.User;

public class Messages {
    public int reaction_type=0;
    public int is_seen;
    public String text;
    public int direction;
    public Messages(String text ,int is_seen ,int reaction_type ,int direction){
        this.text=text;
        this.is_seen=is_seen;
        this.reaction_type=reaction_type;
        this.direction=direction;
    }

}
