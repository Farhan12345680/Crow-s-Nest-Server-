package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class CallOffer extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID = 700L;

    public String callerId;
    public String sdpOffer;

    public CallOffer(String callerId, String sdpOffer) {
        super("");
        this.callerId = callerId;
        this.sdpOffer = sdpOffer;
    }
}
