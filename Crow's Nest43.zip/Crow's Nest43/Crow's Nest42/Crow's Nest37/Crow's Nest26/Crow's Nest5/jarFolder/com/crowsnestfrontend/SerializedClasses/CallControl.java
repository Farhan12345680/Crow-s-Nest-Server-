package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class CallControl extends payload implements Serializable {
    @Serial
    private static final long serialVersionUID = 146L;

    public String fromUserId;
    public String toUserId;
    public String action;

    public CallControl(String fromUserId, String toUserId, String action) {
        super("");
        this.fromUserId = fromUserId;
        this.toUserId = toUserId;
        this.action = action;
    }
}
