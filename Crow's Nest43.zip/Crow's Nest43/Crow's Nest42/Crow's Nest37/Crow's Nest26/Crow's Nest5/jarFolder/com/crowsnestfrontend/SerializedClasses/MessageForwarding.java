package com.crowsnestfrontend.SerializedClasses;
import java.io.Serial;
import java.io.Serializable;

public class MessageForwarding extends payload implements Serializable{
    @Serial
    private static final long serialVersionUID=92L;
    private final String sender;
    private final String text;
    private final int messageID;
    private final String dateTime;
    private final  boolean isReply;
    private final int replyingMessageID;

    public MessageForwarding(String clientName, String sender , String text , int messageID, String dateTime, boolean isReply, int replyingMessageID){
        super(clientName);
        this.sender=sender;
        this.text=text;
        this.messageID=messageID;
        this.dateTime = dateTime;
        this.isReply = isReply;
        this.replyingMessageID = replyingMessageID;
    }

    public String senderString(){
        return this.sender;
    }

    public String getText(){
        return this.text;
    }
    public int getMessageID(){
        return this.messageID;
    }
    public String getDateTime(){
        return dateTime;
    }

    public int getReplyingMessageID() {
        return replyingMessageID;
    }

    public boolean isReply() {
        return isReply;
    }
}