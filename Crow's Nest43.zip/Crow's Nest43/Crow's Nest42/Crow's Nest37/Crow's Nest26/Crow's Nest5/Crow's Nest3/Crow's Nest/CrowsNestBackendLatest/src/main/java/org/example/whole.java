package org.example;

import org.example.DatabaseCreation.DatabaseCreation;

import java.io.IOException;
import java.sql.SQLException;

public class whole {

    public static void main(String[] args) throws IOException, SQLException, InterruptedException {
        DatabaseCreation.main(null);

        Thread firstThread=Thread.startVirtualThread(()->{
            try {
                ServerCrowsNest.main(null);
            } catch (Exception e) {
                System.out.println("an error occurred Thread1");
            }
        });
        Thread secondThread=Thread.startVirtualThread(()->{
            try {
                server2.main(null);

            } catch (Exception e) {
                System.out.println("an error occurred Thread2");
            }


        });
        firstThread.join();
        secondThread.join();

    }
}
