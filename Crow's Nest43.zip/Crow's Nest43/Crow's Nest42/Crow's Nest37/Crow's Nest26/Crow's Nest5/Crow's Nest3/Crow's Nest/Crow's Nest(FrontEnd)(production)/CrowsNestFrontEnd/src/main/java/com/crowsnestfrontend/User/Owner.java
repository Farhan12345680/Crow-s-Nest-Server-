package com.crowsnestfrontend.User;

import com.crowsnestfrontend.SerializedClasses.RequestUsers;
import com.crowsnestfrontend.User.User;

import java.util.concurrent.ConcurrentHashMap;

public class Owner {
    public static ConcurrentHashMap<String , String> friends=new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String ,User> current=new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String , String>friendRequest =new ConcurrentHashMap<>();


    public static String  nameId;
    public static byte[] image=null;
    public static String password=null;
}
