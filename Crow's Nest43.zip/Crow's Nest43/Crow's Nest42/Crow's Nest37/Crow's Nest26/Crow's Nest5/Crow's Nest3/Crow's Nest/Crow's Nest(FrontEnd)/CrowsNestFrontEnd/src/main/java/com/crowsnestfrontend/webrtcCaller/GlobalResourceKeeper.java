package com.crowsnestfrontend.webrtcCaller;

import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.Utility.SyncManager;
import dev.onvoid.webrtc.PeerConnectionFactory;
import dev.onvoid.webrtc.RTCPeerConnection;
import dev.onvoid.webrtc.media.audio.AudioTrack;
import dev.onvoid.webrtc.media.video.VideoTrack;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import nu.pattern.OpenCV;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;

import java.io.ByteArrayInputStream;

public class GlobalResourceKeeper {
    private static GlobalResourceKeeper instance;

    public VideoCapture capture;

    public PeerConnectionFactory peerFactory;
    public RTCPeerConnection peerConnection;

    public AudioTrack localAudio;
    public VideoTrack localVideo;

    @FXML
    public ImageView otherView;
    @FXML
    public ImageView selfView;

    @FXML
    public Text ClientName;
    @FXML
    public Text UserName;

    @FXML
    public VBox voiceHolder;

    private WritableImage writableImage;
    private PixelWriter pixelWriter;

    private WritableImage remoteWritableImage;
    private PixelWriter remotePixelWriter;

    @FXML
    public VBox codeArea;
    private int state=0;

    public static synchronized GlobalResourceKeeper getInstance(){
        if(instance==null){
            instance = new GlobalResourceKeeper();
        }

        return instance;
    }
    private volatile boolean cameraActive = false;
    private Thread cameraThread;

    public synchronized  void selfCameraOnOff(){
        if(state==0){
            codeArea.setVisible(true);
            codeArea.setManaged(true);

            voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *30f/100);
        }
        else{
            codeArea.setVisible(false);
            codeArea.setManaged(false);
            voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        }
        state++;
        state%=2;
    }

    public synchronized void stopCamera() {
        cameraActive = false;

        if (cameraThread != null && cameraThread.isAlive()) {
            try {
                cameraThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            cameraThread = null;
        }

        if (capture != null) {
            if (capture.isOpened()) capture.release();
            capture = null;
        }

        Platform.runLater(() -> selfView.setImage(new Image(new ByteArrayInputStream(Owner.image))));
    }

    public synchronized void stopCameraPermanent() {
        this.stopCamera();
        GlobalResourceKeeper.instance=null;


        // it will do a lot of other things
        //such as tell the remote peer that the stream has ended

    }

    public synchronized void cycleCamera() {
        if (cameraActive) {
            stopCamera();
        } else {
            startCamera();
        }
    }

    public   synchronized void startCamera() {
        OpenCV.loadShared();
        capture = new VideoCapture(0, Videoio.CAP_ANY);
        System.out.println("is the loading thing working ");
        if (!capture.isOpened()) {
            selfView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
            return;
        }

        cameraActive = true;

        Mat frame = new Mat();
        Mat converted = new Mat();

        cameraThread = Thread.ofVirtual().start(() -> {
            byte[] buffer = null;
            WritableImage writableImage = null;
            PixelWriter pixelWriter = null;

            while (cameraActive) {
                if (!capture.read(frame) || frame.empty()) {
                    Platform.runLater(() -> selfView.setImage(new Image(new ByteArrayInputStream(Owner.image))));
                    break;
                }


                Imgproc.cvtColor(frame, converted, Imgproc.COLOR_BGR2BGRA);

                int width = converted.width();
                int height = converted.height();

                if (buffer == null || buffer.length != width * height * 4) {
                    buffer = new byte[width * height * 4];
                    writableImage = new WritableImage(width, height);
                    pixelWriter = writableImage.getPixelWriter();
                }

                converted.get(0, 0, buffer);

                WritableImage finalImage = writableImage;
                byte[] finalBuffer = buffer;
                PixelWriter finalPixelWriter = pixelWriter;
                Platform.runLater(() -> {
                    finalPixelWriter.setPixels(0, 0, width, height, PixelFormat.getByteBgraInstance(), finalBuffer, 0, width * 4);
                    selfView.setImage(finalImage);
                });

                try {
                    Thread.sleep(33);
                } catch (InterruptedException e) {
                    break;
                }
            }
        });
    }


}
