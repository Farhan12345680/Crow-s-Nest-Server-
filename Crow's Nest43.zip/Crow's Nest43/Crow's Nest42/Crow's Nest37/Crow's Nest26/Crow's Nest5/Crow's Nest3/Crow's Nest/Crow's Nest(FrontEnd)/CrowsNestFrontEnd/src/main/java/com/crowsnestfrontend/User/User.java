package com.crowsnestfrontend.User;

import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;


public class User {
    public String name;
    public byte[] imageURL;
    private final IntegerProperty isFriend = new SimpleIntegerProperty(0);
    private final IntegerProperty MessageCount=new SimpleIntegerProperty(0);

    public IntegerProperty isFriendProperty() {
        return isFriend;
    }

    public IntegerProperty MessageProperty(){

        return MessageCount;
    }

    public int getStatus() {
        return isFriend.get();
    }

    public void setIsFriend(int value) {
        isFriend.set(value);
    }

    public void UpMessageCount() {

        if (Platform.isFxApplicationThread()) {
            MessageCount.set(MessageCount.get() + 1);
        } else {
            Platform.runLater(() -> MessageCount.set(MessageCount.get() + 1));
        }
    }

    public void setIngerCountToZero(){
        if (Platform.isFxApplicationThread()) {
            MessageCount.set(0);
        } else {
            Platform.runLater(() -> MessageCount.set(MessageCount.get() + 1));
        }

    }
}
