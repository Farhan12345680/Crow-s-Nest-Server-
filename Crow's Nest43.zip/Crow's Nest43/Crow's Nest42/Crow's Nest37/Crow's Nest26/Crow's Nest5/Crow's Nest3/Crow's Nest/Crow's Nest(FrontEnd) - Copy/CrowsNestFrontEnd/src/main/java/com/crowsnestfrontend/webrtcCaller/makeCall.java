package com.crowsnestfrontend.webrtcCaller;

import dev.onvoid.webrtc.*;
import dev.onvoid.webrtc.media.MediaStreamTrack;
import dev.onvoid.webrtc.media.audio.*;
import dev.onvoid.webrtc.media.video.*;
import javafx.application.Platform;

import java.util.ArrayList;
import java.util.List;

public class makeCall {

    private PeerConnectionFactory factory;
    private RTCPeerConnection peerConnection;
    private AudioTrack localAudio;
    private VideoTrack localVideo;

    public makeCall(SignalingChannel signaling) { // <--- Pass a signaling channel
        factory = new PeerConnectionFactory();

        Platform.runLater(() -> {
            RTCConfiguration config = new RTCConfiguration();
            RTCIceServer iceServer = new RTCIceServer();
            iceServer.urls.add("stun:stun.l.google.com:19302");
            config.iceServers.add(iceServer);

            peerConnection = factory.createPeerConnection(config, new PeerConnectionObserver() {
                @Override
                public void onIceCandidate(RTCIceCandidate candidate) {
                    // Send candidate to remote
                    signaling.sendCandidate(candidate);
                }

                @Override
                public void onTrack(RTCRtpTransceiver transceiver) {
                    MediaStreamTrack track = transceiver.getReceiver().getTrack();
                    System.out.println("Caller received remote track: " + track.getKind());
                }
            });

            // Local media
            AudioOptions audioOptions = new AudioOptions();
            audioOptions.echoCancellation = true;
            localAudio = factory.createAudioTrack("audio0", factory.createAudioSource(audioOptions));

            VideoDeviceSource videoSource = new VideoDeviceSource();
            localVideo = factory.createVideoTrack("video0", videoSource);

            List<String> streamIds = new ArrayList<>();
            streamIds.add("stream1");
            peerConnection.addTrack(localAudio, streamIds);
            peerConnection.addTrack(localVideo, streamIds);

            // Create an offer
            RTCOfferOptions offerOptions = new RTCOfferOptions();
            peerConnection.createOffer(offerOptions, new CreateSessionDescriptionObserver() {
                @Override
                public void onSuccess(RTCSessionDescription desc) {
                    peerConnection.setLocalDescription(desc, new SetSessionDescriptionObserver() {
                        @Override
                        public void onSuccess() {
                            System.out.println("Caller local description set!");
                            signaling.sendOffer(desc); // <--- Send offer over signaling
                        }
                        @Override
                        public void onFailure(String error) {
                            System.out.println("Failed to set local desc: " + error);
                        }
                    });
                }

                @Override
                public void onFailure(String error) {
                    System.out.println("Offer failed: " + error);
                }
            });

            // Listen for answer from callee (via signaling)
            signaling.onAnswer(desc -> {
                peerConnection.setRemoteDescription(desc, new SetSessionDescriptionObserver() {
                    @Override
                    public void onSuccess() {
                        System.out.println("Caller remote description set (answer received).");
                    }
                    @Override
                    public void onFailure(String error) {
                        System.out.println("Failed to set remote desc: " + error);
                    }
                });
            });

            // Listen for remote ICE candidate
            signaling.onCandidate(candidate -> peerConnection.addIceCandidate(candidate));
        });
    }
}
