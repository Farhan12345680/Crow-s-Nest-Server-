package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class payloadFriends extends payload implements Serializable  {

    @Serial
    private static final long serialVersionUID= 17L;

    private final RequestFriend rs;

    public payloadFriends(String clientName, RequestFriend rs) {
        super(clientName);
        this.rs = rs;
    }



    public RequestFriend getFriends(){
        return rs;
    }

}
