package org.example.Messages;

import com.crowsnestfrontend.SerializedClasses.Message;
import com.crowsnestfrontend.SerializedClasses.MessagePayload;
import org.example.DatabaseCreation.DatabaseCreation;
import org.example.server2;

import java.sql.*;

public class MessageData {

    public static int makeMessage(String clientName, Message msg, int isSent) {
        String makeMessage = """
            INSERT INTO Messages(sender, receiver, content, isSent) VALUES (?, ?, ?, ?);
            """;

        try (Connection conn = DriverManager.getConnection(DatabaseCreation.URL);
             PreparedStatement ps = conn.prepareStatement(makeMessage, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, clientName);
            ps.setString(2, msg.name());
            ps.setString(3, msg.getText());
            ps.setInt(4, isSent);

            int affectedRows = ps.executeUpdate();

            if (affectedRows == 0) {
                System.out.println("Insert failed");
                return 0;
            }

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static String getDateTime(int id){
        String dateTime="";
        String select="SELECT time_sent from Messages WHERE id=?";

        try(Connection conn=DriverManager.getConnection(DatabaseCreation.URL);
            PreparedStatement ps=conn.prepareStatement(select)){

            ps.setInt(1,id);
            ResultSet rs=ps.executeQuery();
            while (rs.next()){
                return rs.getString(1);
            }
        }catch (SQLException e){

        }


        return dateTime;
    }

    public static void getAllMessage(String name){
        String selectString = """
                SELECT * FROM Messages WHERE receiver=? OR sender=?;
                """;
        String countString = """
                SELECT count(*) FROM Messages WHERE receiver=? OR sender=?;
                """;
        try(Connection conn=DriverManager.getConnection(DatabaseCreation.URL);
        PreparedStatement ps =conn.prepareStatement(selectString);
        PreparedStatement ps2=conn.prepareStatement(countString)
        ){
            ps.setString(1 , name);
            ps.setString(2,name);
            ResultSet rs=ps.executeQuery();

            ps2.setString(1,name);
            ps2.setString(2 ,name);
            ResultSet rs2=ps2.executeQuery();
            rs2.next();


            while(rs.next()){
                if(server2.payloadBlockingQueue.containsKey(name)){
                    MessagePayload payload=new MessagePayload(
                            rs.getString("sender"),
                            rs.getInt("id"),
                            rs.getString("content"),
                            rs.getInt("reaction"),
                            rs.getString("time_sent")+" UTC"
                    );
                    payload.sender=rs.getString("receiver");
                    server2.payloadBlockingQueue.get(name).add(payload);
                }

            }

        }catch (SQLException e){
            e.printStackTrace();
        }
    }
}
