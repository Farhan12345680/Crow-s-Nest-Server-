package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.RequestUsers;
import com.crowsnestfrontend.SerializedClasses.payLoadUsers;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.User;


public class constantUserStreamGetter {


    public static void streamCaller(payLoadUsers users) {


            Thread.startVirtualThread(()->{

                RequestUsers req = users.getRequestUser();

                if (!Owner.current.containsKey(req.getUserName())) {
                    User newUser = new User();

                    newUser.name=(req.getUserName());
                    newUser.imageURL=req.getProfilePicture();


                    SceneManager.mainSceneContrller.addUser(newUser);
                    Owner.current.put(newUser.name, newUser);

                }});

    }

}

