package com.crowsnestfrontend.Messages;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Message {
    public int reaction_type=0;
    public int is_seen;
    public String text;
    public boolean ownMessage;

    public String formattedTime ;

    public Message(String text ,boolean ownMessage ,String formattedTime){
        this.text=text;
        this.ownMessage = ownMessage;
        this.formattedTime=formattedTime;
    }

    public String getText() {
        return text;
    }

    public boolean isOwnMessage() {
        return ownMessage;
    }

}