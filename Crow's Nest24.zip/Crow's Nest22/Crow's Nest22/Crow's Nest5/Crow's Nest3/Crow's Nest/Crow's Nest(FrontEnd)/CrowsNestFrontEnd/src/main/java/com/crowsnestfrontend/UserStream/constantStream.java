package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.Messages.MessagePayloadProcessing;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.SignInProfile;
import com.crowsnestfrontend.SerializedClasses.*;
import com.crowsnestfrontend.User.Owner;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import javafx.application.Platform;

public class constantStream {

    public static BlockingQueue<payload> payloadBlockingQueue = new LinkedBlockingQueue<>();

    public static void streamGetter() {
        try {
            Socket socket = new Socket("localhost", 12346);
            ObjectOutputStream writer = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream reader = new ObjectInputStream(socket.getInputStream());


            synchronized (writer) {
                writer.writeObject(new SignInProfile(Owner.nameId, " "));
                writer.flush();
            }

            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        Object obj = reader.readObject();

                        if (obj instanceof payload) {
                            payloadBlockingQueue.add((payload) obj);
                        } else {
                            System.err.println("Received unknown object: " + obj.getClass());
                        }
                    }
                } catch (EOFException e) {
                    System.err.println("Server closed connection.");
                } catch (IOException | ClassNotFoundException e) {
                    System.err.println("Error reading from server: " + e.getMessage());
                    e.printStackTrace();
                }
            });

            Thread.startVirtualThread(() -> {
                try {
                    while (true) {
                        payload obj = payloadBlockingQueue.take();

                        switch (obj) {
                            case payLoadUsers users -> constantUserStreamGetter.streamCaller(users);
                            case MessagePayload messagePayload -> {
                                MessagePayloadProcessing.messageLoader(messagePayload);
                            }
                            case MessageGetterRequest _ -> {
                                synchronized (writer) {
                                    writer.writeObject(obj);
                                    writer.flush();
                                }
                            }
//                            case MessageForwarding _ -> Platform.runLater(() -> {
//                                SceneManager.mainSceneContrller.messageListView.getItems().add(
//                                        new com.crowsnestfrontend.Messages.Message(((MessageForwarding) obj).getText(), false)
//                                );
//                            });
                            case Unfriend uf -> {
                                synchronized (writer) {
                                    writer.writeObject(uf);
                                    writer.flush();
                                }
                            }
                            case updateStatus us -> UpdateStream.updater(us);
                            case payloadFriendRequest request -> constantFriendRequestStream.streamCaller(request);
                            case MakeFriendRequest mk -> {
                                synchronized (writer) {
                                    writer.writeObject(mk);
                                    writer.flush();
                                }
                            }
                            case deleteFriendRequest del -> {
                                synchronized (writer) {
                                    writer.writeObject(del);
                                    writer.flush();
                                }
                            }
                            case MakeFriendRequestAccept mk -> {
                                synchronized (writer) {
                                    writer.writeObject(mk);
                                    writer.flush();
                                }
                            }
                            case removeIncomingFriendRequest IFR -> {
                                synchronized (writer) {
                                    writer.writeObject(IFR);
                                    writer.flush();
                                }
                            }
                            case MakeBlock makeBlock -> {
                                synchronized (writer) {
                                    writer.writeObject(makeBlock);
                                    writer.flush();
                                }
                            }
                            case Message message -> {
                                synchronized (writer) {
                                    writer.writeObject(message);
                                    writer.flush();
                                }
                            }
                            default -> System.err.println("Unhandled payload type: " + obj.getClass());
                        }

                    }
                } catch (InterruptedException e) {
                    System.err.println("Processor thread interrupted.");
                    Thread.currentThread().interrupt();
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            });


        } catch (IOException e) {
            System.err.println("Failed to connect to server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
