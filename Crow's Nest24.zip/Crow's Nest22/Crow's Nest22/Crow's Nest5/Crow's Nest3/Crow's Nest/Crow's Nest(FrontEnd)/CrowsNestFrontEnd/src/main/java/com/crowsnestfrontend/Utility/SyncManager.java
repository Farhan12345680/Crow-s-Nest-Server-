package com.crowsnestfrontend.Utility;


import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;

public class SyncManager {
    public static CountDownLatch imageSenderLock =null;
    public static CountDownLatch messageLoading =null;
    public static CountDownLatch signUploading=null;
    public static CountDownLatch allLoadingLatch =new CountDownLatch(1);

    static {
        processing();



    }



    public static void processing(){

        

    }
}
