package com.CodingFileLocks;

import java.io.Serializable;
import java.io.Serial;

public class giveUpLock implements Serializable {
    @Serial
    private static final long serialVersionUID = 99802L;

    public giveUpLock() {
    }
}
