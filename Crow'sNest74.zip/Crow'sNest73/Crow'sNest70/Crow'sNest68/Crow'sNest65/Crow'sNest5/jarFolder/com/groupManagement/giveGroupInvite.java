package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class giveGroupInvite extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7710L;
    
    public int channelID;
    public String name ;

    public giveGroupInvite(String clientName ,int channelID,String name  ){
        super(clientName);
        this.channelID= channelID;
        this.name=name;
    }


}
