package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class groupDataCorrect extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7701L;
    


    public groupDataCorrect(){
        super(null);  
    }


}