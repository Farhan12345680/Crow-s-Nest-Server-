package com.chess;

import java.io.Serializable;
import java.io.Serial;


public class chessOfferReject implements Serializable{
    @Serial
    private static final long serialVersionUID = 95904L;

}