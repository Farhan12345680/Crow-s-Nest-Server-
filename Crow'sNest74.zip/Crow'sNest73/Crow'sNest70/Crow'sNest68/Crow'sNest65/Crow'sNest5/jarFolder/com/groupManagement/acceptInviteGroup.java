package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class acceptInviteGroup extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7711L;
    
    public int channelID;


    public acceptInviteGroup(String clientName ,int channelID  ){
        super(clientName);
        this.channelID= channelID;

    }


}
