package com.chess;

import java.io.Serializable;
import java.io.Serial;


public class chessOfferAccept implements Serializable{
    @Serial
    private static final long serialVersionUID = 95903L;

}