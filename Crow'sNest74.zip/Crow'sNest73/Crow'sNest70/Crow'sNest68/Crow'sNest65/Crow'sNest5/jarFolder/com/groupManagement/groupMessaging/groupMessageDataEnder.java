package com.groupManagement.groupMessaging;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class groupMessageDataEnder extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7718L;
    


    public groupMessageDataEnder(String clientName  ){
        super(clientName);
    }


}
