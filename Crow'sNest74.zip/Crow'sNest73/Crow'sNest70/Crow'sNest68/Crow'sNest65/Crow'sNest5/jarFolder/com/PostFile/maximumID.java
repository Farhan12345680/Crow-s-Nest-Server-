package com.PostFile;

import java.io.Serializable;

import com.crowsnestfrontend.SerializedClasses.payload;
import java.io.Serial;

public class maximumID extends payload implements Serializable{
        @Serial
    private static final long serialVersionUID = 12497L;

    public String senderName ;
    public int EndingRange;

    public maximumID(String senderName ,int EndingRange){
        super(senderName);
        this.senderName=senderName;
        this.EndingRange=EndingRange;
    }   
}
