package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class groupDataSendingEnder extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7699L;
    


    public groupDataSendingEnder(){
        super(null);  
    }


}