package com.chess;

import java.io.Serializable;
import java.io.Serial;


public class chessOffer implements Serializable{
    
    @Serial
    private static final long serialVersionUID = 95901L;

}