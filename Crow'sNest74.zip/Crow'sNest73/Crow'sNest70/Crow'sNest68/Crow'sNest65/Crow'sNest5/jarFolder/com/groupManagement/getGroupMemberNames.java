package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;

import com.crowsnestfrontend.SerializedClasses.payload;



public class getGroupMemberNames extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7705L;

    public int channelID;


    public getGroupMemberNames(String name , int channelId){
        super(name);  
        this.channelID=channelId;
    }
}