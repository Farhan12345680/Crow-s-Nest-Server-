package com.chess;

import java.io.Serializable;
import java.io.Serial;


public class chessCapturedPiece implements Serializable{
    @Serial
    private static final long serialVersionUID = 95907L;
    public int row , column;
    
    public chessCapturedPiece(int row , int column){
        this.column=column;
        this.row=row;

    }

}