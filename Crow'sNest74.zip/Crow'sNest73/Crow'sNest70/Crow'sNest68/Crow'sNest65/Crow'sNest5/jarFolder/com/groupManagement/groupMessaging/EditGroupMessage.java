package com.groupManagement.groupMessaging;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class EditGroupMessage extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7720L;
    
    public int messageID;
    public String messageText;
    public String imageURL;


    public EditGroupMessage(String clientName,int messageID ,String messageText , String imageURL){
        super(clientName);
        this.messageID=messageID;
        this.messageText=messageText;
        this.imageURL=imageURL;
    }


}
