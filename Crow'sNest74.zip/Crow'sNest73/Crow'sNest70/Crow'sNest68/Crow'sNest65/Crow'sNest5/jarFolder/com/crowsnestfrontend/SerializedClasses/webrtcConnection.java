package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class webrtcConnection extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID = 701L;

    public String userId;
    public String candidate;
    public String type;
    public String sdp;

    public webrtcConnection(String userId, String candidate, String type, String sdp) {
        super(userId);
        this.userId = userId;
        this.candidate = candidate;
        this.type=type;
        this.sdp=sdp;
    }
}