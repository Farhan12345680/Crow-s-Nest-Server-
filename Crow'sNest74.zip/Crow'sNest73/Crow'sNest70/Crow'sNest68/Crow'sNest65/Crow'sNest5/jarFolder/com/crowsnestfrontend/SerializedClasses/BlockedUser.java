package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class BlockedUser extends payload implements Serializable {
        
    @Serial 
    private static final long serialVersionUID=3680L;
    public String name;
    public String imageURL;

    public BlockedUser(String name, String imageURL){
        super(null);
        this.name=name;
        this.imageURL=imageURL;
        
    }
}
