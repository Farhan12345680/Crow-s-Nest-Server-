package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;

import com.crowsnestfrontend.SerializedClasses.payload;



public class groupMemberInfo extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7706L;


    public String  name ;
    public int memberID;
    public int memberRole;
    public String imageURL;

    public groupMemberInfo(String name ,String imageURL, int memberID , int memberRole){
        super(name);  
        this.memberID=memberID;
        this.memberRole=memberRole;
        this.imageURL=imageURL;
        
    }
}