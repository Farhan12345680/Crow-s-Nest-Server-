package com.groupManagement.groupMessaging;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class groupMessagingSender extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7715L;
    
    public int channelID;
    public String messageText;
    public String imageURL;


    public groupMessagingSender(String clientName ,int channelID ,String messageText ,String imageURL  ){
        super(clientName);
        this.channelID= channelID;
        this.messageText=messageText;
        this.imageURL=imageURL;

    }


}
