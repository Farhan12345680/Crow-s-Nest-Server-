package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class showGroupInviteRangeEnd extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7702L;




    public showGroupInviteRangeEnd( ){
        super(null );


    }


}