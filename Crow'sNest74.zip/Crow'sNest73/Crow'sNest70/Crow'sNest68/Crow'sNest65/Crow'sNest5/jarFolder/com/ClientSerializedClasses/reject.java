package com.ClientSerializedClasses;

import java.io.Serializable;
import java.io.Serial;

public class reject implements Serializable {
    @Serial
    private static final long serialVersionUID =1712L;
    
    public reject(){
        
    }       
    
}
