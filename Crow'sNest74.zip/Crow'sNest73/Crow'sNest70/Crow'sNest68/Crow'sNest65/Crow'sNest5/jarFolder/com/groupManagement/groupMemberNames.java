package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;

import com.crowsnestfrontend.SerializedClasses.payload;
import com.groupManagement.groupMemberInfo;


public class groupMemberNames extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7704L;

    public ArrayList<groupMemberInfo>dataArraylist=new ArrayList<>();


    public groupMemberNames(){
        super(null);  
    }
}