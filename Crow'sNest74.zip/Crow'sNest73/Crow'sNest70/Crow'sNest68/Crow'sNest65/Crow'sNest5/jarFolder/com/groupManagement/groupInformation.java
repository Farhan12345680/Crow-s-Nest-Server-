package com.groupManagement;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class groupInformation extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7694L;
    
    public String groupName ;
    public String groupDescription;
    public String groupImageURL;
    public String creatorName ;
    public int groupID;

    public groupInformation(String clientName , String groupName 
    ,String groupDescription,String groupImageURL ,String creatorName , int groupID){
        super(clientName);  
        this.groupName=groupName;
        this.groupDescription=groupDescription;
        this.groupImageURL=groupImageURL;
        this.creatorName=creatorName;
        this.groupID=groupID;
    }


}