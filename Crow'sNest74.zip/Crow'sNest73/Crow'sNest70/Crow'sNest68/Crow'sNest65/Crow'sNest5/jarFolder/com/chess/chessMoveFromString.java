package com.chess;

import java.io.Serializable;
import java.io.Serial;


public class chessMoveFromString implements Serializable{
    @Serial
    private static final long serialVersionUID = 95906L;
    public String from;
    public String to;

    public chessMoveFromString(String from , String to){
        this.from=from;
        this.to=to;
    }

}