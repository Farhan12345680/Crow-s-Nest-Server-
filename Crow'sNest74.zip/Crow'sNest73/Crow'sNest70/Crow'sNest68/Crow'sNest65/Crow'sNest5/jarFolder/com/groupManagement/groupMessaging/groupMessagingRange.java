package com.groupManagement.groupMessaging;

import java.io.Serial;
import java.io.Serializable;
import com.crowsnestfrontend.SerializedClasses.payload;



public class groupMessagingRange extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=7717L;
    
    public int channelID;
    public int start;
    public int end;



    public groupMessagingRange(String clientName,int channelID,int start , int end  ){
        super(clientName);
        this.start=start;
        this.end = end;
        this.channelID=channelID;
    }


}
