package com.crowsnestfrontend;

import com.ClientSerializedClasses.endCall;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.webrtcCaller.Callee;
import com.crowsnestfrontend.webrtcCaller.Caller;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.*;
import java.util.Objects;

import okhttp3.*;



public class MainApplication extends Application {
    public static OkHttpClient client= new OkHttpClient();


    @Override
    public void start(Stage stage) throws IOException, ClassNotFoundException {
        SceneManager.globalStage=stage;
        try {
            stage.getIcons().add(new Image(
                    Objects.requireNonNull(MainApplication.class.getResourceAsStream("images/raven.png"))
            ));
        } catch (Exception e) {

        }
        Class.forName("com.crowsnestfrontend.Utility.SyncManager");

        stage.setTitle("Crow's Nest");
        SignBranchingHandler.signBranchLogicHandler();

        stage.show();
        stage.centerOnScreen();
        stage.setResizable(false);
        stage.setOnCloseRequest((event)->{
                    closingFunction();
                }
        );

        Runtime.getRuntime().addShutdownHook(new Thread(MainApplication::closingFunction));
    };

    public static void main(String[] args) {
        launch();
    }

    public static void closingFunction(){
        try{
            Thread.startVirtualThread(()->{

                Owner.nameId=(Owner.nameId!=null)?makeSpaceDisappear(Owner.nameId):null;
                String urlString = "http://localhost:8080/signOut/?"+(Owner.nameId==null?"":Owner.nameId);
                Request request = new Request.Builder()
                        .url(urlString)
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    if (response.isSuccessful()) {
                        if(response.body()!=null){

                        }
                    } else {
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }).join();

            if(Caller.callerObject!=null){
                Caller.callerObject.sendObject(new endCall());
                Caller.callerObject.scheduleCleanup();



            }
            if(Callee.callee!=null){
                Callee.callee.sendObject(new endCall());
                Callee.callee.scheduleCleanup();



            }

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            Platform.exit();
        }
    }

    public static String makeSpaceDisappear(String name ){
        StringBuilder ResultString=new StringBuilder("");
        for(int i=0;i<name.length(); i++){
            if(name.charAt(i)==' '){
                ResultString.append("%");
                ResultString.append("20");
                        continue;
            }
            ResultString.append(name.charAt(i));
        }


        return ResultString.toString();
    }
}