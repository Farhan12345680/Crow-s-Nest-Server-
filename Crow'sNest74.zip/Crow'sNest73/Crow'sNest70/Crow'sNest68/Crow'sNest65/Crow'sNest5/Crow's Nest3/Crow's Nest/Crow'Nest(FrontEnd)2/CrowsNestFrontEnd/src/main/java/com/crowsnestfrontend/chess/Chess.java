package com.crowsnestfrontend.chess;

import com.chess.chessMoveFromString;
import com.crowsnestfrontend.webrtcCaller.Callee;
import com.crowsnestfrontend.webrtcCaller.Caller;
import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.Piece;
import com.github.bhlangonijr.chesslib.Side;
import com.github.bhlangonijr.chesslib.Square;
import com.github.bhlangonijr.chesslib.move.Move;
import com.github.bhlangonijr.chesslib.move.MoveGenerator;
import com.github.bhlangonijr.chesslib.move.MoveGeneratorException;
import javafx.scene.image.ImageView;


import java.util.ArrayList;
import java.util.List;

public class Chess {

    public static Side type;

    public static ArrayList<ArrayList<ImageView>> ImageViewArrayList=new ArrayList<>();
    public static Board board ;

    public Chess(Side type){
        board=new Board();

        Chess.type=type;

        for(int i=0;i<8; i++){
            ImageViewArrayList.add(new ArrayList<>());
        }
    }

    public static boolean moveChecker(String side){
        if(board.getSideToMove()!= type){
            return false;
        }

        Piece piece= board.getPiece(Square.valueOf(side));
        Square square=Square.valueOf(side);

        if(piece==null){
            return false;
        }

        if(piece.getPieceSide()!=type){
            return false;
        }

        MoveGenerator.generateLegalMoves(board);

        try {
            List<Move> legalMoves = MoveGenerator.generateLegalMoves(board);

            for (Move move : legalMoves) {
                if (move.getFrom() == square) {

                    System.out.println("Legal move: " + move);

                }
            }

        }
        catch (MoveGeneratorException e) {
            e.printStackTrace();
        }
        return true;
    }

    public static boolean idValid(String data1 , String data2){
        System.out.println("is valid checking happening");
        Square from = Square.valueOf(data1);
        Square to = Square.valueOf(data2);


        Move moveToCheck = new Move(from, to);

        return MoveGenerator.generateLegalMoves(board)
                .contains(moveToCheck);
    }

    public static void moveTo(String data1 , String data2){
        Square from = Square.valueOf(data1);
        Square to = Square.valueOf(data2);


        board.doMove(new Move(from, to));


        if(Caller.callerObject!=null){
            Caller.callerObject.sendObject(new chessMoveFromString(data1 ,data2));
        }
        if(Callee.callee!=null){
            Callee.callee.sendObject(new chessMoveFromString(data1 ,data2));
        }

    }

    public static void moveTo2(String data1 , String data2){
        Square from = Square.valueOf(data1);
        Square to = Square.valueOf(data2);


        board.doMove(new Move(from, to));
    }

    public static boolean MateCheck(){
        return board.isMated();
    }
}
