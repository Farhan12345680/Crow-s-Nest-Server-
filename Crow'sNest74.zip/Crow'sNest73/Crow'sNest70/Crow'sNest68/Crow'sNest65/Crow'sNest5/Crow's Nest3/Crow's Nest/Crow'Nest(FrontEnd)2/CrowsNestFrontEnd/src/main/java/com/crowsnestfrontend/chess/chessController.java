package com.crowsnestfrontend.chess;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.controllers.VideoSceneController;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

import java.util.ArrayList;

public class chessController {

    public ImageView a8, b8, c8, d8, e8, f8, g8, h8;
    public ImageView a7, b7, c7, d7, e7, f7, g7, h7;
    public ImageView a6, b6, c6, d6, e6, f6, g6, h6;
    public ImageView a5, b5, c5, d5, e5, f5, g5, h5;
    public ImageView a4, b4, c4, d4, e4, f4, g4, h4;
    public ImageView a3, b3, c3, d3, e3, f3, g3, h3;
    public ImageView a2, b2, c2, d2, e2, f2, g2, h2;
    public ImageView a1, b1, c1, d1, e1, f1, g1, h1;

    @FXML
    public VBox ButtonMenu;

    public StackPane chessStackPane;

    public static StackPane pane;
    public String moveData;

    public Button Surrender;
    public Label ChessState;

    public StackPane ParentStackPane;

    @FXML
    public void initialize() {

        String GLOBAL_STYLE=
                """
                @import url('https://fonts.cdnfonts.com/css/telegrama');
                
                #ParentStackPane {
                    -fx-background-color: #234C6A;
                    -fx-text-fill: white;
                    -fx-font-size: 14px;
                    -fx-border-radius: 5px;
                }
                
                #LabelData {
                    -fx-font: normal bold 30px 'telegrama';
                    -fx-font-optical-sizing: auto;
                    -fx-font-variation-settings:
                        "slnt" 0,
                        "CRSV" 0.5,
                        "ELSH" 0,
                        "ELXP" 0,
                        "SZP1" 0,
                        "SZP2" 0,
                        "XPN1" 0,
                        "XPN2" 0,
                        "YPN1" 0,
                        "YPN2" 0;
                }
                
                #surrender {
                    -fx-font: normal bold 18px 'Telegram';
                    -fx-font-weight: bolder;
                    -fx-text-fill: #234C6A;\s
                    -fx-background-radius: 6px;
                    -fx-border-width: 2px;
                    -fx-border-radius: 6px;
                    -fx-cursor: hand;
                
                    -fx-effect: dropshadow(three-pass-box, rgba(60, 70, 80, 0.25), 6, 0, 0, 4);
                    -fx-transition: all 0.3s ease;
                }
                
                #surrender:hover {
                    -fx-background-color: linear-gradient(to bottom, #9e4b4b, #7a3737); /* Slightly deeper reds */
                    -fx-effect: dropshadow(three-pass-box, rgba(191, 167, 111, 0.4), 8, 0, 0, 6);
                }
                
                #surrender:pressed {
                    -fx-background-color: #622e2e;
                    -fx-effect: dropshadow(three-pass-box, rgba(40, 45, 50, 0.3), 4, 0, 0, 2);
                    -fx-scale-x: 0.98;
                    -fx-scale-y: 0.98;
                }
                """;


        ParentStackPane.getStylesheets().add(
                "data:text/css," + GLOBAL_STYLE.replace("\n", "%0A").replace(" ", "%20")
        );


        if (Chess.ImageViewArrayList == null || Chess.ImageViewArrayList.isEmpty()) {
            Chess.ImageViewArrayList = new ArrayList<>();
            for (int i = 0; i < 8; i++) {
                Chess.ImageViewArrayList.add(new ArrayList<>());
            }
        }

        Chess.ImageViewArrayList.get(0).addAll(java.util.List.of(a1, a2, a3, a4, a5, a6, a7, a8));
        Chess.ImageViewArrayList.get(1).addAll(java.util.List.of(b1, b2, b3, b4, b5, b6, b7, b8));
        Chess.ImageViewArrayList.get(2).addAll(java.util.List.of(c1, c2, c3, c4, c5, c6, c7, c8));
        Chess.ImageViewArrayList.get(3).addAll(java.util.List.of(d1, d2, d3, d4, d5, d6, d7, d8));
        Chess.ImageViewArrayList.get(4).addAll(java.util.List.of(e1, e2, e3, e4, e5, e6, e7, e8));
        Chess.ImageViewArrayList.get(5).addAll(java.util.List.of(f1, f2, f3, f4, f5, f6, f7, f8));
        Chess.ImageViewArrayList.get(6).addAll(java.util.List.of(g1, g2, g3, g4, g5, g6, g7, g8));
        Chess.ImageViewArrayList.get(7).addAll(java.util.List.of(h1, h2, h3, h4, h5, h6, h7, h8));

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                ImageView r = Chess.ImageViewArrayList.get(i).get(j);
                if (r == null) continue;

                String id = "" + (char) ('A' + i) + (j + 1);
                r.setId(id);
                final String o = id;

                r.setOnDragDetected(e -> {
                    if (!Chess.moveChecker(o) || r.getImage() == null) {
                        e.consume();
                        return;
                    }
                    Dragboard db = r.startDragAndDrop(TransferMode.MOVE);
                    moveData = o;
                    ClipboardContent content = new ClipboardContent();
                    content.putImage(r.getImage());
                    db.setContent(content);
                    r.setOpacity(0.4);
                    e.consume();
                });

                r.setOnDragOver(event -> {
                    if (event.getGestureSource() != r && event.getDragboard().hasImage()) {
                        event.acceptTransferModes(TransferMode.MOVE);
                    }
                    event.consume();
                });

                r.setOnDragDropped(e -> {
                    if (!Chess.idValid(moveData, o)) {
                        e.setDropCompleted(false);
                        e.consume();
                        return;
                    }

                    Dragboard db = e.getDragboard();
                    boolean success = false;
                    if (db.hasImage()) {
                        r.setImage(db.getImage());
                        ImageView source = (ImageView) e.getGestureSource();
                        source.setImage(null);
                        success = true;
                    }

                    Chess.moveTo(moveData, o);
                    e.setDropCompleted(success);
                    e.consume();
                });

                r.setOnDragDone(e -> {
                    r.setOpacity(1.0);
                    e.consume();
                });
            }
        }


        Surrender.setOnMouseClicked(e -> {

            VideoSceneController.box.getChildren().remove(pane);
        });


    }
}
