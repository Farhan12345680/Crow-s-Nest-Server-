package com.crowsnestfrontend.controllers;

import com.ClientSerializedClasses.accept;
import com.ClientSerializedClasses.offer;
import com.cloudinary.utils.ObjectUtils;
import com.crowsnestfrontend.ClientSideDataBase.changeOwnerClientDatabase;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.Messages.MessageCell;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.ImageChanger;
import com.crowsnestfrontend.SerializedClasses.showAllBlockedUsers;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.User.User;
import com.crowsnestfrontend.UserFloatingButton.UserCell;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.forum.forumViewScene;
import com.crowsnestfrontend.webrtcCaller.Caller;
import com.crowsnestfrontend.webrtcCaller.VideoScene;
import com.crowsnestfrontend.webrtcCaller.callerWaitingScene;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import com.crowsnestfrontend.Messages.Message;
import javafx.stage.*;
import com.crowsnestfrontend.gifObject.gifObjectVbox;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import static com.crowsnestfrontend.SceneManagement.SceneManager.*;
import static com.crowsnestfrontend.webrtcCaller.Caller.callerObject;

public class mainSceneController {

    @FXML public Text FriendUserName;
    @FXML public ListView<Message> messageListView;
    @FXML public ImageView sendButton;
    @FXML public Pane WelcomeScene;
    @FXML public StackPane sceneHolder;
    @FXML public VBox messageBox;
    @FXML public Pane BlockScreen;
    @FXML public Text blockUserMessage;
    @FXML public ImageView callButton;
    @FXML public ImageView forumView;
    @FXML
    public ImageView gifButton;
    @FXML
    public Button groupButton;
    public HBox options_call_video_message;

    @FXML
    public ImageView uploadComputerImage;
    @FXML
    public VBox messageLoading;

    @FXML private Label Title_Shower;

    @FXML public ImageView Personal_image_id;

    @FXML private Button people_button;
    @FXML private Button friends_button;
    @FXML private Button requests_button;
    @FXML private Button cross_button;

    @FXML private ImageView search_icon;

    @FXML public ImageView user_icon;
    @FXML public Button Message;
    @FXML public Button Call;
    @FXML public Button Video_Call;

    @FXML private ImageView writingImage;
    @FXML private Button send_button;

    public TextField searchPeople;
    public ImageView clearSearchPeople;
    public TextField writeTextField;
    public Button sendTextMessage;

    @FXML public ListView<User> peopleListView;
    @FXML public ListView<User> FriendPeopleView;
    @FXML public ListView<User> requestScrollView;

    public final ObservableList<User> obsUsers           = FXCollections.observableArrayList();
    public final ObservableList<User> friendUsers        = FXCollections.observableArrayList();
    public final ObservableList<User> friendRequestUsers = FXCollections.observableArrayList();

    @FXML
    public void profileImageSetter(Image newImage){
        this.Personal_image_id.setImage(newImage);
    }
    private long index = 1;

    public static String name;
    public static String image;

    @FXML
    public void initialize() throws IOException {

        if (Title_Shower != null) {
            Title_Shower.setText("Crow's Nest");
        }

        if (Personal_image_id != null) {
            Personal_image_id.setOnMouseClicked(this::gg);
        }

        if (clearSearchPeople != null) {
            clearSearchPeople.setOnMouseClicked(this::clearSearch);
        }

        if (sendTextMessage != null) {
            sendTextMessage.setOnMouseClicked(this::textSender);
        }

        if (people_button != null) {
            people_button.setOnMouseClicked(this::peopleShower);
        }
        if (friends_button != null) {
            friends_button.setOnMouseClicked(this::friendShower);
        }
        if (requests_button != null) {
            requests_button.setOnMouseClicked(this::requestShower);
        }
        if(FriendUserName!=null){
            FriendUserName.setWrappingWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth()-450);
        }
        if (callButton != null) {

            callButton.setOnMouseClicked((event) -> {
                if (callerObject == null || callerObject.pc == null) {
                    callerObject = new Caller();
                }

                try {
                    Platform.runLater(() -> {
                        Dialog<Void> dialog = new Dialog<>();
                        dialog.setDialogPane(new DialogPane());
                        ButtonType tempButton = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
                        dialog.getDialogPane().getButtonTypes().add(tempButton);
                        dialog.getDialogPane().lookupButton(tempButton).setVisible(false);
                        dialog.getDialogPane().lookupButton(tempButton).setManaged(false);
                        dialog.initStyle(StageStyle.UNDECORATED);

                        callerWaitingScene calling = callerWaitingScene.initialize(() -> {
                            dialog.close();
//                            Thread.startVirtualThread(() -> {
//                                if (Caller.callerObject != null) {
//                                    Caller.callerObject.stopCaller();
//                                }
//                            });
                            callerWaitingScene.callerWaitingInstance = null;
                        });
                        dialog.getDialogPane().setContent(calling);
                        dialog.show();
                        Thread.startVirtualThread(() -> {

                            callerObject.makeOffer();
                        });

                    });

                }
                catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
        }

        if(forumView!= null){

            forumView.setOnMouseClicked((e)->{
                SceneManager.globalStage.setScene(forumViewScene.initialize());
                SceneManager.globalStage.centerOnScreen();
            });




        }

        FilteredList<User> filteredPeople = new FilteredList<>(obsUsers, p -> true);
        FilteredList<User> filteredFriends = new FilteredList<>(friendUsers, p -> true);
        FilteredList<User> filteredRequests = new FilteredList<>(friendRequestUsers, p -> true);

        peopleListView.setItems(filteredPeople);
        FriendPeopleView.setItems(filteredFriends);
        requestScrollView.setItems(filteredRequests);

        peopleListView.setCellFactory(lv -> {
            try {
                return new UserCell();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        FriendPeopleView.setCellFactory(lv -> {
            try {
                return new UserCell();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        requestScrollView.setCellFactory(lv -> {
            try {
                return new UserCell();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        peopleListView.setStyle("-fx-background-color: #1d1f1f; -fx-control-inner-background: #1d1f1f; -fx-selection-bar: transparent; -fx-selection-bar-non-focused: transparent;");
        FriendPeopleView.setStyle("-fx-background-color: #1d1f1f; -fx-control-inner-background: #1d1f1f; -fx-selection-bar: transparent; -fx-selection-bar-non-focused: transparent;");
        requestScrollView.setStyle("-fx-background-color: #1d1f1f; -fx-control-inner-background: #1d1f1f; -fx-selection-bar: transparent; -fx-selection-bar-non-focused: transparent;");

        peopleListView.setFocusTraversable(false);
        FriendPeopleView.setFocusTraversable(false);
        requestScrollView.setFocusTraversable(false);

        peopleListView.setSelectionModel(new NoSelectionModel<>());
        FriendPeopleView.setSelectionModel(new NoSelectionModel<>());
        requestScrollView.setSelectionModel(new NoSelectionModel<>());

        searchPeople.textProperty().addListener((observable, oldVal, newVal) -> {
            String filterText = newVal == null ? "" : newVal.toLowerCase();

            if (index == 1) {
                filteredPeople.setPredicate(u -> u.name.toLowerCase().contains(filterText));
            } else if (index == 2) {
                filteredFriends.setPredicate(u -> u.name.toLowerCase().contains(filterText));
            } else if (index == 3) {
                filteredRequests.setPredicate(u -> u.name.toLowerCase().contains(filterText));
            }
        });

        messageListView.setCellFactory(listView -> new MessageCell());
        messageListView.setStyle("-fx-background-color: transparent; -fx-control-inner-background: transparent; -fx-selection-bar: transparent; -fx-selection-bar-non-focused: transparent;");
        messageListView.setFocusTraversable(false);
        messageListView.setSelectionModel(new NoSelectionModel<>());

        SelectedUserData.name.addListener((observable, oldValue, newValue) -> {
            Platform.runLater(() -> {
                try {
                    SceneManager.mainSceneContrller.user_icon.setImage(new Image(SelectedUserData.image));
                } catch (Exception e) {
                    e.printStackTrace();
                }

                SceneManager.mainSceneContrller.FriendUserName.setText(SelectedUserData.name.get());
            });
        });

        gifButton.setOnMouseClicked((_)->{
            Popup popup = new Popup();
            popup.setAutoHide(true);

            gifObjectVbox temp = gifObjectVbox.initialize();


            popup.getContent().add(temp);

            double x = Screen.getScreens().getFirst().getVisualBounds().getWidth()/2 - 300   ;
            double y = Screen.getScreens().getFirst().getVisualBounds().getHeight()/2 -
                    200;
            popup.setX(x);
            popup.setY(y);
            popup.show(SceneManager.globalStage);
            popup.setOnHidden(event -> {
                System.out.println("Popup was closedsfdsfsdfasdfsaqdfsfafas!");
                popup.getContent().clear();
            });

        });
        sendButton.setOnMouseClicked(event -> {
            if (writeTextField.getText().trim().isEmpty()) {
                return;
            }

            constantStream.payloadBlockingQueue.add(new com.crowsnestfrontend.SerializedClasses.Message(
                    Owner.nameId,
                    SelectedUserData.name.get(),
                    writeTextField.getText(),
                    0, -1 , 1,"")
            );
            Platform.runLater(() -> {
                writeTextField.clear();

            });

        });

        writeTextField.setOnKeyPressed((event) -> {
            if (event.getCode() == KeyCode.ENTER) {
                if (writeTextField.getText().trim().isEmpty()) {
                    return;
                }

                constantStream.payloadBlockingQueue.add(new com.crowsnestfrontend.SerializedClasses.Message(
                        Owner.nameId,
                        SelectedUserData.name.get(),
                        writeTextField.getText(),
                        0, -1 ,1 ,"")
                );

                Platform.runLater(() -> {
                    writeTextField.clear();

                });

            }
        });

        if(groupButton!=null){
            groupButton.setOnMouseClicked((e)->{
                try{
                    var GroupSceneloader = new FXMLLoader(MainApplication.class.getResource("GroupMessaging.fxml"));
                    Scene groupScene = new Scene(GroupSceneloader.load(), Screen.getScreens().getFirst().getVisualBounds().getWidth(),
                            Screen.getScreens().getFirst().getVisualBounds().getHeight()-50);
                    SceneManager.globalStage.setScene(groupScene);
                }catch (Exception e1){
                    e1.printStackTrace();
                }

            });
        }

        String base = "-fx-background-color: #2e2f2f; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-repeat: no-repeat; -fx-background-position: center center; -fx-background-size: 60%; -fx-background-radius: 6px; -fx-border-radius: 6px; -fx-padding: 8px 12px; -fx-cursor: hand;";
        String hover = "-fx-background-color: #3a3b3b; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-repeat: no-repeat; -fx-background-position: center center; -fx-background-size: 60%; -fx-background-radius: 6px; -fx-border-radius: 6px; -fx-padding: 8px 12px; -fx-cursor: hand;";
        String pressed = "-fx-background-color: #262727; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-background-repeat: no-repeat; -fx-background-position: center center; -fx-background-size: 60%; -fx-background-radius: 6px; -fx-border-radius: 6px; -fx-padding: 8px 12px; -fx-cursor: hand;";

        applyButtonEffects(people_button, base, hover, pressed);
        applyButtonEffects(friends_button, base, hover, pressed);
        applyButtonEffects(requests_button, base, hover, pressed);
        applyButtonEffects(Message, base, hover, pressed);
        applyButtonEffects(Call, base, hover, pressed);
        applyButtonEffects(Video_Call, base, hover, pressed);
        applyButtonEffects(send_button, base, hover, pressed);

        applyButtonEffects(groupButton , base , hover ,pressed);

        if(uploadComputerImage!=null){
            uploadComputerImage.setOnMouseClicked((e)->{
                Window ownerWindow = ((Node)e.getSource()).getScene().getWindow();
                FileChooser fileChooser = new FileChooser();

                fileChooser.setTitle("Select Profile Image");
                fileChooser.getExtensionFilters().addAll(
                        new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp")
                );

                File selectedFile = fileChooser.showOpenDialog(ownerWindow);
                if (selectedFile != null) {
                    CountDownLatch UPLOADER_LATCH=new CountDownLatch(1);
                    Platform.runLater(()->{
                        SceneManager.globalStage.setScene(SceneManager.loadingScene);
                        SceneManager.globalStage.centerOnScreen();
                    });

                    Thread.startVirtualThread(()->{
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        String selectedUserName =SelectedUserData.name.get();
                        try {
                            net.coobird.thumbnailator.Thumbnails.of(selectedFile)
                                    .scale(1)
                                    .outputFormat(Files.probeContentType(selectedFile.toPath()).substring(6))
                                    .toOutputStream(baos);
                        } catch (IOException e1) {
                            throw new RuntimeException(e1);
                        }

                        byte[] imageBytes = baos.toByteArray();

                        Image image = new Image(new ByteArrayInputStream(imageBytes));


                        Map uploadResult = null;
                        try {
                            uploadResult = cloudinary.uploader().upload(imageBytes,
                                    ObjectUtils.asMap("folder", "profile_images"));
                        }
                        catch (IOException e1) {
                            throw new RuntimeException(e1);
                        }

                        String imageUrl = (String) uploadResult.get("secure_url");

                        //System.out.println("Uploaded Image URL: " + imageUrl);
                        UPLOADER_LATCH.countDown();

                        try{
                            UPLOADER_LATCH.await();
                            Platform.runLater(()->{
                                SceneManager.globalStage.setScene(SceneManager.mainScene);
                                SceneManager.globalStage.centerOnScreen();

                            });
                            constantStream.payloadBlockingQueue.add(new com.crowsnestfrontend.SerializedClasses.Message(

                                    Owner.nameId,
                                    selectedUserName,
                                    "",
                                    0, -1 , 2,imageUrl)
                            );
                            System.out.println(
                                imageUrl
                            );
                        }catch (Exception e2){
                            e2.printStackTrace();
                        }


            });

        }});}

        WelcomeScene.setStyle("-fx-background-size: "+Screen.getScreens().getFirst().getVisualBounds().getWidth()*60/100);

    }


    public void addUser(User user) {
        Platform.runLater(() -> {
            obsUsers.add(user);
        });
    }

    public void addRequestUser(User user){
        Platform.runLater(()->{
            friendRequestUsers.add(user);
        });
    }

    private void requestShower(MouseEvent event) {
        index=3;
        requestScrollView.setVisible(true);
        requestScrollView.setManaged(true);
        peopleListView.setVisible(false);
        peopleListView.setManaged(false);
        FriendPeopleView.setManaged(false);
        FriendPeopleView.setVisible(false);
    }

    private void friendShower(MouseEvent event) {
        index=2;
        requestScrollView.setVisible(false);
        requestScrollView.setManaged(false);
        peopleListView.setVisible(false);
        peopleListView.setManaged(false);
        FriendPeopleView.setManaged(true);
        FriendPeopleView.setVisible(true);
    }

    private void peopleShower(MouseEvent event) {
        index=1;

        requestScrollView.setVisible(false);
        requestScrollView.setManaged(false);
        peopleListView.setVisible(true);
        peopleListView.setManaged(true);
        FriendPeopleView.setManaged(false);
        FriendPeopleView.setVisible(false);
    }

    private void textSender(MouseEvent event) {
        writeTextField.clear();
    }

    private void clearSearch(MouseEvent event) {
        searchPeople.setText("");
    }

    @FXML
    private void gg(MouseEvent event) {
        profileController.BlockDataHolder.getChildren().clear();
        
        constantStream.payloadBlockingQueue.add(new showAllBlockedUsers(Owner.nameId ,null));
        SceneManager.globalStage.setScene(SceneManager.profileScene);
        SceneManager.globalStage.centerOnScreen();
    }

    @FXML
    private void onSendButtonClicked() {
    }

    @FXML
    private void onPeopleClicked() {
    }

    @FXML
    private void onFriendsClicked() {
    }

    @FXML
    private void onRequestsClicked() {
    }

    @FXML
    private void onCrossClicked() {
    }

    @FXML
    private void onMessageClicked() {
    }

    @FXML
    private void onCallClicked() {
    }

    @FXML
    private void onVideoCallClicked() {
    }

    private void applyButtonEffects(Button btn, String baseStyle, String hoverStyle, String pressedStyle) {
        if (btn == null) return;
        btn.setStyle(baseStyle);
        btn.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> btn.setStyle(hoverStyle));
        btn.addEventHandler(MouseEvent.MOUSE_EXITED, e -> btn.setStyle(baseStyle));
        btn.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> btn.setStyle(pressedStyle));
        btn.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> btn.setStyle(hoverStyle));
    }

    private static class NoSelectionModel<T> extends MultipleSelectionModel<T> {
        @Override
        public ObservableList<Integer> getSelectedIndices() {
            return FXCollections.emptyObservableList();
        }

        @Override
        public ObservableList<T> getSelectedItems() {
            return FXCollections.emptyObservableList();
        }

        @Override
        public void selectIndices(int index, int... indices) {}

        @Override
        public void selectAll() {}

        @Override
        public void clearAndSelect(int index) {}

        @Override
        public void select(int index) {}

        @Override
        public void select(T obj) {}

        @Override
        public void clearSelection(int index) {}

        @Override
        public void clearSelection() {}

        @Override
        public boolean isSelected(int index) { return false; }

        @Override
        public boolean isEmpty() { return true; }

        @Override
        public void selectPrevious() {}

        @Override
        public void selectNext() {}

        @Override
        public void selectFirst() {}

        @Override
        public void selectLast() {}


    }
}
