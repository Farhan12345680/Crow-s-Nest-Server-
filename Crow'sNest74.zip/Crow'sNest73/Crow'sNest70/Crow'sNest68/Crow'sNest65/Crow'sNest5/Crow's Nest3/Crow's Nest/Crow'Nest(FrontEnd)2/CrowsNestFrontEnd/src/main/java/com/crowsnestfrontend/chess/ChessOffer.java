package com.crowsnestfrontend.chess;

import com.chess.chessOfferAccept;
import com.chess.chessOfferReject;
import com.chess.chessReject;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.webrtcCaller.Callee;
import com.crowsnestfrontend.webrtcCaller.Caller;
import com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper;
import com.github.bhlangonijr.chesslib.Side;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;

import java.io.IOException;


public class ChessOffer extends VBox {
    public static ChessOffer offer;
    public Runnable runnable;
    @FXML
    public ImageView accept;
    @FXML
    public ImageView decline;


    public static ChessOffer initialize(int state){

        if(offer==null){
            offer=new ChessOffer(state);
        }

        return offer;
    }

    public ChessOffer(int state){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("ChessOffer.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        accept.setOnMouseClicked((e)->{
            if(Caller.callerObject!=null){
                Caller.callerObject.sendObject(new chessOfferAccept());
                runnable.run();
            }
            else if(Callee.callee!=null){
                Callee.callee.sendObject(new chessOfferAccept());
                runnable.run();
            }

            new Chess(Side.WHITE);
            FXMLLoader fxmlLoader2 = new FXMLLoader(MainApplication.class.getResource("ChessDataStackPane.fxml"));

            StackPane pane1=null;

            chessController chess;

            try {
                pane1 = fxmlLoader2.load();
                chess = fxmlLoader2.getController();
                GlobalResourceKeeper.chesscontroller=chess;
                chess.ButtonMenu = GlobalResourceKeeper.controller.codeArea;
                chess.chessStackPane = pane1;

            }
            catch(IOException ex){
                ex.printStackTrace();
            }
            for (Node node : GlobalResourceKeeper.controller.codeArea.getChildren()) {
                node.setManaged(false);
                node.setVisible(false);
            }
            GlobalResourceKeeper.controller.voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 30f / 100);
            GlobalResourceKeeper.controller.codeArea.setVisible(true);
            GlobalResourceKeeper.controller.codeArea.setManaged(true);
            GlobalResourceKeeper.controller.screenShare.setManaged(false);
            GlobalResourceKeeper.controller.screenShare.setVisible(false);
            GlobalResourceKeeper.controller.codeArea.getChildren().add(pane1);
            GlobalResourceKeeper.isChessStackPane.set(false);
        });

        decline.setOnMouseClicked((e)->{
            if(state==1){

                if(Caller.callerObject!=null){
                    Caller.callerObject.sendObject(new chessReject());
                    runnable.run();
                    offer=null;
                }
                else if(Callee.callee!=null){
                    Callee.callee.sendObject(new chessReject());
                    runnable.run();
                    offer=null;
                }
                return;
            }

            if(Caller.callerObject!=null){
                Caller.callerObject.sendObject(new chessOfferReject());
                runnable.run();
                offer=null;
            }
            else if(Callee.callee!=null){
                Callee.callee.sendObject(new chessOfferReject());
                runnable.run();
                offer=null;
            }
        });

    }
}
