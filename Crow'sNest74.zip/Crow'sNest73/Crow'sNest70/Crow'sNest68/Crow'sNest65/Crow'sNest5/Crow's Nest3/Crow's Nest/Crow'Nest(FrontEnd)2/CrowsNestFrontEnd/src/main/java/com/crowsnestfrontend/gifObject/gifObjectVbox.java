package com.crowsnestfrontend.gifObject;

import com.crowsnestfrontend.MainApplication;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import static com.crowsnestfrontend.MainApplication.client;

public class gifObjectVbox extends VBox {
    public static gifObjectVbox staticGifObject;
    @FXML
    public TextField gifSearch;
    @FXML
    public Button searchGifButton;
    @FXML
    public FlowPane imageHolder;
    public static ArrayList<gifObjectImageView> arr = new ArrayList<>();

    public static gifObjectVbox initialize() {
        if (staticGifObject == null) {
            staticGifObject = new gifObjectVbox();
            for (int i = 0; i < 20; i++) {
                gifObjectImageView temp = new gifObjectImageView("");
                arr.add(temp);
                Platform.runLater(() -> {
                    staticGifObject.imageHolder.getChildren().add(temp);
                });
            }
            try {

                Thread.startVirtualThread(() -> {
                    Platform.runLater(() -> {
                        for (var imageView : staticGifObject.imageHolder.getChildren()) {
                            ((gifObjectImageView) imageView).setNull();
                        }
                    });
                    HttpUrl url = HttpUrl.parse("https://tenor.googleapis.com/v2/search")
                            .newBuilder().addQueryParameter("q", "default")
                            .addQueryParameter("key", "AIzaSyBEAma3ZbO9EIVdPTnwlwCZyEZsSc_4478")
                            .addQueryParameter("limit", "20")
                            .build();
                    Request request = new Request.Builder()
                            .url(url)
                            .get()
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String responseBody = response.body().string();
                            JSONObject json = new JSONObject(responseBody);

                            JSONArray results = json.getJSONArray("results");
                            for (int i = 0; i < results.length(); i++) {
                                JSONObject gifObject = results.getJSONObject(i);
                                JSONObject media = gifObject.getJSONObject("media_formats");
                                JSONObject gifData = media.getJSONObject("tinygif");
                                String gifUrl = gifData.getString("url");

                                int j = i;
                                Platform.runLater(() -> {
                                    arr.get(j).setImageURL(gifUrl);
                                });
                            }
                        } else {
                            System.out.println("Request failed: " + response.code());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return staticGifObject;
    }

    public gifObjectVbox() {
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("gifScene.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        searchGifButton.setOnMouseClicked((_)-> {
            String tenorApikey = "AIzaSyBEAma3ZbO9EIVdPTnwlwCZyEZsSc_4478";

            try {
                Thread.startVirtualThread(() -> {

                    Platform.runLater(() -> {
                        for (var imageView : imageHolder.getChildren()) {
                            ((gifObjectImageView) imageView).setNull();
                        }
                        System.gc();

                    });

                    HttpUrl url = HttpUrl.parse("https://tenor.googleapis.com/v2/search")
                            .newBuilder().addQueryParameter("q", gifSearch.getText().trim())
                            .addQueryParameter("key", tenorApikey)
                            .addQueryParameter("limit", "20")
                            .build();
                    Request request = new Request.Builder()
                            .url(url)
                            .get()
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String responseBody = response.body().string();
                            JSONObject json = new JSONObject(responseBody);

                            JSONArray results = json.getJSONArray("results");
                            for (int i = 0; i < results.length(); i++) {
                                JSONObject gifObject = results.getJSONObject(i);
                                JSONObject media = gifObject.getJSONObject("media_formats");
                                JSONObject gifData = media.getJSONObject("tinygif");
                                String gifUrl = gifData.getString("url");

                                int j = i;
                                Platform.runLater(() -> {
                                    arr.get(j).setImageURL(gifUrl);
                                });
                            }
                        } else {
                            System.out.println("Request failed: " + response.code());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
