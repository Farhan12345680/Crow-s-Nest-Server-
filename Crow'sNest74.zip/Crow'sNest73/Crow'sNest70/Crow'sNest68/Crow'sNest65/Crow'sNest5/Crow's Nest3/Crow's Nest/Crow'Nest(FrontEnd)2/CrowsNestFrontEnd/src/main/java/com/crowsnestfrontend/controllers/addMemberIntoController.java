package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.groupManagement.giveGroupInvite;
import com.groupManagement.groupData;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

public class addMemberIntoController {
    public ImageView MemberImage;
    public Label MemberName;
    public Button sendInvitation;
    public groupData data;

    @FXML
    public void initialize(){

        if(sendInvitation!=null){
            sendInvitation.setOnMouseClicked((e)->{
                groupDetailController.controller1.AddMemberVBox.getChildren().remove(this);
                constantStream.payloadBlockingQueue.add(new giveGroupInvite(Owner.nameId ,data.groupID ,MemberName.getText() ));
            });
        }
    }
}
