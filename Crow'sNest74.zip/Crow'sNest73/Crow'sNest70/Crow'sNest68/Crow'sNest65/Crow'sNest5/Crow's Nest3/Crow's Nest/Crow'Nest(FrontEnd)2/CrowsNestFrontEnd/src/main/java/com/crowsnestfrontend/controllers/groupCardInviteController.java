package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.Utility.codeArea;
import com.crowsnestfrontend.gifObject.gifObjectImageView;
import com.groupManagement.acceptInviteGroup;
import com.groupManagement.deleteGroupInvite;
import com.groupManagement.showInviteGroupData;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

import java.io.IOException;



public class groupCardInviteController extends HBox {
    @FXML
    public ImageView groupImage;
    public ImageView accept;
    public ImageView decline;

    @FXML
    public Label GroupName;

    public showInviteGroupData data;

    public groupCardInviteController(showInviteGroupData data) {
        this.data=data;

        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("GroupCardInvite.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        accept.setOnMouseClicked((e)->{
            Platform.runLater(()->{
                constantStream.payloadBlockingQueue.add(new acceptInviteGroup(Owner.nameId ,data.groupID));
                GroupMessaging.object.groupVBoxContaine.getChildren().remove(this);
            });
        });
        decline.setOnMouseClicked((e)->{
            Platform.runLater(()->{
                constantStream.payloadBlockingQueue.add(new deleteGroupInvite(Owner.nameId ,data.groupID));

                GroupMessaging.object.groupVBoxContaine.getChildren().remove(this);
            });
        });
        groupImage.setImage(new Image(data.groupImageURL));
        GroupName.setText(data.groupName);
    }

}
