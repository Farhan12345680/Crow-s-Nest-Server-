package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.User;
import com.groupManagement.DeleteGroup;
import com.groupManagement.deleteGroupInvite;
import com.groupManagement.getGroupMemberNames;
import com.groupManagement.groupData;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import com.crowsnestfrontend.UserStream.constantStream;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

public class groupDetailController {
    public static groupDetailController controller1;
    public static groupData data;
    public static Runnable runnable;


    @FXML
    public ImageView GroupLogo;
    @FXML
    public Label GroupName;
    @FXML
    public Label GroupDescription;
    @FXML
    public Button AddMember;
    @FXML
    public Button ShowMember;
    @FXML
    public ScrollPane ShowMemberScrollPane;
    @FXML
    public VBox ShowMemberVBox;
    @FXML
    public VBox AddMemberVBox;
    public TextField AddMemberSearchField;
    public VBox AddMemberInnerVBox;

    public Button DeleteGroup;
    public Button LeaveGroup;


    public static ConcurrentHashMap<String , Integer> addMember=new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String , Integer> showMember=new ConcurrentHashMap<>();


    @FXML
    public void initialize(){
        controller1=this;

        if(AddMemberVBox!=null){
            AddMember.setOnMouseClicked((e)->{
                ShowMemberScrollPane.setVisible(false);
                ShowMemberScrollPane.setManaged(false);
                AddMemberVBox.setManaged(true);
                AddMemberVBox.setVisible(true);
                AddMemberInnerVBox.getChildren().clear();

                System.out.println("this is the size of thr keyset "+Owner.current.keySet().size());
                for(var t:Owner.current.keySet()){
                    FXMLLoader loader =new FXMLLoader(MainApplication.class.getResource("addMemberIntoGroup.fxml"));

                    if(showMember.containsKey(t)){
                        continue;
                    }

                    try {
                        HBox box =loader.load();
                        addMemberIntoController j=loader.getController();
                        j.data=data;
                        j.MemberName.setText(t);
                        j.MemberImage.setImage(new Image(Owner.current.get(t).imageURL));
                        AddMemberInnerVBox.getChildren().add(box);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            });
        }
        if(ShowMember!=null){
           ShowMember.setOnMouseClicked((e)->{
               ShowMemberScrollPane.setVisible(true);
               ShowMemberScrollPane.setManaged(true);
               AddMemberVBox.setManaged(false);
               AddMemberVBox.setVisible(false);
               ShowMemberVBox.getChildren().clear();
               showMember.clear();
               constantStream.payloadBlockingQueue.add(new getGroupMemberNames(Owner.nameId ,data.groupID));
           });
        }
        constantStream.payloadBlockingQueue.add(new getGroupMemberNames(Owner.nameId ,data.groupID));

        AddMemberVBox.setVisible(false);
        AddMemberVBox.setManaged(false);
        DeleteGroup.setManaged(false);
        DeleteGroup.setVisible(false);
        LeaveGroup.setManaged(false);
        LeaveGroup.setVisible(false);
        AddMember.setVisible(false);
        AddMember.setManaged(false);

        if(data!=null){
            switch (data.memberRole){
                case 1 ->{
                    LeaveGroup.setManaged(true);
                    LeaveGroup.setVisible(true);

                }
                case 4 ->{
                    DeleteGroup.setManaged(true);
                    DeleteGroup.setVisible(true);
                    AddMember.setManaged(true);
                    AddMember.setVisible(true);

                }
            }
        }

        if(DeleteGroup!=null){
            DeleteGroup.setOnMouseClicked((e)->{
                runnable.run();
                constantStream.payloadBlockingQueue.add(new DeleteGroup(Owner.nameId , data.groupID));
            });
        }

        if(LeaveGroup!=null){
            LeaveGroup.setOnMouseClicked((e)->{
                constantStream.payloadBlockingQueue.add(new deleteGroupInvite(Owner.nameId ,data.groupID));
                ((VBox)(((Node)e.getSource()).getParent()).getParent()).getChildren().remove(
                        (((Node)e.getSource()).getParent()).getParent()
                );
                SceneManager.globalStage.setScene(SceneManager.mainScene);
                SceneManager.globalStage.centerOnScreen();
                runnable.run();
            });
        }

    }
}
