package com.crowsnestfrontend.gifObject;

import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.controllers.GroupMessaging;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


public class gifObjectImageView2 extends ImageView {
    public String imageURL;

    public gifObjectImageView2(String imageURL){
        super();

        this.imageURL=imageURL;

        this.setOnMouseClicked((e)->{
            System.out.println("this is the image url " +this.imageURL);
            if(this.imageURL==null
            ){
                return;
            }
            GroupMessaging.object.EditUploadImage.setText("Delete existing image");
            GroupMessaging.object.imageURL=this.imageURL;
            GroupMessaging.object.EditImage.setImage(new Image(this.imageURL));
        });
    }

    public void setImageURL( String url){
        System.out.println("has this ever been called here \n1\n2\n3\n4");
        this.imageURL=url;

        super.setImage(new Image(url,true));
    }

    public void setNull(){
        this.imageURL=null;
        super.setImage(null);
    }
}
