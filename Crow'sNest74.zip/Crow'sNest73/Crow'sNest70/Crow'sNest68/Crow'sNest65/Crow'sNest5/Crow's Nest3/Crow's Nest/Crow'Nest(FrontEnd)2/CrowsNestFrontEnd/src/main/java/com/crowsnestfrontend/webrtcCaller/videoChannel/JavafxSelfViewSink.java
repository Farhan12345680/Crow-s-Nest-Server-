package com.crowsnestfrontend.webrtcCaller.videoChannel;

import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.webrtcCaller.GlobalResourceKeeper;
import dev.onvoid.webrtc.media.FourCC;
import dev.onvoid.webrtc.media.video.VideoBufferConverter;
import dev.onvoid.webrtc.media.video.VideoFrame;
import dev.onvoid.webrtc.media.video.VideoFrameBuffer;
import dev.onvoid.webrtc.media.video.VideoTrackSink;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.PixelFormat;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.nio.ByteBuffer;
import java.util.Locale;

public class JavafxSelfViewSink implements VideoTrackSink {

    private WritableImage writableImage;
    private byte[] rgbaBuffer;
    private int[] argbBuffer;

    private static final long LOG_INTERVAL_MS = 1000;
    private int frameCount = 0;
    private long lastLogTime = System.currentTimeMillis();



    public JavafxSelfViewSink() { }


    @Override
    public void onVideoFrame(VideoFrame frame) {
        if(!GlobalResourceKeeper.isSelfCameraActive.get()){
            Platform.runLater(()->{
                GlobalResourceKeeper.controller.selfView.setImage(new Image(Owner.image));
            });
            return;
        }
        frameCount++;
        long now = System.currentTimeMillis();

        if (now - lastLogTime >= LOG_INTERVAL_MS) {

            frameCount = 0;
            lastLogTime = now;
        }

        try {
            VideoFrameBuffer frameBuffer = frame.buffer;
            int frameWidth = frameBuffer.getWidth();
            int frameHeight = frameBuffer.getHeight();

            BufferedImage image = new BufferedImage(frameWidth, frameHeight, BufferedImage.TYPE_4BYTE_ABGR);

            byte[] imageBuffer = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();

            VideoBufferConverter.convertFromI420(frameBuffer, imageBuffer, FourCC.RGBA);
            Image fxImage = SwingFXUtils.toFXImage(image, null);

            if(GlobalResourceKeeper.controller!=null){
                Platform.runLater(() ->{
                    GlobalResourceKeeper.controller.selfView.setImage(fxImage);


                });

            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            frame.release();
        }
    }





}