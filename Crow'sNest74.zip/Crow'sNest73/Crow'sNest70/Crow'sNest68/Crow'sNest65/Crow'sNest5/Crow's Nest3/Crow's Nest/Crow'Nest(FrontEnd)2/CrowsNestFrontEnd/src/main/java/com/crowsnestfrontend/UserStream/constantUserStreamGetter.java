package com.crowsnestfrontend.UserStream;

import com.crowsnestfrontend.ClientSideDataBase.UserPayloadHandling;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.RequestUsers;
import com.crowsnestfrontend.SerializedClasses.payLoadUsers;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.User;

import java.io.File;


public class constantUserStreamGetter {

    public static void streamCaller(payLoadUsers users) {
            Thread.startVirtualThread(()->{
                RequestUsers req = users.getRequestUser();

                if (!Owner.current.containsKey(req.getUserName())) {
                    User newUser = new User();

                    newUser.name=(req.getUserName());
                    String data=FileManager.storeImageOnFile(req.getProfilePicture(),
                            "profileImage");
                    newUser.imageURL= data;

                    SceneManager.mainSceneContrller.addUser(newUser);
                    Owner.current.put(newUser.name, newUser);
                    UserPayloadHandling.userPayloadHandling(users ,data);
                    System.out.println("Came here to store the data again ?");

                }

            });
    }

}

