package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.makeUnblock;
import com.crowsnestfrontend.User.Owner;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

import com.crowsnestfrontend.UserStream.constantStream;
import javafx.scene.layout.HBox;

public class BlockCard {
    @FXML
    public ImageView BlockCardImage;
    @FXML
    public Label BlockCardName;
    @FXML
    public Button UnBlockButton;

    public HBox Hbox1;

    public void initialize(){
        if(UnBlockButton!=null){
            UnBlockButton.setOnMouseClicked(e->{
                constantStream.payloadBlockingQueue.add(new makeUnblock(Owner.nameId , BlockCardName.getText()));
                SceneManager.profileController.BlockDataHolder.getChildren().remove(Hbox1);
                System.out.println("Called makeUnBlock");
            });



        }
    }
}
