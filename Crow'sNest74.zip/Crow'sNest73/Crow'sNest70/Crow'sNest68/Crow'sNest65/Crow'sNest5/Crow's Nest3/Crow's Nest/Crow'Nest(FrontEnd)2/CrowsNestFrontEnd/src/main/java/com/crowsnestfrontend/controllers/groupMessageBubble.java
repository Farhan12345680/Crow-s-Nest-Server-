package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.ClientSideDataBase.localDataBaseGenerator;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.Owner;
import com.groupManagement.groupMessaging.DeleteGroupMessage;
import com.groupManagement.groupMessaging.groupMessageDataReceiver;
import com.groupManagement.groupMessaging.groupMessagingSender;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import com.crowsnestfrontend.UserStream.constantStream;
import javafx.scene.text.Text;
import javafx.stage.Screen;


import javax.imageio.ImageTranscoder;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class groupMessageBubble extends HBox {

    @FXML
    public Text messageText;
    @FXML
    public Label SenderName;

    @FXML
    public ImageView messageImage;
    @FXML
    public Label BubbleTime;
    @FXML
    public MenuButton menuButton;
    @FXML
    public ImageView profileImage;
    @FXML
    public MenuItem Edit;
    @FXML
    public MenuItem Delete;
    @FXML
    public groupMessageDataReceiver dataReceiver;

    public groupMessageBubble(groupMessageDataReceiver data){

        dataReceiver=data;
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("GroupMessagingChatBubble.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }


        if(messageText!=null){
            messageText.setText(data.messageText);
        }

        if(BubbleTime!=null){
            BubbleTime.setText(data.date);
        }
        System.out.println("this is the image url "+ data.imageURL);
        if(messageImage!=null && data.imageURL!=null){
            messageImage.setImage(new Image(data.imageURL));
            if(messageImage!=null){
                messageImage.setOnMouseClicked((e)->{
                    try {
                        Dialog<Void> dialog = new Dialog<>();
                        dialog.setDialogPane(new DialogPane());
                        ButtonType tempButton = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
                        dialog.getDialogPane().getButtonTypes().add(tempButton);
                        dialog.getDialogPane().lookupButton(tempButton).setVisible(false);
                        dialog.getDialogPane().lookupButton(tempButton).setManaged(false);


                        var imageView1= new ImageView(messageImage.getImage());
                        ScrollPane pane =new ScrollPane(imageView1);
                        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();

                        imageView1.setFitWidth(screenBounds.getWidth() * 0.9);
                        imageView1.setFitHeight(screenBounds.getHeight() * 0.9);
                        imageView1.setPreserveRatio(true);


                        imageView1.setOnMouseClicked((e1)->{
                            double zoomFactor = 1.1;
                            imageView1.setFitWidth(imageView1.getFitWidth() * zoomFactor);
                            imageView1.setFitHeight(imageView1.getFitHeight() * zoomFactor);
                            e1.consume();
                        });
                        dialog.getDialogPane().setContent(pane);
                        dialog.show();

                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                });

            }

        }

        if(SenderName!=null){
            SenderName.setText(data.clientName);
        }

        if(profileImage!=null){
            String imageURL;
            String Query= """
                        SELECT image from Contacts where name_id=?;
                        """;
            try(Connection conn = DriverManager.getConnection("jdbc:sqlite:clientData.db");
                PreparedStatement ps = conn.prepareStatement(Query)){

                ps.setString(1, data.clientName);
                ResultSet rs =ps.executeQuery();

                while(rs.next()){
                    profileImage .setImage(new Image(rs.getString(1)));

                }
            }catch (Exception e){
                e.printStackTrace();
            }



        }

        if(Edit!=null){
            Edit.setOnAction((e)->{
                GroupMessaging.object.EditCommentVBoxFXML.toFront();
                GroupMessaging.object.EditTextArea.setText(data.messageText);
                if(data.imageURL!=null){
                    GroupMessaging.object.EditImage.setImage(new Image(data.imageURL));
                    GroupMessaging.object.imageURL=data.imageURL;
                    GroupMessaging.object.EditUploadImage.setText("Delete exiting image");
                }else{
                    GroupMessaging.object.EditImage.setImage(null);
                    GroupMessaging.object.imageURL=null;
                }
                GroupMessaging.object.EDITmessageID= data.messageID;


            });
        }
        if(Delete!=null){
            Delete.setOnAction((e)->{
                constantStream.payloadBlockingQueue.add(new DeleteGroupMessage(Owner.nameId, data.messageID));
            });
        }

    }
}
