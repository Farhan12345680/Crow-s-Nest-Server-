package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class payloadMessageReaction extends payload implements Serializable {
    
    @Serial
    private static final long serialVersionUID=1909L;

    public int messageID;
    public int reactionType;
    public String receiver;
    public payloadMessageReaction(String sender ,String receiver ,int messageID , int reactionType){
        super(sender)   ;
        this.receiver=receiver;
        this.messageID=messageID;
            this.reactionType=reactionType;
    }
}
