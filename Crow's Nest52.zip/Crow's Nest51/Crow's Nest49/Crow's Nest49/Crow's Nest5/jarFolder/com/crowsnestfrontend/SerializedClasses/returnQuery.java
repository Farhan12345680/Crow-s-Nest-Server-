package com.crowsnestfrontend.SerializedClasses;

import java.io.Serial;
import java.io.Serializable;

public class returnQuery implements Serializable {
    @Serial
    public static final long serialVersionUID=7L;

    private final int status;
    private final String message;
    private final String imageURL;
    public returnQuery(int status ,String message,String imageURL ){
        this.status=status;
        this.message=message;
        this.imageURL=imageURL;
    }

    public int getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public String getImageBytes() {
        return this.imageURL;
    }
}
