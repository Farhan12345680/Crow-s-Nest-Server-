package com.crowsnestfrontend.controllers;

import com.PostFile.getPostRequest;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.forum.PostStorage;
import com.crowsnestfrontend.forum.forumViewLoading;
import com.crowsnestfrontend.forum.writePost.WritePost;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.ArrayList;

public class forumController {
    @FXML
    public Button Newest;
    @FXML
    public Button Prev15;
    @FXML
    public Text textData;
    @FXML
    public Button Next15;
    @FXML
    public Button GetBack;
    @FXML
    public HBox contentBox;
    @FXML
    public Button writePost;
    @FXML
    public StackPane stackData;

    public int lowest=1;
    public int highest=15;
    public int maximumID=Integer.MIN_VALUE;


    public forumViewLoading loading;
    @FXML
    public VBox mainPostHolder;
    @FXML
    public Button Refresh;
    @FXML
    public Button yourPost;

    @FXML
    public void initialize() throws IOException{

        this.loading=forumViewLoading.initialize();
        stackData.getChildren().add(loading);
       loading.toBack();

        if(GetBack!=null){
            GetBack.setOnMouseClicked((e)->{
                SceneManager.globalStage.setScene(SceneManager.mainScene);
                SceneManager.globalStage.centerOnScreen();
            });
        }

        if(writePost!=null){
            writePost.setOnMouseClicked((e)->{
                stackData.getChildren().add(WritePost.initialize());

                WritePost.initialize().toFront();
            });
        }

        if(Newest!=null){
            Newest.setOnMouseClicked((e)->{
                contentBox.getChildren().clear();
                loading.toFront();
                constantStream.payloadBlockingQueue.add(new getPostRequest(Owner.nameId , -1 ,-1));
            });

        }

        if(Refresh!=null){
            Refresh.setOnMouseClicked((e)->{
                contentBox.getChildren().clear();
                loading.toFront();

                constantStream.payloadBlockingQueue.add(new getPostRequest(Owner.nameId , -1 ,lowest-1));

            });
        }

        if(Next15!=null){
            Next15.setOnMouseClicked((e)->{
                if(highest==maximumID){
                    return;
                }
                contentBox.getChildren().clear();
                loading.toFront();
                this.lowest+=15;
                this.highest+=15;
                constantStream.payloadBlockingQueue.add(new getPostRequest(Owner.nameId , lowest ,highest));
            });
        }

        if(Prev15!=null){
            Prev15.setOnMouseClicked((e)->{
                if(lowest==1){
                    return;
                }
                contentBox.getChildren().clear();
                loading.toFront();
                this.lowest-=15;
                this.highest-=15;
                constantStream.payloadBlockingQueue.add(new getPostRequest(Owner.nameId , lowest ,highest));
            });
        }
    }

    public void changeScene(){
        loading.toBack();
    }

    public void addPostStorage(PostStorage post){

        contentBox.getChildren().add(post);
    }


}
