package com.crowsnestfrontend.UserFloatingButton;

import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.User.User;
import com.crowsnestfrontend.controllers.UserBubbleController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.ListCell;

import java.io.IOException;

public  class UserCell extends ListCell<User> {
    private final Parent root;
    private final UserBubbleController ctrl;

    public UserCell() throws IOException {
        FXMLLoader loader = new FXMLLoader( MainApplication.class.getResource("UserBubble.fxml"));
        root = loader.load();
        ctrl = loader.getController();
        ctrl.setOwnerCell(this);

    }

    @Override
    protected void updateItem(User user, boolean empty) {
        super.updateItem(user, empty);
        if (empty || user == null) {
            setGraphic(null);
        } else {
            ctrl.setUser(user);
            setGraphic(root);
        }
    }
}
