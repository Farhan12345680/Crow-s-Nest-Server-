package com.crowsnestfrontend.webrtcCaller;

import com.ClientSerializedClasses.accept;
import com.ClientSerializedClasses.offerReject;
import com.crowsnestfrontend.SerializedClasses.returnIceObject;
import com.crowsnestfrontend.SerializedClasses.webrtcConnection;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.Utility.VideoChatBox;
import dev.onvoid.webrtc.*;
import dev.onvoid.webrtc.media.MediaStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.ClientSerializedClasses.offer;
import javafx.application.Platform;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.crowsnestfrontend.MainApplication.client;

public class Callee {
    public static Callee callee;

    private PeerConnectionFactory factory;
    public RTCPeerConnection pc;
    private RTCDataChannel dataChannel;
    private final String name;

    private final List<RTCIceCandidate> pendingIce = Collections.synchronizedList(new ArrayList<>());

    private final AtomicBoolean cleaned = new AtomicBoolean(false);
    private final ExecutorService cleanupExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "callee-cleanup");
        t.setDaemon(true);
        return t;
    });

    public static synchronized Callee initialize(String name) {
        if (callee == null || callee.pc == null || callee.cleaned.get()) {
            callee = new Callee(name);
        }
        return callee;
    }

    public Callee(String name) {
        this.name = name;
        factory = new PeerConnectionFactory();
        RTCConfiguration config = new RTCConfiguration();

        RTCIceServer iceServer = new RTCIceServer();
        iceServer.urls.add("stun:stun.l.google.com:19302");
        config.iceServers.add(iceServer);

        pc = factory.createPeerConnection(config, new PeerConnectionObserver() {
            @Override
            public void onDataChannel(RTCDataChannel channel) {
                System.out.println("Callee received data channel: " + channel.getLabel());

                channel.registerObserver(new RTCDataChannelObserver() {
                    @Override
                    public void onBufferedAmountChange(long l) { }

                    @Override
                    public void onStateChange() {
                        System.out.println("Data channel state: " + channel.getState());
                    }

                    @Override
                    public void onMessage(RTCDataChannelBuffer buffer) {
                        try {
                            if (!buffer.binary) {
                                buffer.data.rewind();
                                String msg = StandardCharsets.UTF_8.decode(buffer.data).toString();
                                VideoChatBox.initialize().insertIntoMessage(SelectedUserData.name.get(),
                                                                    msg);
                                return;
                            }

                            ByteBuffer bb = buffer.data;
                            byte[] bytes = new byte[bb.remaining()];
                            bb.get(bytes);

                            Thread.startVirtualThread(() -> handleBinaryMessage(channel, bytes));
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }
                });

                dataChannel = channel;
            }

            @Override public void onIceCandidate(RTCIceCandidate candidate) {
                System.out.println("Callee ICE: " + candidate.sdp);
                var obj = new returnIceObject(
                        Owner.nameId,
                        name,
                        candidate.sdp,
                        candidate.sdpMid,
                        candidate.sdpMLineIndex
                );
                constantStream.payloadBlockingQueue.add(obj);
            }

            @Override public void onIceConnectionChange(RTCIceConnectionState state) {}
            @Override public void onIceGatheringChange(RTCIceGatheringState state) {}
            @Override public void onSignalingChange(RTCSignalingState state) {}
            @Override public void onAddStream(MediaStream stream) {}
            @Override public void onRemoveStream(MediaStream stream) {}
            @Override public void onRenegotiationNeeded() {}
        });
    }

    private void handleBinaryMessage(RTCDataChannel channel, byte[] bytes) {
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bytes))) {
            Object obj = ois.readObject();

            if (obj instanceof offer off) {
                System.out.println("Received Offer object");
                Platform.runLater(() -> {
                    Dialog<Void> dialog = new Dialog<>();
                    dialog.setDialogPane(new DialogPane());

                    ButtonType tempButton = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
                    dialog.getDialogPane().getButtonTypes().add(tempButton);
                    dialog.getDialogPane().lookupButton(tempButton).setVisible(false);
                    dialog.getDialogPane().lookupButton(tempButton).setManaged(false);
                    CallerIncoming calling=null;
                    try{
                        calling = new CallerIncoming(off.name, off.image, dialog::close);

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    dialog.getDialogPane().setContent(calling);
                    dialog.show();
                });
            } else if (obj instanceof accept acc) {
                System.out.println("Received Accept object");
            } else if (obj instanceof String str) {
                System.out.println("Received serialized String: " + str);
            } else if (obj instanceof offerReject) {
                System.out.println("Received offerReject -> schedule cleanup");
                scheduleCleanupAndUiNotify();
            } else {
                System.out.println("Unknown binary object: " + obj.getClass().getName());
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public void sendMessage(String message) {
        if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
            byte[] data = message.getBytes();
            try {
                RTCDataChannelBuffer buffer = new RTCDataChannelBuffer(ByteBuffer.wrap(data), false);
                dataChannel.send(buffer);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("Callee data channel is not open");
        }
    }

    public void sendObject(Object object) {
        Thread.startVirtualThread(() -> {
            try {
                if (dataChannel == null || dataChannel.getState() != RTCDataChannelState.OPEN) {
                    System.err.println("sendObject: dataChannel not open");
                    return;
                }
                try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
                     ObjectOutputStream oos = new ObjectOutputStream(baos)) {
                    oos.writeObject(object);
                    oos.flush();
                    byte[] bytes = baos.toByteArray();
                    dataChannel.send(new RTCDataChannelBuffer(ByteBuffer.wrap(bytes), true));
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
        });
    }

    public void onOfferReceived(RTCSessionDescription offer, String fromName) {
        if (pc == null) {
            System.err.println("onOfferReceived ignored: pc is null");
            return;
        }
        pc.setRemoteDescription(offer, new SetSessionDescriptionObserver() {
            @Override
            public void onSuccess() {
                System.out.println("Callee remote SDP set, creating answer...");
                createAnswer(fromName);
                for (RTCIceCandidate c : pendingIce) {
                    pc.addIceCandidate(c);
                }
                pendingIce.clear();
            }
            @Override
            public void onFailure(String error) {
                System.err.println("Callee failed to set remote: " + error);
            }
        });
    }

    private void createAnswer(String fromName) {
        if (pc == null) {
            System.err.println("createAnswer ignored: pc is null");
            return;
        }
        RTCAnswerOptions options = new RTCAnswerOptions();
        pc.createAnswer(options, new CreateSessionDescriptionObserver() {
            @Override
            public void onSuccess(RTCSessionDescription answer) {
                if (pc == null) return;
                pc.setLocalDescription(answer, new SetSessionDescriptionObserver() {
                    @Override
                    public void onSuccess() {
                        System.out.println("Callee local SDP set");
                        var obj = new webrtcConnection(
                                Owner.nameId,
                                fromName,
                                "ANSWER",
                                answer.sdp
                        );
                        constantStream.payloadBlockingQueue.add(obj);
                    }
                    @Override
                    public void onFailure(String error) {
                        System.err.println("Callee failed to set local: " + error);
                    }
                });
            }
            @Override
            public void onFailure(String error) {
                System.err.println("Callee failed to create answer: " + error);
            }
        });
    }

    public void onIceCandidate(RTCIceCandidate candidate) {
        if (pc == null) {
            pendingIce.add(candidate);
        } else {
            pc.addIceCandidate(candidate);
        }
    }


    private void scheduleCleanupAndUiNotify() {
        scheduleCleanup();
        Platform.runLater(() -> {
            if (CallerIncoming.incoming != null) {
                try {
                    CallerIncoming.incoming.stopCall();
                } catch (Throwable ignored) {}
                CallerIncoming.incoming = null;
            }
            if (callerWaitingScene.callerWaitingInstance != null) {
                try {
                    callerWaitingScene.callerWaitingInstance.run.run();
                } catch (Throwable ignored) {}
                callerWaitingScene.callerWaitingInstance = null;
            }
        });
    }

    private void scheduleCleanup() {
        if (!cleaned.compareAndSet(false, true)) return;
        cleanupExecutor.execute(() -> {
            try {
                if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
                    System.out.println("this is the selected name "+SelectedUserData.name.get());
                    HttpUrl url = HttpUrl.parse("http://localhost:8080/removeBusy?"+SelectedUserData.name.get())
                            .newBuilder().build();
                    Request request = new Request.Builder()
                            .url(url)
                            .get()
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String responseBody = response.body().string();
                            System.out.println(responseBody);
                        }
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
                if (dataChannel != null && dataChannel.getState() == RTCDataChannelState.OPEN) {
                    HttpUrl url = HttpUrl.parse("http://localhost:8080/removeBusy?"+Owner.nameId)
                            .newBuilder().build();
                    Request request = new Request.Builder()
                            .url(url)
                            .get()
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.isSuccessful() && response.body() != null) {
                            String responseBody = response.body().string();
                            System.out.println(responseBody);
                        }
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }

                // close dataChannel first
                if (dataChannel != null) {
                    try { dataChannel.unregisterObserver(); }
                    catch (Throwable ignored) {}
                    try { dataChannel.close(); } catch (Throwable ignored) {}
                    try { dataChannel.dispose(); } catch (Throwable ignored) {}
                    dataChannel = null;
                }

                if (pc != null) {
                    try { pc.close(); } catch (Throwable t) { System.err.println("pc.close() error: "+t.getMessage()); }
                    pc = null;
                }

                if (factory != null) {
                    try { factory.dispose(); } catch (Throwable t) { System.err.println("factory.dispose() error: "+t.getMessage()); }
                    factory = null;
                }

                // clear singleton
                callee = null;
            } finally {
            }
        });
    }


    public void stopCallee() {
        Thread.startVirtualThread(this::scheduleCleanupAndUiNotify);
    }
}
