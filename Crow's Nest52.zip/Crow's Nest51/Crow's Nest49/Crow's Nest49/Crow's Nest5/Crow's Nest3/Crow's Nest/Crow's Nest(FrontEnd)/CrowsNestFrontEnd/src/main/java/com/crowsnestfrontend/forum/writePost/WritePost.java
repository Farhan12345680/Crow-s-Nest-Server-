package com.crowsnestfrontend.forum.writePost;

import com.PostFile.PostData;
import com.cloudinary.utils.ObjectUtils;
import com.crowsnestfrontend.ClientSideDataBase.changeOwnerClientDatabase;
import com.crowsnestfrontend.FileManager;
import com.crowsnestfrontend.MainApplication;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.SerializedClasses.ClientRequest;
import com.crowsnestfrontend.SerializedClasses.ImageChanger;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.UserStream.constantStream;
import com.crowsnestfrontend.forum.MarkDownCodeEditor.MarkDownCodeEditor;
import com.crowsnestfrontend.forum.forumViewScene;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Window;


import java.awt.*;
import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import static com.crowsnestfrontend.SceneManagement.SceneManager.cloudinary;


public class WritePost extends VBox {
    public static WritePost curr;

    public static WritePost  initialize(){
        if(curr==null){
            curr= new WritePost();
        }

        return curr;
    }

    @FXML
    public Button DiscardButton;
    @FXML
    public Button Post;
    @FXML
    public Button addImage;
    @FXML
    public TextField PostHeader;
    @FXML
    public TextField PostDescription;
    @FXML
    public Button preViewThePostButton;


    MarkDownCodeEditor codeEditor;

    public WritePost(){
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.
                class.getResource("writePost.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(DiscardButton!=null){
            DiscardButton.setOnMouseClicked((e)->{
                PostHeader.clear();
                PostDescription.clear();
                this.toBack();
            });
        }

        if(addImage!=null){

        }

        if(Post!=null){
            Post.setOnMouseClicked((e)->{
                Thread.startVirtualThread(()->{
                    String title=PostHeader.getText();
                    String description=PostDescription.getText();
                    String markDownCode =codeEditor.getText();
                    byte[] byte1=new byte[0];
                    File Folder=new File("Posts");

                    try{
                        Folder.mkdir();
                    }catch (Exception e1){
                        System.out.println(e1.getMessage());
                    }
                    File temp=new File("Posts/temp.md");
                    try(FileOutputStream fs=new FileOutputStream(temp)) {
                        temp.createNewFile();
                        fs.write(markDownCode.getBytes());

                    } catch (FileNotFoundException ex) {
                        throw new RuntimeException(ex);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }

                    try(FileInputStream fs = new FileInputStream(temp)){
                        byte1= Files.readAllBytes(temp.toPath()) ;

                    }catch (Exception e2 ){
                        System.out.println("encoded unsuccessful");
                    }

                    try{
                        temp.delete();
                    }catch (Exception e1 ){
                        e1.printStackTrace();
                    }


                    PostData data= new PostData(Owner.nameId, title,description,byte1);
                    constantStream.payloadBlockingQueue.add(
                            data
                    );
                    Platform.runLater(()->{

                        PostHeader.clear();
                        PostDescription.clear();
                        codeEditor.clear();
                        forumViewScene.jk().controller.stackData.getChildren().remove(this);
                        forumViewScene.jk().controller.mainPostHolder.toFront();
                    });
                });
            });
        }
        this.codeEditor=new MarkDownCodeEditor();
        this.getChildren().add(codeEditor);

        if(preViewThePostButton!=null){
            preViewThePostButton.setOnMouseClicked((e)->{

            });
        }

        if(addImage!=null){
            addImage.setOnMouseClicked((e)->{

                    onUploadButton(e ,this , codeEditor);

            });

        }

    }

    public static void onUploadButton(MouseEvent event , Node node ,MarkDownCodeEditor codeEditor) {
        Window ownerWindow = node.getScene().getWindow();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Profile Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp")
        );

        File selectedFile = fileChooser.showOpenDialog(ownerWindow);
        if (selectedFile != null) {
            CountDownLatch UPLOADER_LATCH=new CountDownLatch(1);
            Platform.runLater(()->{

                forumViewScene.jk().controller.loading.toFront();
            });

            Thread.startVirtualThread(()->{
                ByteArrayOutputStream baos = new ByteArrayOutputStream();

                try {
                    net.coobird.thumbnailator.Thumbnails.of(selectedFile)
                            .scale(1.0)
                            .outputFormat(Files.probeContentType(selectedFile.toPath()).substring(6))
                            .toOutputStream(baos);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                byte[] imageBytes = baos.toByteArray();


                Map uploadResult = null;
                try {
                    uploadResult = cloudinary.uploader().upload(imageBytes,
                            ObjectUtils.asMap("folder", "postImages"));
                }
                catch (IOException e) {
                    throw new RuntimeException(e);
                }

                String imageUrl = (String) uploadResult.get("secure_url");
                Owner.image = FileManager.storeImageOnFile( imageUrl,"profileImage");

                System.out.println("Uploaded Image URL: " + imageUrl);
                Platform.runLater(()->{
                    codeEditor.appendText("![image]("+imageUrl+")\n");
                });

                UPLOADER_LATCH.countDown();




            });

            Thread.startVirtualThread(()->{
                try{
                    UPLOADER_LATCH.await();
                    System.out.println("came here");
                    Platform.runLater(()->{
                        forumViewScene.jk().controller.loading.toBack();

                    });
                }catch (Exception e){
                    System.out.println(e.getMessage());
                }

            });

        }
    }



}
