package com.crowsnestfrontend.controllers;

import com.crowsnestfrontend.Messages.codeStackPane;
import com.crowsnestfrontend.SceneManagement.SceneManager;
import com.crowsnestfrontend.User.Owner;
import com.crowsnestfrontend.User.SelectedUserData;
import com.crowsnestfrontend.Utility.codeArea;
import javafx.animation.AnimationTimer;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.image.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import nu.pattern.OpenCV;
import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.LineNumberFactory;
import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;

import java.io.ByteArrayInputStream;


public class VideoSceneController {

    @FXML
    public ImageView otherView;
    @FXML
    public ImageView endCall;
    @FXML
    public ImageView code;
    @FXML
    public ImageView camera;
    @FXML
    public ImageView mic;

    @FXML
    public ImageView selfView;

    @FXML
    public VBox voiceHolder;
    @FXML
    public HBox buttonHolder;
    @FXML
    public VBox codeArea;
    @FXML
    public VBox videoChatHolder;
    @FXML
    public Text ClientName;
    @FXML
    public Text UserName;

    private CodeArea codeBox;
    private AnimationTimer timer;
    private VideoCapture capture;

    private byte[] buffer;
    private WritableImage writableImage;
    private PixelWriter pixelWriter;
    private static final long ONE_FRAME_NS = 33_333_333;
    private int state=0;


    @FXML
    public void initialize() {

        ClientName.setText(SelectedUserData.name.get());
        UserName.setText(Owner.nameId);

        otherView.setImage(new Image(new ByteArrayInputStream(SelectedUserData.image)));
//
//        codeArea.getChildren().add(codeBox);




        voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
        videoChatHolder.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight()-200);
        selfView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        selfView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        otherView.setFitWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() * 1F/2 );
        otherView.setFitHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() * 1F/3);
        codeArea.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *65f/100);
        codeArea.setMinHeight(Screen.getScreens().getFirst().getVisualBounds().getHeight() *90f/100);

        codeStackPane pane=new codeStackPane();
        codeArea.getChildren().add(pane);

        codeArea.setVisible(false);
        codeArea.setManaged(false);
        code.setOnMouseClicked((e)->{
            if(state==0){
                codeArea.setVisible(true);
                codeArea.setManaged(true);

                voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth() *30f/100);
            }
            else{
                codeArea.setVisible(false);
                codeArea.setManaged(false);
                voiceHolder.setMinWidth(Screen.getScreens().getFirst().getVisualBounds().getWidth());
            }
            state++;
            state%=2;
        });
        endCall.setOnMouseClicked((e)->{
            stopCamera();
            SceneManager.globalStage.setScene(SceneManager.mainScene);
            SceneManager.globalStage.centerOnScreen();
            SceneManager.globalStage.show();
        });

        camera.setOnMouseClicked((e)->{
            cycleCamera();
        });


        startCamera();
    }

    private volatile boolean cameraActive = false;
    private Thread cameraThread; 

    private void startCamera() {
        OpenCV.loadShared();
        capture = new VideoCapture(0, Videoio.CAP_ANY);

        if (!capture.isOpened()) {
            selfView.setImage(new Image(new ByteArrayInputStream(Owner.image)));
            return;
        }

        cameraActive = true;

        Mat frame = new Mat();
        Mat rotated = new Mat();
        Mat converted = new Mat();

        cameraThread = Thread.ofVirtual().start(() -> {
            byte[] buffer = null;
            WritableImage writableImage = null;
            PixelWriter pixelWriter = null;

            while (cameraActive) {
                if (!capture.read(frame) || frame.empty()) {
                    Platform.runLater(() -> selfView.setImage(new Image(new ByteArrayInputStream(Owner.image))));
                    break;
                }


                Core.rotate(frame, rotated, Core.ROTATE_90_CLOCKWISE);
                Imgproc.cvtColor(rotated, converted, Imgproc.COLOR_BGR2BGRA);

                int width = converted.width();
                int height = converted.height();

                if (buffer == null || buffer.length != width * height * 4) {
                    buffer = new byte[width * height * 4];
                    writableImage = new WritableImage(width, height);
                    pixelWriter = writableImage.getPixelWriter();
                }

                converted.get(0, 0, buffer);

                WritableImage finalImage = writableImage;
                byte[] finalBuffer = buffer;
                PixelWriter finalPixelWriter = pixelWriter;
                Platform.runLater(() -> {
                    finalPixelWriter.setPixels(0, 0, width, height, PixelFormat.getByteBgraInstance(), finalBuffer, 0, width * 4);
                    selfView.setImage(finalImage);
                });

                try {
                    Thread.sleep(33);
                } catch (InterruptedException e) {
                    break;
                }
            }
        });
    }

    private void stopCamera() {
        cameraActive = false;

        if (cameraThread != null && cameraThread.isAlive()) {
            try {
                cameraThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            cameraThread = null;
        }

        if (capture != null) {
            if (capture.isOpened()) capture.release();
            capture = null;
        }

        Platform.runLater(() -> selfView.setImage(new Image(new ByteArrayInputStream(Owner.image))));
    }

    private void cycleCamera() {
        if (cameraActive) {
            stopCamera();
        } else {
            startCamera();
        }
    }


}
